import Mathlib

namespace PEqualNP.Outside.L_meta_9427

noncomputable def retainedTerms (B : Finset (Finset ℕ)) (missing : Finset (Fin 11 × Fin 11)) :
    Finset (Finset ℕ) := by
  classical
  exact B.filter fun t => ∃ r : Fin 16, r.val ∈ t ∧ edgeAt r ∉ missing

private theorem headsFromProjectionPartial
    (D B : Finset (Finset ℕ)) (label : Finset ℕ → Finset (Fin 11))
    (missing : Finset (Fin 11 × Fin 11))
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      rowsOf (label a) ∩ rowsOf (label b) ⊆ edgeRows ∧
      ∀ r : Fin 16, r.val ∈ t → edgeAt r ∉ missing →
        r.val ∈ rowsOf (label a) ∩ rowsOf (label b))
    (cover : ∀ r : Fin 16, edgeAt r ∉ missing → r.val ∈ B.biUnion id) :
    ∃ H : Finset (Fin 11 × Finset (Fin 11)), H.card ≤ (retainedTerms B missing).card ∧
      (∀ h ∈ H, h.2 ∈ D.image label ∧ h.2 ⊆ neighbors h.1) ∧
      (∀ e ∈ orientedEdges, e ∈ missing ∨ ∃ h ∈ H,
        (e.1 = h.1 ∧ e.2 ∈ h.2) ∨ (e.2 = h.1 ∧ e.1 ∈ h.2)) := by
  classical
  let terms := retainedTerms B missing
  have extract (t : Finset ℕ) (ht : t ∈ terms) :
      ∃ h : Fin 11 × Finset (Fin 11), h.2 ∈ D.image label ∧
        h.2 ⊆ neighbors h.1 ∧ ∀ r : Fin 16, r.val ∈ t → edgeAt r ∉ missing →
          ((edgeAt r).1 = h.1 ∧ (edgeAt r).2 ∈ h.2) ∨
          ((edgeAt r).2 = h.1 ∧ (edgeAt r).1 ∈ h.2) := by
    obtain ⟨htB, r, inT, hr⟩ := Finset.mem_filter.mp ht
    obtain ⟨a, ha, b, hb, clean, keep⟩ := pairs t htB
    let P := rowsOf (label a)
    let Q := rowsOf (label b)
    let T := P ∩ Q
    have cleanRows : P ∩ Q ∩ actualRows ⊆ edgeRows := Finset.inter_subset_left.trans clean
    have Tnonempty : (T ∩ edgeRows).Nonempty :=
      ⟨r.val, Finset.mem_inter.mpr ⟨keep r inT hr, Finset.mem_range.mpr r.isLt⟩⟩
    obtain ⟨h, other, adj, each⟩ :=
      projectedHead P Q T (label a) (label b) Finset.Subset.rfl Finset.Subset.rfl
        rfl rfl cleanRows rfl Tnonempty
    refine ⟨h, ?_, adj, fun i hi hm => each i (keep i hi hm)⟩
    rcases other with eq | eq
    · rw [eq]
      exact Finset.mem_image_of_mem _ ha
    · rw [eq]
      exact Finset.mem_image_of_mem _ hb
  let select (t : Finset ℕ) : Fin 11 × Finset (Fin 11) :=
    if h : t ∈ terms then (extract t h).choose else (0, ∅)
  have selected (t : Finset ℕ) (ht : t ∈ terms) :
      (select t).2 ∈ D.image label ∧
        (select t).2 ⊆ neighbors (select t).1 ∧ ∀ r : Fin 16, r.val ∈ t →
        edgeAt r ∉ missing →
          ((edgeAt r).1 = (select t).1 ∧ (edgeAt r).2 ∈ (select t).2) ∨
          ((edgeAt r).2 = (select t).1 ∧ (edgeAt r).1 ∈ (select t).2) := by
    simpa [select, ht] using (extract t ht).choose_spec
  let H := terms.image select
  have heads : ∀ h ∈ H, h.2 ∈ D.image label ∧ h.2 ⊆ neighbors h.1 := by
    intro h hh
    obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hh
    exact ⟨(selected t ht).1, (selected t ht).2.1⟩
  have covered : ∀ e ∈ orientedEdges, e ∈ missing ∨ ∃ h ∈ H,
      (e.1 = h.1 ∧ e.2 ∈ h.2) ∨ (e.2 = h.1 ∧ e.1 ∈ h.2) := by
    intro e he
    by_cases hm : e ∈ missing
    · exact Or.inl hm
    right
    obtain ⟨lt, adj⟩ := (Finset.mem_filter.mp he).2
    obtain ⟨r, eq⟩ := edgeAtIndexed e.1 e.2 lt adj
    have notMissing : edgeAt r ∉ missing := by simpa only [eq] using hm
    obtain ⟨t, ht, inT⟩ := Finset.mem_biUnion.mp (cover r notMissing)
    have hT : t ∈ terms := Finset.mem_filter.mpr ⟨ht, ⟨r, inT, notMissing⟩⟩
    refine ⟨select t, Finset.mem_image_of_mem _ hT, ?_⟩
    have found := (selected t hT).2.2 r inT notMissing
    rw [eq] at found
    exact found
  exact ⟨H, Finset.card_image_le, heads, covered⟩

private theorem headsFromProjection
    (D B : Finset (Finset ℕ)) (label : Finset ℕ → Finset (Fin 11))
    (missing : Finset (Fin 11 × Fin 11))
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      rowsOf (label a) ∩ rowsOf (label b) ⊆ edgeRows ∧
      ∀ r : Fin 16, r.val ∈ t → edgeAt r ∉ missing →
        r.val ∈ rowsOf (label a) ∩ rowsOf (label b))
    (cover : edgeRows ⊆ B.biUnion id) :
    ∃ H : Finset (Fin 11 × Finset (Fin 11)), H.card ≤ (retainedTerms B missing).card ∧
      (∀ h ∈ H, h.2 ∈ D.image label ∧ h.2 ⊆ neighbors h.1) ∧
      (∀ e ∈ orientedEdges, e ∈ missing ∨ ∃ h ∈ H,
        (e.1 = h.1 ∧ e.2 ∈ h.2) ∨ (e.2 = h.1 ∧ e.1 ∈ h.2)) :=
  headsFromProjectionPartial D B label missing pairs
    (fun r _ => cover (Finset.mem_range.mpr r.isLt))

private theorem projectedCostWithMissing
    (D B : Finset (Finset ℕ)) (label : Finset ℕ → Finset (Fin 11))
    (missing : Finset (Fin 11 × Fin 11)) (missingSub : missing ⊆ orientedEdges)
    (build : ∀ w ∈ D.image label, 1 < w.card →
      ∃ a ∈ D.image label, ∃ b ∈ D.image label, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      rowsOf (label a) ∩ rowsOf (label b) ⊆ edgeRows ∧
      ∀ r : Fin 16, r.val ∈ t → edgeAt r ∉ missing →
        r.val ∈ rowsOf (label a) ∩ rowsOf (label b))
    (cover : edgeRows ⊆ B.biUnion id) :
    23 ≤ ((D.image label).filter fun s => 1 < s.card).card +
      2 * B.card + 2 * missing.card := by
  obtain ⟨H, count, heads, covered⟩ := headsFromProjection D B label missing pairs cover
  have bound := pureCostWithMissing (D.image label) H missing missingSub build heads covered
  have terms : retainedTerms B missing ⊆ B := by
    classical
    exact Finset.filter_subset _ _
  have termCost := count.trans (Finset.card_le_card terms)
  omega

end PEqualNP.Outside.L_meta_9427
