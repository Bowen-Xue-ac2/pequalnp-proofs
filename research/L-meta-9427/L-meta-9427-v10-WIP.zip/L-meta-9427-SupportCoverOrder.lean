import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def termRow (i : Fin 17) : ℕ :=
  if i.val = 16 then 40 else i.val

def termCode (t : Finset ℕ) : ℕ :=
  Nat.ofBits fun i : Fin 17 => decide (termRow i ∈ t)

private theorem termCodeInjOn (B : Finset (Finset ℕ))
    (condition : ∀ t ∈ B, t ⊆ insert 40 edgeRows) :
    Set.InjOn termCode (B : Set (Finset ℕ)) := by
  intro t ht q hq eq
  ext r
  by_cases atTarget : r ∈ insert 40 edgeRows
  · have index : ∃ i : Fin 17, termRow i = r := by
      rcases Finset.mem_insert.mp atTarget with rfl | actual
      · exact ⟨16, rfl⟩
      · have bound : r < 16 := Finset.mem_range.mp actual
        exact ⟨⟨r, bound.trans (by decide)⟩, by simp [termRow, Nat.ne_of_lt bound]⟩
    obtain ⟨i, row⟩ := index
    have bits := congrArg (fun n : ℕ => n.testBit i.val) eq
    have test (s : Finset ℕ) : (termCode s).testBit i.val = decide (termRow i ∈ s) :=
      Nat.testBit_ofBits_lt _ i i.isLt
    rw [test t, test q, row] at bits
    exact ⟨fun h => of_decide_eq_true (bits.symm.trans (decide_eq_true h)),
      fun h => of_decide_eq_true (bits.trans (decide_eq_true h))⟩
  · exact ⟨fun h => (atTarget (condition t ht h)).elim,
      fun h => (atTarget (condition q hq h)).elim⟩

private theorem supportCoverOrdered (d e : Finset ℕ) (B : Finset (Finset ℕ))
    (G : Finset (CoverOperand × CoverOperand))
    (clean : ∀ t ∈ B, t ⊆ insert 40 edgeRows)
    (values : G.image (supportedTerm d e) = B) :
    ∃ terms : Fin B.card → CoverOperand × CoverOperand,
      StrictMono (fun i => termCode (supportedTerm d e (terms i))) ∧
      Finset.univ.image (fun i => supportedTerm d e (terms i)) = B := by
  classical
  let codes := B.image termCode
  let ordered := codes.sort (· ≤ ·)
  have orderLength : ordered.length = B.card :=
    (Finset.length_sort (s := codes) (· ≤ ·)).trans
      (Finset.card_image_of_injOn (termCodeInjOn B clean))
  let element (i : Fin B.card) := ordered.get (i.cast orderLength.symm)
  have witness (i : Fin B.card) :
      ∃ g ∈ G, termCode (supportedTerm d e g) = element i := by
    have atList : element i ∈ ordered := List.get_mem _ _
    have inCodes : element i ∈ codes := by simpa only [ordered, Finset.mem_sort] using atList
    obtain ⟨t, tB, eq⟩ := Finset.mem_image.mp inCodes
    rw [← values] at tB
    obtain ⟨g, hg, rfl⟩ := Finset.mem_image.mp tB
    exact ⟨g, hg, eq⟩
  let term (i : Fin B.card) := (witness i).choose
  have chosen (i : Fin B.card) :
      term i ∈ G ∧ termCode (supportedTerm d e (term i)) = element i := (witness i).choose_spec
  have output (i : Fin B.card) : supportedTerm d e (term i) ∈ B :=
    values ▸ Finset.mem_image_of_mem _ (chosen i).1
  refine ⟨term, ?_, ?_⟩
  · intro i j lt
    change termCode (supportedTerm d e (term i)) < termCode (supportedTerm d e (term j))
    rw [(chosen i).2, (chosen j).2]
    have pairwise : List.Pairwise (· ≤ ·) ordered := Finset.pairwise_sort _ _
    have distinct : ordered.Nodup := Finset.sort_nodup _ _
    have le : element i ≤ element j :=
      List.pairwise_iff_get.mp pairwise _ _ lt
    have ne : element i ≠ element j :=
      List.pairwise_iff_get.mp (List.nodup_iff_pairwise_ne.mp distinct) _ _ lt
    exact lt_of_le_of_ne le ne
  · ext t
    constructor
    · intro appears
      obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp appears
      exact output i
    · intro inB
      have atList : termCode t ∈ ordered := by
        simpa only [ordered, Finset.mem_sort] using (Finset.mem_image_of_mem termCode inB)
      obtain ⟨i, hi⟩ := List.mem_iff_get.mp atList
      let j := i.cast orderLength
      have h : element j = termCode t := by simpa only [element, j, Fin.cast_cast, Fin.cast_eq_self] using hi
      have exactTerm := termCodeInjOn B clean (output j) inB ((chosen j).2.trans h)
      exact Finset.mem_image.mpr ⟨j, Finset.mem_univ _, exactTerm⟩

def swapOperandTags (a : CoverOperand) : CoverOperand :=
  ⟨a.support, a.secondTag, a.firstTag⟩

private theorem swapSupportedTerm (d e : Finset ℕ) (a b : CoverOperand) :
    supportedTerm e d (swapOperandTags a, swapOperandTags b) = supportedTerm d e (a, b) := by
  have row (w : CoverOperand) : operandRows e d (swapOperandTags w) = operandRows d e w := by
    simp only [operandRows, swapOperandTags, Finset.union_right_comm] <;> rfl
  unfold supportedTerm
  dsimp only
  rw [row a, row b]
  simp only [swapOperandTags, Bool.and_comm]

def tagCode (t : Finset ℕ) : ℕ :=
  Nat.ofBits fun i : Fin 40 => decide (i.val ∈ t)

private theorem orderedSupportModel (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dFrom : ∃ a ∈ D, ∃ b ∈ D, a ⊆ actualRows ∧ b ⊆ actualRows ∧ d = a ∩ b)
    (eFrom : ∃ a ∈ D, ∃ b ∈ D, a ⊆ actualRows ∧ b ⊆ actualRows ∧ e = a ∩ b)
    (dDirty : ¬d ⊆ edgeRows) (eDirty : ¬e ⊆ edgeRows)
    (build : ∀ t ∈ D, t ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ t ∧ b ⊂ t ∧ t = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    ∃ (p q : Finset ℕ) (U V X Y : Finset (Fin 11))
        (T : Fin B.card → CoverOperand × CoverOperand),
      p = rowsOf U ∩ rowsOf V ∧ q = rowsOf X ∩ rowsOf Y ∧
      ¬p ⊆ edgeRows ∧ ¬q ⊆ edgeRows ∧ tagCode p ≤ tagCode q ∧
      (((p ∩ q) ⊆ edgeRows) ↔ ((d ∩ e) ⊆ edgeRows)) ∧
      (∀ i, supportedTerm p q (T i) ⊆ insert 40 edgeRows) ∧
      StrictMono (fun i => termCode (supportedTerm p q (T i))) ∧
      (Finset.univ.image fun i => supportedTerm p q (T i)).biUnion id = insert 40 edgeRows := by
  classical
  have clean (t : Finset ℕ) (ht : t ∈ B) : t ⊆ insert 40 edgeRows := by
    obtain ⟨_, _, _, _, _, inside⟩ := pairs t ht
    exact inside
  obtain ⟨U, V, X, Y, G, dVal, eVal, _, values⟩ :=
    supportCoverFromFamily d e D B dFrom eFrom build pairs
  obtain ⟨T, order, outputs⟩ := supportCoverOrdered d e B G clean values
  have legal (i : Fin B.card) : supportedTerm d e (T i) ⊆ insert 40 edgeRows :=
    clean _ (outputs ▸ Finset.mem_image_of_mem _ (Finset.mem_univ i))
  have allRows :
      (Finset.univ.image fun i => supportedTerm d e (T i)).biUnion id = insert 40 edgeRows := by
    rw [outputs, cover]
  rcases le_total (tagCode d) (tagCode e) with keep | flip
  · exact ⟨d, e, U, V, X, Y, T, dVal, eVal, dDirty, eDirty, keep, Iff.rfl, legal, order, allRows⟩
  · let R (i : Fin B.card) : CoverOperand × CoverOperand :=
      (swapOperandTags (T i).1, swapOperandTags (T i).2)
    have same (i : Fin B.card) : supportedTerm e d (R i) = supportedTerm d e (T i) :=
      swapSupportedTerm d e (T i).1 (T i).2
    refine ⟨e, d, X, Y, U, V, R, eVal, dVal, eDirty, dDirty, flip, ?_, ?_, ?_, ?_⟩
    · rw [Finset.inter_comm e d]
    · intro i
      rw [same i]
      exact legal i
    · simpa only [same] using order
    · simpa only [same] using allRows

end PEqualNP.Outside.L_meta_9427
