#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <set>
#include <unordered_map>
#include <vector>

using Word = std::uint32_t;
constexpr Word positive = (1u << 16) - 1;
constexpr Word negative = (1u << 24) - 1;
constexpr std::array<std::uint64_t, 11> vertices = {
    2147418115, 663661903884, 34144976944, 728266375360, 21653750532,
    103293914128, 26322415680, 344922804352, 414195942664, 581968119809, 1065151898146,
};

struct Clause {
    Word truth;
    Word falsity;
};

bool cover(Word remaining, int count, const std::vector<Word>& clauses,
           const std::array<std::vector<Word>, 24>& by_row,
           std::unordered_map<Word, int>& failed) {
    if (!remaining) {
        return true;
    }
    if (!count) {
        return false;
    }
    if (auto old = failed.find(remaining); old != failed.end() && count <= old->second) {
        return false;
    }
    int max_rows = 0;
    for (Word clause : clauses) {
        const Word gained = remaining & clause;
        if (gained == remaining) {
            return true;
        }
        max_rows = std::max(max_rows, std::popcount(gained));
    }
    if (count == 1 || max_rows * count < std::popcount(remaining)) {
        return false;
    }
    int rare = -1;
    for (Word rows = remaining; rows; rows &= rows - 1) {
        const int row = std::countr_zero(rows);
        if (rare < 0 || by_row[row].size() < by_row[rare].size()) {
            rare = row;
        }
    }
    for (Word clause : by_row[rare]) {
        if (cover(remaining & ~clause, count - 1, clauses, by_row, failed)) {
            return true;
        }
    }
    failed[remaining] = count;
    return false;
}

int main() {
    std::set<std::uint64_t> words = {0};
    for (auto vertex : vertices) {
        std::vector<std::uint64_t> previous(words.begin(), words.end());
        for (auto word : previous) {
            words.insert(word | vertex);
        }
    }
    std::vector<Clause> family;
    for (auto word : words) {
        if (Word false_rows = negative & ~(word >> 16)) {
            family.push_back({positive & Word(word), false_rows});
        }
    }
    std::sort(family.begin(), family.end(), [](auto a, auto b) {
        return std::popcount(a.falsity) > std::popcount(b.falsity);
    });
    std::array<int, 6> maxima = {};
    std::array<Word, 6> examples = {};
    std::array<std::uint64_t, 7> totals = {};
    std::array<int, positive + 1> minima = {};
    for (Word t = 0; t <= positive; ++t) {
        std::vector<Word> relevant;
        std::array<std::vector<Word>, 24> by_row;
        for (auto clause : family) {
            if ((clause.truth & t) != t) {
                continue;
            }
            if (std::any_of(relevant.begin(), relevant.end(), [clause](Word prev) {
                    return (prev & clause.falsity) == clause.falsity;
                })) {
                continue;
            }
            relevant.push_back(clause.falsity);
            for (Word rows = clause.falsity; rows; rows &= rows - 1) {
                by_row[std::countr_zero(rows)].push_back(clause.falsity);
            }
        }
        std::unordered_map<Word, int> failed;
        int bound = 1;
        for (; bound <= 5; ++bound) {
            if (cover(negative, bound, relevant, by_row, failed)) {
                break;
            }
        }
        minima[t] = bound;
        ++totals[bound];
        for (int q = bound; q <= 5; ++q) {
            if (int n = std::popcount(t); n > maxima[q]) {
                maxima[q] = n;
                examples[q] = t;
            }
        }
    }
    std::cout << "distinct clauses with a nonempty negative falsity mask " << family.size() << '\n';
    for (int q = 1; q <= 5; ++q) {
        std::cout << "clauses " << q << ", minimal for " << totals[q] << " edge subsets, maximum "
                  << maxima[q] << " edges, example mask " << examples[q] << '\n';
    }
    std::cout << "more than five clauses needed for " << totals[6] << " edge subsets\n";
    std::array<std::array<int, 6>, 6> pairs = {};
    for (Word a = 0; a <= positive; ++a) {
        if (minima[a] > 5) {
            continue;
        }
        for (Word extra = a;; extra = (extra - 1) & a) {
            Word b = (positive ^ a) | extra;
            if (b >= a && minima[b] <= 5) {
                auto [low, high] = std::minmax(minima[a], minima[b]);
                ++pairs[low][high];
            }
            if (!extra) {
                break;
            }
        }
    }
    for (int a = 1; a <= 5; ++a) {
        for (int b = a; b <= 5; ++b) {
            if (pairs[a][b]) {
                std::cout << "two masks with " << a << " and " << b << " minimum clauses cover all edges in "
                          << pairs[a][b] << " ways\n";
            }
        }
    }
    std::array<std::array<std::array<int, 6>, 6>, 6> triples = {};
    for (Word a = 0; a <= positive; ++a) {
        if (minima[a] > 5) {
            continue;
        }
        const Word remaining = positive ^ a;
        for (Word b = remaining;; b = (b - 1) & remaining) {
            const Word c = remaining ^ b;
            if (a <= b && b <= c && minima[b] <= 5 && minima[c] <= 5) {
                std::array counts = {minima[a], minima[b], minima[c]};
                std::sort(counts.begin(), counts.end());
                ++triples[counts[0]][counts[1]][counts[2]];
            }
            if (!b) {
                break;
            }
        }
    }
    for (int a = 1; a <= 5; ++a) {
        for (int b = a; b <= 5; ++b) {
            for (int c = b; c <= 5; ++c) {
                if (triples[a][b][c]) {
                    std::cout << "clause counts " << a << ' ' << b << ' ' << c << ", partitions "
                              << triples[a][b][c] << '\n';
                }
            }
        }
    }
}
