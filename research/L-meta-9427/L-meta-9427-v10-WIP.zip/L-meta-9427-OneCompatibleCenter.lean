import Mathlib

namespace PEqualNP.Outside.L_meta_9427

set_option maxHeartbeats 1800000 in
private theorem costOverlapWithSingleCompatibleCenter (d e : Finset ℕ)
    (D B : Finset (Finset ℕ)) (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (n : ℕ) (nd : n ∈ d) (ne : n ∈ e) (neg : n ∉ edgeRows)
    (v : Fin 11) (oneCenter : ∀ z ∈ ({d,e} : Finset (Finset ℕ)), ∀ u : Fin 11,
      z ∩ rootSet u ∩ actualRows ⊆ edgeRows → u = v)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  classical
  let X := markedSeeds d e
  let seed (w : Finset ℕ) := if hw : w ∈ X then (eraseSeedFacts d e dRows eRows w hw).choose else ∅
  obtain ⟨label, rooted, joined⟩ := labelUnionFamily D X seed build
  have fromSeed (w : Finset ℕ) (hw : w ∈ D) (seedWord : w ∈ X) :
      (label w).card ≤ 1 ∧ projectionFacts d e ∅ ∅ w (label w) ∧
        ((40 ∈ w ∨ 41 ∈ w) → (label w) = ∅) ∧ ¬(40 ∈ w ∧ 41 ∈ w) := by
    rw [rooted w hw seedWord]
    simpa [seed, seedWord] using (eraseSeedFacts d e dRows eRows w seedWord).choose_spec
  have replay := projectionFactsReplay D X d e ∅ ∅ label
    (fun w hw hx => (fromSeed w hw hx).2.1) joined
  let plain := D.filter fun w => ¬carriesTag w
  have plainBuild (w : Finset ℕ) (hw : w ∈ plain) (paid : w ∉ X) :
      ∃ a ∈ plain, ∃ b ∈ plain, a ⊂ w ∧ b ⊂ w ∧ label w = label a ∪ label b := by
    obtain ⟨wD, noMark⟩ := Finset.mem_filter.mp hw
    obtain ⟨a, aD, b, bD, sa, sb, _, eq⟩ := joined w wD paid
    have keeps (z : Finset ℕ) (zD : z ∈ D) (zSub : z ⊆ w) : z ∈ plain := by
      refine Finset.mem_filter.mpr ⟨zD, ?_⟩
      exact fun h => noMark (h.elim (fun f => Or.inl (zSub f)) (fun f => Or.inr (zSub f)))
    exact ⟨a, keeps a aD sa.1, b, keeps b bD sb.1, sa, sb, eq⟩
  obtain ⟨paidPlain, rulesPlain⟩ := projectedFamily plain X label
    (fun w hw hx => (fromSeed w (Finset.mem_filter.mp hw).1 hx).1) plainBuild
  have witnesses (t : {t // t ∈ B}) := pairs t.val t.property
  choose a aD b bD output clean using witnesses
  have rawClean (t : {t // t ∈ B}) : a t ∩ b t ∩ actualRows ⊆ edgeRows :=
    (cleanProductFacts _ _ (output t ▸ clean t)).1
  have synthetic : 40 ∈ B.biUnion id := by rw [cover]; exact Finset.mem_insert_self _ _
  obtain ⟨t, ht, tag⟩ := Finset.mem_biUnion.mp synthetic
  let tTag : {t // t ∈ B} := ⟨t, ht⟩
  have carrier := overlapTagCarrier d e _ _ _ _ (replay _ (aD tTag)) (replay _ (bD tTag))
    n nd ne (dRows nd) neg (output tTag ▸ clean tTag) (output tTag ▸ tag)
  have paidMarked : ∃ w ∈ D \ X, carriesTag w := by
    have find (w : Finset ℕ) (wD : w ∈ D) (first : 40 ∈ w) (second : 41 ∈ w) :
        ∃ z ∈ D \ X, carriesTag z := by
      have counted : w ∉ X := fun h => (fromSeed w wD h).2.2.2 ⟨first, second⟩
      exact ⟨w, Finset.mem_sdiff.mpr ⟨wD, counted⟩, Or.inl first⟩
    exact carrier.elim (fun h => find _ (aD tTag) h.1 h.2.1)
      (fun h => find _ (bD tTag) h.1 h.2.1)
  have losesOne : (plain \ X).card + 1 ≤ (D \ X).card := by
    obtain ⟨w, wD, yes⟩ := paidMarked
    have strict : plain \ X ⊂ D \ X := Finset.ssubset_iff_subset_ne.mpr
      ⟨fun z hz => Finset.mem_sdiff.mpr
        ⟨(Finset.mem_filter.mp (Finset.mem_sdiff.mp hz).1).1, (Finset.mem_sdiff.mp hz).2⟩,
        fun eq => by
          have paid : w ∈ plain \ X := eq.symm ▸ wD
          have quiet : ¬carriesTag w := (Finset.mem_filter.mp (Finset.mem_sdiff.mp paid).1).2
          exact quiet yes⟩
    exact Finset.card_lt_card strict
  have carriesShared (w : Finset ℕ) (wD : w ∈ D) (marker : carriesTag w) : n ∈ w := by
    exact marker.elim (fun f => ((replay w wD).2.1 f).1 nd)
      (fun f => ((replay w wD).2.2.1 f).1 ne)
  have fromTag (x y : Finset ℕ) (xD : x ∈ D) (yD : y ∈ D)
      (xMark : carriesTag x) (cleanRows : x ∩ y ∩ actualRows ⊆ edgeRows)
      (r : ℕ) (rActual : r ∈ actualRows) (row : r ∈ y) : r ∈ rootSet v := by
    have yPlain : ¬carriesTag y := fun yes => neg (cleanRows
      (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨carriesShared x xD xMark, carriesShared y yD yes⟩, dRows nd⟩))
    have plainRow : r ∈ rowsOf (label y) := by
      rcases (replay y yD).2.2.2 r row rActual with hits | ⟨flag, _⟩ | ⟨flag, _⟩
      · exact hits
      · exact (yPlain (Or.inl flag)).elim
      · exact (yPlain (Or.inr flag)).elim
    obtain ⟨u, uY, atU⟩ := Finset.mem_biUnion.mp plainRow
    have xContains : ∃ z ∈ ({d,e} : Finset (Finset ℕ)), z ⊆ x := by
      rcases xMark with fd | fe
      · exact ⟨d, Finset.mem_insert_self _ _, ((replay x xD).2.1 fd).1⟩
      · exact ⟨e, Finset.mem_insert_of_mem (Finset.mem_singleton_self _), ((replay x xD).2.2.1 fe).1⟩
    obtain ⟨z, zKind, zInX⟩ := xContains
    have cleanOpposite : z ∩ rootSet u ∩ actualRows ⊆ edgeRows := by
      intro s hs
      obtain ⟨both, actual⟩ := Finset.mem_inter.mp hs
      obtain ⟨atZ, atRoot⟩ := Finset.mem_inter.mp both
      exact cleanRows (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨zInX atZ,
        (replay y yD).1 (Finset.mem_biUnion.mpr ⟨u,uY,atRoot⟩)⟩, actual⟩)
    exact oneCenter z zKind u cleanOpposite ▸ atU
  let ordinary := B.attach.filter fun t => ¬carriesTag (a t) ∧ ¬carriesTag (b t)
  let P := ordinary.image Subtype.val
  have fewOrdinary : P.card + 1 ≤ B.card := by
    have absent : tTag ∉ ordinary := by
      intro has
      have pure := (Finset.mem_filter.mp has).2
      exact carrier.elim (fun h => pure.1 (Or.inl h.1)) (fun h => pure.2 (Or.inl h.1))
    have subset : ordinary ⊂ B.attach := Finset.ssubset_iff_subset_ne.mpr
      ⟨Finset.filter_subset _ _, fun eq => absent (eq.symm ▸ Finset.mem_attach _ _)⟩
    have count := Finset.card_lt_card subset
    rw [Finset.card_attach] at count
    have imageCount : P.card ≤ ordinary.card := Finset.card_image_le
    omega
  let missing := orientedEdges.filter fun f => f.1 = v ∨ f.2 = v
  have realWitness (t : {t // t ∈ B}) (r : Fin 16) (hr : r.val ∈ t.val) :
      r.val ∈ a t ∩ b t := by
    have pos : r.val ∈ edgeRows := Finset.mem_range.mpr r.isLt
    have real := (cleanProductFacts _ _ (output t ▸ clean t)).2.1
    have ht : r.val ∈ t.val ∩ edgeRows := Finset.mem_inter.mpr ⟨hr,pos⟩
    rw [output t, real] at ht
    exact (Finset.mem_inter.mp ht).1
  have ordinaryPairs (t : Finset ℕ) (ht : t ∈ P) :
      ∃ x ∈ plain, ∃ y ∈ plain, rowsOf (label x) ∩ rowsOf (label y) ⊆ edgeRows ∧
        ∀ r : Fin 16, r.val ∈ t → edgeAt r ∉ missing → r.val ∈ rowsOf (label x) ∩ rowsOf (label y) := by
    obtain ⟨q, hq, rfl⟩ := Finset.mem_image.mp ht
    have h := (Finset.mem_filter.mp hq).2
    refine ⟨a q, Finset.mem_filter.mpr ⟨aD q, h.1⟩,
      b q, Finset.mem_filter.mpr ⟨bD q, h.2⟩,
      projectedClean _ _ _ _ (replay _ (aD q)).1 (replay _ (bD q)).1 (rawClean q), ?_⟩
    intro r atQ _
    obtain ⟨left,right⟩ := Finset.mem_inter.mp (realWitness q r atQ)
    have actual : r.val ∈ actualRows := Finset.mem_range.mpr (r.isLt.trans (by decide : 16 < 40))
    have lift (w : Finset ℕ) (wD : w ∈ D) (inW : r.val ∈ w) (quiet : ¬carriesTag w) :
        r.val ∈ rowsOf (label w) := by
      rcases (replay w wD).2.2.2 r.val inW actual with room | ⟨f,_⟩ | ⟨f,_⟩
      · exact room
      · exact (quiet (Or.inl f)).elim
      · exact (quiet (Or.inr f)).elim
    exact Finset.mem_inter.mpr ⟨lift _ (aD q) left h.1, lift _ (bD q) right h.2⟩
  have ordinaryCover (r : Fin 16) (kept : edgeAt r ∉ missing) : r.val ∈ P.biUnion id := by
    have pos : r.val ∈ edgeRows := Finset.mem_range.mpr r.isLt
    have actual : r.val ∈ actualRows := Finset.mem_range.mpr (r.isLt.trans (by decide : 16 < 40))
    have original : r.val ∈ B.biUnion id := by rw [cover]; exact Finset.mem_insert_of_mem pos
    obtain ⟨q, hq, hit⟩ := Finset.mem_biUnion.mp original
    let w : {t // t ∈ B} := ⟨q, hq⟩
    have ⟨left,right⟩ := Finset.mem_inter.mp (realWitness w r hit)
    have outside : r.val ∉ rootSet v := by
      intro contains
      rcases (edgeAtMembership r v).mp contains with first | second
      · exact kept (Finset.mem_filter.mpr ⟨edgeAtOriented r, Or.inl first.symm⟩)
      · exact kept (Finset.mem_filter.mpr ⟨edgeAtOriented r, Or.inr second.symm⟩)
    have inOrdinary : w ∈ ordinary := Finset.mem_filter.mpr ⟨Finset.mem_attach _ _, by
      constructor
      · intro flag
        exact outside (fromTag _ _ (aD w) (bD w) flag (rawClean w) r.val actual right)
      · intro flag
        have reversed : b w ∩ a w ∩ actualRows ⊆ edgeRows := by
          simpa only [Finset.inter_comm (b w) (a w)] using rawClean w
        exact outside (fromTag _ _ (bD w) (aD w) flag reversed r.val actual left)⟩
    exact Finset.mem_biUnion.mpr ⟨q, Finset.mem_image_of_mem _ inOrdinary, hit⟩
  obtain ⟨H, hCount, heads, covers⟩ :=
    headsFromProjectionPartial plain P label missing ordinaryPairs ordinaryCover
  let F₀ := plain.image label
  let singletonRoots : Finset (Finset (Fin 11)) :=
    (Finset.univ : Finset (Fin 11)).image (fun u => {u})
  let F := F₀ ∪ singletonRoots
  have allRoots (u : Fin 11) : ({u} : Finset (Fin 11)) ∈ F :=
    Finset.mem_union_right _ (Finset.mem_image_of_mem _ (Finset.mem_univ _))
  have largeFromOld (w : Finset (Fin 11)) (hw : w ∈ F) (big : 1 < w.card) : w ∈ F₀ := by
    rcases Finset.mem_union.mp hw with old | root
    · exact old
    · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp root
      simp at big
  have built (w : Finset (Fin 11)) (hw : w ∈ F) (big : 1 < w.card) :
      ∃ a ∈ F, ∃ b ∈ F, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b := by
    obtain ⟨a,aIn,b,bIn,left,right,eq⟩ := rulesPlain w (largeFromOld w hw big) big
    exact ⟨a,Finset.mem_union_left _ aIn,b,Finset.mem_union_left _ bIn,left,right,eq⟩
  have countF : (F.filter fun s => 1 < s.card).card ≤ (plain \ X).card := by
    refine (Finset.card_le_card ?_).trans paidPlain
    intro w hw
    obtain ⟨belongs,big⟩ := Finset.mem_filter.mp hw
    exact Finset.mem_filter.mpr ⟨largeFromOld w belongs big,big⟩
  obtain ⟨G, enlarge, fullStar, unionCost, buildG⟩ := adjoinPureSupport F (neighbors v) allRoots built
  let expanded := insert (v,neighbors v) H
  have valid (h : Fin 11 × Finset (Fin 11)) (hh : h ∈ expanded) :
      h.2 ∈ G ∧ h.2 ⊆ neighbors h.1 := by
    rcases Finset.mem_insert.mp hh with rfl | old
    · exact ⟨fullStar, Finset.Subset.rfl⟩
    · exact ⟨enlarge (Finset.mem_union_left _ (heads h old).1), (heads h old).2⟩
  have complete (f : Fin 11 × Fin 11) (hf : f ∈ orientedEdges) :
      ∃ h ∈ expanded, (f.1 = h.1 ∧ f.2 ∈ h.2) ∨ (f.2 = h.1 ∧ f.1 ∈ h.2) := by
    rcases covers f hf with atCenter | ⟨h, hh, done⟩
    · have adjacent := (Finset.mem_filter.mp hf).2.2
      refine ⟨(v,neighbors v), Finset.mem_insert_self _ _, ?_⟩
      rcases (Finset.mem_filter.mp atCenter).2 with first | second
      · exact Or.inl ⟨first, Finset.mem_filter.mpr ⟨Finset.mem_univ _, first ▸ adjacent⟩⟩
      · exact Or.inr ⟨second, Finset.mem_filter.mpr ⟨Finset.mem_univ _, second ▸ (edgeSwap _ _).mp adjacent⟩⟩
    · exact ⟨h, Finset.mem_insert_of_mem hh, done⟩
  have cost := pureCost G expanded buildG valid complete
  have headCount : H.card ≤ P.card := hCount.trans (Finset.card_le_card (Finset.filter_subset _ _))
  have expandedCount : expanded.card ≤ H.card + 1 := Finset.card_insert_le _ _
  have degree : (neighbors v).card ≤ 4 := (show ∀ u : Fin 11, (neighbors u).card ≤ 4 by decide +kernel) v
  change (plain \ X).card + 1 ≤ (D \ markedSeeds d e).card at losesOne
  omega

private def tagCenters (d e : Finset ℕ) : Finset (Fin 11) :=
  Finset.univ.filter fun u => ∃ z ∈ ({d,e} : Finset (Finset ℕ)),
    z ∩ rootSet u ∩ actualRows ⊆ edgeRows

private theorem costOverlapWithAtMostOneCenter (d e : Finset ℕ)
    (D B : Finset (Finset ℕ)) (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (n : ℕ) (nd : n ∈ d) (ne : n ∈ e) (neg : n ∉ edgeRows)
    (few : (tagCenters d e).card ≤ 1)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  have member (z : Finset ℕ) (inTags : z ∈ ({d,e} : Finset (Finset ℕ))) (u : Fin 11)
      (clean : z ∩ rootSet u ∩ actualRows ⊆ edgeRows) : u ∈ tagCenters d e :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ _, z, inTags, clean⟩
  by_cases live : (tagCenters d e).Nonempty
  · obtain ⟨v,hv⟩ := live
    exact costOverlapWithSingleCompatibleCenter d e D B dRows eRows n nd ne neg v
      (fun z hz u clean => Finset.card_le_one.mp few u (member z hz u clean) v hv)
      build pairs cover
  · exact costOverlapWithSingleCompatibleCenter d e D B dRows eRows n nd ne neg 0
      (fun z hz u clean => (live ⟨u,member z hz u clean⟩).elim) build pairs cover

private theorem costFromIdenticalTagsWithTwoRoots (d : Finset ℕ) (D B : Finset (Finset ℕ))
    (dRows : d ⊆ actualRows) (dirty : ¬d ⊆ edgeRows)
    (u v : Fin 11) (distinct : u ≠ v) (fromU : rootSet u ⊆ d) (fromV : rootSet v ⊆ d)
    (build : ∀ w ∈ D, w ∉ markedSeeds d d →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d d).card + 2 * B.card := by
  classical
  have witness : ∃ n ∈ d, n ∉ edgeRows := by
    by_contra absent
    apply dirty
    intro r hr
    by_contra neg
    exact absent ⟨r,hr,neg⟩
  obtain ⟨n, nd, neg⟩ := witness
  apply costOverlapWithAtMostOneCenter d d D B dRows dRows n nd nd neg _ build pairs cover
  have narrow : tagCenters d d ⊆ neighbors u ∩ neighbors v := by
    intro s hs
    obtain ⟨w, hw, safe⟩ := (Finset.mem_filter.mp hs).2
    have eq : w = d := by simpa using hw
    subst w
    have adjacent (a : Fin 11) (whole : rootSet a ⊆ d) : s ∈ neighbors a := by
      refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, (rootSetPair a s).mp ?_⟩
      intro r hr
      obtain ⟨left,right⟩ := Finset.mem_inter.mp hr
      exact safe (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨whole left,right⟩, rootRowsBound a left⟩)
    exact Finset.mem_inter.mpr ⟨adjacent u fromU, adjacent v fromV⟩
  exact (Finset.card_le_card narrow).trans (commonNeighbors u v distinct)

end PEqualNP.Outside.L_meta_9427

