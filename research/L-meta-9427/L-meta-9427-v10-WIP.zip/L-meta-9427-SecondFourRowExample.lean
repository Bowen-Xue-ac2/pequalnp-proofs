import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def secondExampleProducer (i : Fin 3) : Finset ℕ :=
  ([rootSet 1 ∪ rootSet 9, rootSet 0 ∪ rootSet 4, rootSet 1 ∪ rootSet 10] :
    List (Finset ℕ))[i.val]?.getD ∅

def secondExampleD : Finset ℕ := rootSet 0 ∩ secondExampleProducer 0

def secondExampleE : Finset ℕ := secondExampleProducer 1 ∩ secondExampleProducer 2

def secondExampleLost (i : Fin 4) : Fin 11 × Fin 11 :=
  edgeAt (([0,1,2,9] : List (Fin 16))[i.val]?.getD 0)

def secondExampleCenter (i : Fin 3) : Fin 11 :=
  ([8,10,4] : List (Fin 11))[i.val]?.getD 0

def secondExampleRequired (i : Fin 3) : Finset (Fin 16) :=
  ([{3,15}, {1,9}, {2,9}] : List (Finset (Fin 16)))[i.val]?.getD ∅

def secondExampleUnused (E : Finset (Fin 11 × Fin 11)) (C : Finset (Fin 11)) :
    Finset (Fin 3) :=
  Finset.univ.filter fun i => secondExampleCenter i ∉ C ∨
    ∃ r ∈ secondExampleRequired i, edgeAt r ∉ E

def secondExampleFree (E : Finset (Fin 11 × Fin 11)) : Finset (Fin 11) :=
  (Finset.univ.filter fun i => ∀ r ∈ secondExampleRequired i, edgeAt r ∈ E).image
    secondExampleCenter

def secondExampleGroups (omitted : Finset (Fin 4)) : Finset (Finset (Fin 11)) :=
  let cases : List (Finset (Finset (Fin 11))) :=
    [∅, {{2,5}}, {{0,9}}, {{2,5},{3,6}},
     {{0,9}}, {{2,5},{3,6}}, {{0,9},{2,5}}, {{2,5},{3,6},{4,10}},
     {{0,9}}, {{0,10},{1,4}}, {{0,9},{1,4}}, {{1,4},{2,5},{3,6}},
     {{0,9},{2,5}}, {{0,10},{2,5},{3,6}}, {{0,9},{2,5},{3,6}},
     {{3,6,7},{2,10},{5,9}}]
  cases[Nat.ofBits (fun i : Fin 4 => decide (i ∈ omitted))]?.getD ∅

set_option maxHeartbeats 4000000 in
set_option synthInstance.maxSize 4096 in
private theorem secondExampleGroupCheck :
    ∀ omitted : Finset (Fin 4),
      let E := orientedEdges \ omitted.image secondExampleLost
      let groups := secondExampleGroups omitted
      E.card + omitted.card = 16 ∧
      (∑ g ∈ groups, (g.card - 1)) = omitted.card ∧
      (∀ g ∈ groups, ∀ h ∈ groups, g ≠ h → ∀ u ∈ g, u ∉ h) ∧
      (∀ g ∈ groups, ∀ u ∈ g, u ∉ secondExampleFree E) ∧
      (∀ g ∈ groups, ∀ u ∈ g, ∀ v ∈ g, u < v → (u, v) ∈ E) := by
  intro omitted
  fin_cases omitted <;> decide +kernel

private theorem secondExampleWeightedCheck :
    ∀ omitted : Finset (Fin 4), ∀ C : Finset (Fin 11),
      let E := orientedEdges \ omitted.image secondExampleLost
      (∀ f ∈ E, f.1 ∈ C ∨ f.2 ∈ C) →
      21 ≤ E.card + C.card + (secondExampleUnused E C).card + 2 := by
  classical
  intro omitted C E covers
  obtain ⟨edgeCount, groupCount, separate, noFree, complete⟩ := secondExampleGroupCheck omitted
  let A := secondExampleFree E
  let Z := C \ A
  let G := secondExampleGroups omitted
  have localCover (g : Finset (Fin 11)) (hg : g ∈ G) : g.card - 1 ≤ (g ∩ Z).card := by
    have remaining (u : Fin 11) (hu : u ∈ g \ Z) : u ∈ g ∧ u ∉ C := by
      obtain ⟨atG, atZ⟩ := Finset.mem_sdiff.mp hu
      exact ⟨atG, fun atC => atZ (Finset.mem_sdiff.mpr ⟨atC, noFree g hg u atG⟩)⟩
    have single : (g \ Z).card ≤ 1 := by
      apply Finset.card_le_one.mpr
      intro u hu v hv
      obtain ⟨uG, uC⟩ := remaining u hu
      obtain ⟨vG, vC⟩ := remaining v hv
      by_contra distinct
      rcases lt_or_gt_of_ne distinct with uv | vu
      · exact (covers _ (complete g hg u uG v vG uv)).elim uC vC
      · exact (covers _ (complete g hg v vG u uG vu)).elim vC uC
    have split := Finset.card_sdiff_add_card_eq_card
      (Finset.inter_subset_left : g ∩ Z ⊆ g)
    have difference : g \ (g ∩ Z) = g \ Z := by
      ext u
      simp only [Finset.mem_sdiff, Finset.mem_inter]
      tauto
    rw [difference] at split
    omega
  have disjoint : (G : Set (Finset (Fin 11))).PairwiseDisjoint (fun g => g ∩ Z) := by
    intro g hg h hh distinct
    apply Finset.disjoint_left.mpr
    intro v vg vh
    exact separate g hg h hh distinct v (Finset.mem_inter.mp vg).1 (Finset.mem_inter.mp vh).1
  have withinZ := sumDisjointCard G (fun g => g ∩ Z) Z
    (fun _ _ => Finset.inter_subset_right) disjoint
  have counted := Finset.sum_le_sum (s := G) localCover
  change (∑ g ∈ G, (g.card - 1)) = omitted.card at groupCount
  rw [groupCount] at counted
  let used := Finset.univ \ secondExampleUnused E C
  have usedTotal := Finset.card_sdiff_add_card_eq_card
    (Finset.subset_univ (secondExampleUnused E C))
  have total : used.card + (secondExampleUnused E C).card = 3 := by
    simpa [used] using usedTotal
  have available (i : Fin 3) (hi : i ∈ used) :
      secondExampleCenter i ∈ C ∧ secondExampleCenter i ∈ A := by
    have usedI := (Finset.mem_sdiff.mp hi).2
    have inC : secondExampleCenter i ∈ C := by
      by_contra absent
      exact usedI (Finset.mem_filter.mpr ⟨Finset.mem_univ _, Or.inl absent⟩)
    have ready (r : Fin 16) (hr : r ∈ secondExampleRequired i) : edgeAt r ∈ E := by
      by_contra absent
      exact usedI (Finset.mem_filter.mpr ⟨Finset.mem_univ _, Or.inr ⟨r, hr, absent⟩⟩)
    exact ⟨inC, Finset.mem_image.mpr ⟨i,
      Finset.mem_filter.mpr ⟨Finset.mem_univ _, ready⟩, rfl⟩⟩
  have separateCenters : Disjoint Z (used.image secondExampleCenter) := by
    apply Finset.disjoint_left.mpr
    intro u inZ picked
    obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp picked
    exact (Finset.mem_sdiff.mp inZ).2 (available i hi).2
  have allCenters : Z ∪ used.image secondExampleCenter ⊆ C := by
    intro u hu
    rcases Finset.mem_union.mp hu with inZ | picked
    · exact (Finset.mem_sdiff.mp inZ).1
    · obtain ⟨i, hi, rfl⟩ := Finset.mem_image.mp picked
      exact (available i hi).1
  have uniqueCenter : Function.Injective secondExampleCenter := by decide +kernel
  have centerBound := Finset.card_le_card allCenters
  rw [Finset.card_union_of_disjoint separateCenters,
    Finset.card_image_of_injective _ uniqueCenter] at centerBound
  change E.card + omitted.card = 16 at edgeCount
  omega

set_option maxHeartbeats 4000000 in
private theorem secondExampleLocalFacts :
    (∀ r : Fin 16, r.val ∈ secondExampleD ∨ r.val ∈ secondExampleE →
      ∃ i : Fin 4, secondExampleLost i = edgeAt r) ∧
    (∀ i : Fin 3, secondExampleProducer i ⊆ actualRows ∧
      secondExampleProducer i ∉ markedSeeds secondExampleD secondExampleE ∧
      ¬carriesTag (secondExampleProducer i)) ∧
    Function.Injective secondExampleProducer ∧
    (∀ i : Fin 3, ∀ u : Fin 11, u ≠ secondExampleCenter i →
      ¬(secondExampleProducer i ∩ rootSet u ∩ actualRows ⊆ edgeRows)) ∧
    (∀ i : Fin 3, ∀ r ∈ secondExampleRequired i,
      r.val ∈ secondExampleProducer i ∩ rootSet (secondExampleCenter i) ∩ actualRows) := by
  decide +kernel

private theorem costSecondFourRowExample (D B : Finset (Finset ℕ))
    (producers : ∀ i : Fin 3, secondExampleProducer i ∈ D)
    (build : ∀ w ∈ D, w ∉ markedSeeds secondExampleD secondExampleE →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds secondExampleD secondExampleE).card + 2 * B.card := by
  classical
  obtain ⟨loss, nodes, distinct, oneCenter, required⟩ := secondExampleLocalFacts
  have dRows : secondExampleD ⊆ actualRows :=
    Finset.inter_subset_left.trans (rootRowsBound 0)
  have eRows : secondExampleE ⊆ actualRows :=
    Finset.inter_subset_left.trans (nodes 1).1
  apply costByRetainedGraph secondExampleD secondExampleE D B dRows eRows build pairs cover
  intro E edges kept C covers
  let omitted := Finset.univ.filter fun i : Fin 4 => secondExampleLost i ∉ E
  have graph : E = orientedEdges \ omitted.image secondExampleLost := by
    apply Finset.ext
    intro f
    constructor
    · intro fE
      refine Finset.mem_sdiff.mpr ⟨edges fE, ?_⟩
      intro removed
      obtain ⟨i, hi, eq⟩ := Finset.mem_image.mp removed
      exact (Finset.mem_filter.mp hi).2 (eq.symm ▸ fE)
    · intro difference
      obtain ⟨inG, notOmitted⟩ := Finset.mem_sdiff.mp difference
      by_contra lost
      obtain ⟨lt, adj⟩ := (Finset.mem_filter.mp inG).2
      obtain ⟨r, ordered⟩ := edgeAtIndexed f.1 f.2 lt adj
      have eq : edgeAt r = f := by simpa only [Prod.eta] using ordered
      have reason : possibleOmission secondExampleD secondExampleE r.val := by
        by_contra impossible
        exact lost (eq ▸ kept r impossible)
      obtain ⟨i, value⟩ := loss r (possibleOmissionMem reason)
      have iLost : i ∈ omitted := Finset.mem_filter.mpr
        ⟨Finset.mem_univ _, fun found => lost (eq ▸ value ▸ found)⟩
      exact notOmitted (Finset.mem_image.mpr ⟨i, iLost, value.trans eq⟩)
  let U := (secondExampleUnused E C).image secondExampleProducer
  have gateCount : U.card = (secondExampleUnused E C).card :=
    Finset.card_image_of_injective _ distinct
  have enough : 21 ≤ E.card + C.card + U.card + 2 := by
    rw [gateCount, graph]
    exact secondExampleWeightedCheck omitted C (by simpa only [graph] using covers)
  refine ⟨U, enough, ?_⟩
  intro w hw
  obtain ⟨i, missed, rfl⟩ := Finset.mem_image.mp hw
  refine ⟨Finset.mem_sdiff.mpr ⟨producers i, (nodes i).2.1⟩, (nodes i).2.2, ?_⟩
  intro u hu usable
  have positive : rowsIn E ⊆ edgeRows := by
    intro r hr
    obtain ⟨q, _, rfl⟩ := Finset.mem_image.mp hr
    exact Finset.mem_range.mpr q.isLt
  have same : u = secondExampleCenter i := by
    by_contra different
    exact oneCenter i u different (usable.trans positive)
  subst u
  rcases (Finset.mem_filter.mp missed).2 with absent | ⟨r, hr, absent⟩
  · exact absent hu
  · have row := usable (required i r hr)
    obtain ⟨q, hq, equal⟩ := Finset.mem_image.mp row
    have eq : q = r := Fin.ext equal
    exact absent (eq ▸ (Finset.mem_filter.mp hq).2)

end PEqualNP.Outside.L_meta_9427
