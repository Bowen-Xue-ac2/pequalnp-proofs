import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem augmentSeedCover (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (scenario : coverScenario d e D B) :
    ∃ C, coverScenario d e (D ∪ markedSeeds d e) C ∧ C.card ≤ B.card ∧
      ((D ∪ markedSeeds d e) \ markedSeeds d e).card = (D \ markedSeeds d e).card := by
  obtain ⟨dFrom, eFrom, dirtyD, dirtyE, bound, build, mPos, mBound, kBound, cover, terms, _⟩ :=
    scenario
  let X := markedSeeds d e
  let E := D ∪ X
  let allProducts := Finset.image₂ productTerm E E
  let cleanProducts := allProducts.filter fun p => p ⊆ insert 40 edgeRows
  have includeD : D ⊆ E := Finset.subset_union_left
  have inProducts : B ⊆ cleanProducts := by
    intro t ht
    obtain ⟨a, aD, b, bD, eq⟩ := Finset.mem_image₂.mp (terms t ht).1
    exact Finset.mem_filter.mpr ⟨Finset.mem_image₂.mpr ⟨a, includeD aD, b, includeD bD, eq⟩,
      (terms t ht).2.1⟩
  obtain ⟨C, few, full, maximal, privateRows⟩ := maximalPrivateSubcover _ cleanProducts B
    inProducts cover (fun _ h => (Finset.mem_filter.mp h).2)
  have samePaid : E \ X = D \ X := by
    ext t
    change t ∈ (D ∪ X) \ X ↔ t ∈ D \ X
    simp only [Finset.mem_sdiff, Finset.mem_union]
    tauto
  have seedBound : ∀ w ∈ X, w ⊆ Finset.range 42 := by
    intro w hw r hr
    have inside : actualRows ⊆ Finset.range 42 := by decide
    change w ∈ markedSeeds d e at hw
    simp only [markedSeeds, Finset.mem_insert] at hw
    rcases hw with rfl | rfl | root
    · rcases Finset.mem_insert.mp hr with rfl | row
      · decide
      · exact inside (plainIntersectionsBound D d dFrom row)
    · rcases Finset.mem_insert.mp hr with rfl | row
      · decide
      · exact inside (plainIntersectionsBound D e eFrom row)
    · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp root
      exact inside (rootRowsBound u hr)
  refine ⟨C, ?_, few, congrArg Finset.card samePaid⟩
  change coverScenario d e E C
  refine ⟨plainIntersectionsMono includeD dFrom, plainIntersectionsMono includeD eFrom,
    dirtyD, dirtyE, ?_, ?_, by rwa [samePaid], by rwa [samePaid], few.trans kBound, full,
    ?_, privateRows⟩
  · intro w hw
    exact (Finset.mem_union.mp hw).elim (bound w) (seedBound w)
  · intro w hw notSeed
    have old := (Finset.mem_union.mp hw).resolve_right notSeed
    obtain ⟨a, aD, b, bD, aSub, bSub, eq⟩ := build w old notSeed
    exact ⟨a, includeD aD, b, includeD bD, aSub, bSub, eq⟩
  · intro t ht
    obtain ⟨present, top⟩ := maximal t ht
    obtain ⟨fromPair, clean⟩ := Finset.mem_filter.mp present
    exact ⟨fromPair, clean, fun q hq cleanQ larger => top q (Finset.mem_filter.mpr ⟨hq, cleanQ⟩) larger⟩

private theorem cappedCounterexampleWithAllSeeds (d e : Finset ℕ) (cap : ℕ)
    (witness : ∃ D B, coverScenario d e D B ∧
      (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧ B.card ≤ cap) :
    ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧
      markedSeeds d e ⊆ D ∧ B.card ≤ cap ∧
      ∀ a ∈ D, ∀ b ∈ D, ∀ c ∈ D, ∀ f ∈ D,
        productTerm a b ∈ B → productTerm c f ∈ B → productTerm a b ≠ productTerm c f →
        ¬(productTerm a f ⊆ insert 40 edgeRows ∧ productTerm c b ⊆ insert 40 edgeRows) := by
  apply cappedCounterexampleWithRequiredWords d e (markedSeeds d e) cap
  obtain ⟨D, B, scenario, cost, few⟩ := witness
  obtain ⟨C, updated, count, paid⟩ := augmentSeedCover d e D B scenario
  exact ⟨D ∪ markedSeeds d e, C, updated, by omega, Finset.subset_union_right, count.trans few⟩

end PEqualNP.Outside.L_meta_9427

