#define OR_LIMIT 6
#define COVER_LIMIT 7
#define main general_search_main
#include "L-meta-9427-small-or.cpp"
#undef main

#include <map>
#include <string_view>

struct PlainOperand {
    Mask word;
    Mask largest_compatible;
    unsigned compatible_roots;
    unsigned contained_roots;
    unsigned equal_roots;
};

Mask largest_compatible(Mask word) {
    Mask result = 0;
    for (Mask root : vertices) {
        if (!(root & word & negatives)) {
            result |= root;
        }
    }
    return result;
}

PlainOperand study(Mask word) {
    PlainOperand result{word, 0, 0, 0, 0};
    for (std::size_t i = 0; i < vertices.size(); ++i) {
        const Mask root = vertices[i];
        const unsigned bit = 1u << i;
        if (!(word & root & negatives)) {
            result.largest_compatible |= root;
            result.compatible_roots |= bit;
        }
        if ((word & root) == root) {
            result.contained_roots |= bit;
        }
        if (word == root) {
            result.equal_roots |= bit;
        }
    }
    return result;
}

struct JunkOperand {
    PlainOperand shape;
    unsigned star_centers = 0;
    int repair_heads = 100;
    bool mirror = false;
};

struct OverlapSearch {
    Search exact;
    bool apply_graph_charges = false;
    bool disjoint_tags = false;
    std::uint64_t dirty_pairs = 0;
    std::uint64_t at_most_two_omissions = 0;
    std::uint64_t other_proven_profiles = 0;
    std::uint64_t relaxed_pairs = 0;
    std::uint64_t relaxed_cover_checks = 0;

    void split_envelope(Mask d, Mask e, const auto& add) {
        const unsigned marker = 1u << 16;
        const Mask common = d & e & low;
        const auto include = [&](Mask a, Mask b) {
            add(marker | unsigned(common | (a & largest_compatible(a) & low)));
            for (Mask root : vertices) {
                if (root & b & negatives) {
                    continue;
                }
                Mask choices = 0;
                for (Mask other : vertices) {
                    if (!(other & (root | a) & negatives)) {
                        choices |= other;
                    }
                }
                const Mask rows = (root & b) | ((a | root) & choices);
                add(marker | unsigned(common | (rows & low)));
            }
        };
        include(d, e);
        include(e, d);
    }

    bool passes_relaxation(Mask d, Mask e, const std::vector<PlainOperand>& untagged) {
        std::vector<unsigned> terms = exact.relevant;
        const auto add = [&terms](unsigned term) {
            if (term && std::find(terms.begin(), terms.end(), term) == terms.end()) {
                terms.push_back(term);
            }
        };
        for (const auto& other : untagged) {
            const unsigned ordinary = unsigned(other.word & other.largest_compatible & low);
            if (!(d & other.word & negatives)) {
                add(ordinary | unsigned(d & other.word & low));
            }
            if (!(e & other.word & negatives)) {
                add(ordinary | unsigned(e & other.word & low));
            }
            if (!((d | e) & other.word & negatives)) {
                add(ordinary | unsigned((d | e) & other.word & low) | (1u << 16));
            }
        }
        if (disjoint_tags) {
            split_envelope(d, e, add);
        }
        int gain = 0;
        for (unsigned word : terms) {
            gain += std::popcount(word) - 1;
        }
        if (gain < 17 - cover_limit) {
            return false;
        }
        for (unsigned i = 0; i < 16; ++i) {
            add(1u << i);
        }
        std::vector<unsigned> maximal;
        for (unsigned a : terms) {
            if (std::none_of(terms.begin(), terms.end(), [a](unsigned b) {
                    return a != b && (a & b) == a;
                })) {
                maximal.push_back(a);
            }
        }
        ++relaxed_cover_checks;
        std::vector<unsigned> chain;
        std::unordered_map<unsigned, int> impossible;
        return cover(maximal, target, cover_limit, impossible, chain);
    }

    bool usable_tagged_word(Mask candidate, Mask d, Mask e) {
        if (largest_compatible(candidate)) {
            return true;
        }
        if (!disjoint_tags) {
            return false;
        }
        const Mask markers = candidate & (tag_d | tag_e);
        return (markers == tag_d && !(candidate & e & negatives))
            || (markers == tag_e && !(candidate & d & negatives));
    }

    bool tagged_search(Mask d, Mask e, std::vector<Mask>& wires, int remaining,
                       bool merged, Mask after) {
        constexpr Mask flags = tag_d | tag_e;
        if (merged && exact.inspect(d, e, wires)) {
            return true;
        }
        if (!remaining) {
            return false;
        }
        if (remaining == 1 && !merged && !after) {
            const Mask candidate = d | e | flags;
            if (!largest_compatible(candidate)) {
                return false;
            }
            exact.append(wires, candidate);
            const bool succeeds = exact.inspect(d, e, wires);
            exact.pop(wires);
            return succeeds;
        }
        for (Mask candidate : unions(wires, true, after)) {
            const bool both = (candidate & flags) == flags;
            if ((remaining == 1 && !merged && !both) || !usable_tagged_word(candidate, d, e)) {
                continue;
            }
            exact.append(wires, candidate);
            if (tagged_search(d, e, wires, remaining - 1, merged || both, candidate)) {
                return true;
            }
            exact.pop(wires);
        }
        return false;
    }

    bool inspect(const std::vector<Mask>& plain) {
        std::vector<PlainOperand> untagged;
        std::vector<Mask> wires;
        std::map<Mask, JunkOperand> junk;
        for (Mask w : plain) {
            exact.append(wires, w);
            untagged.push_back(study(w));
        }
        for (std::size_t i = 0; i < plain.size(); ++i) {
            for (std::size_t j = i; j < plain.size(); ++j) {
                const Mask word = plain[i] & plain[j];
                if (word & negatives) {
                    auto it = junk.find(word);
                    if (it == junk.end()) {
                        const auto data = study(word);
                        if (!disjoint_tags && !data.largest_compatible) {
                            continue;
                        }
                        it = junk.emplace(word, JunkOperand{
                            data, 0, 100, std::binary_search(plain.begin(), plain.end(), word)
                        }).first;
                    }
                    if (apply_graph_charges) {
                        const auto& x = untagged[i];
                        const auto& y = untagged[j];
                        auto& tag = it->second;
                        if (word != x.word) {
                            tag.star_centers |= x.equal_roots;
                        }
                        if (word != y.word) {
                            tag.star_centers |= y.equal_roots;
                        }
                        const int heads = std::popcount(x.contained_roots & y.compatible_roots)
                                        + std::popcount(y.contained_roots & x.compatible_roots);
                        tag.repair_heads = std::min(tag.repair_heads, heads);
                    }
                }
            }
        }
        for (auto i = junk.begin(); i != junk.end(); ++i) {
            const auto& [d, first] = *i;
            const int available = or_limit - int(plain.size() - vertices.size());
            exact.append(wires, d | tag_d);
            for (auto j = i; j != junk.end(); ++j) {
                const auto& [e, second] = *j;
                if (disjoint_tags ? bool(d & e & negatives)
                    : (!(d & e & negatives) || !(first.shape.compatible_roots & second.shape.compatible_roots))) {
                    continue;
                }
                ++dirty_pairs;
                Mask possible_omissions = (d & first.shape.largest_compatible & low)
                    | (e & second.shape.largest_compatible & low);
                if (disjoint_tags) {
                    possible_omissions |= d & e & low;
                }
                if (std::popcount(possible_omissions) <= 2) {
                    ++at_most_two_omissions;
                    continue;
                }
                if (apply_graph_charges
                    && ((first.mirror && second.mirror)
                        || (first.mirror && std::popcount(e & low) <= 1)
                        || (second.mirror && std::popcount(d & low) <= 1)
                        || (first.shape.equal_roots && second.star_centers)
                        || (second.shape.equal_roots && first.star_centers)
                        || (first.star_centers & second.star_centers)
                        || (!disjoint_tags && !(first.shape.contained_roots | second.shape.contained_roots)
                            && first.repair_heads + second.repair_heads <= 2))) {
                    ++other_proven_profiles;
                    continue;
                }
                exact.append(wires, e | tag_e);
                if (available == 1 || passes_relaxation(d, e, untagged)) {
                    ++relaxed_pairs;
                    if (tagged_search(d, e, wires, available, disjoint_tags, 0)) {
                        return true;
                    }
                }
                exact.pop(wires);
            }
            exact.pop(wires);
        }
        while (!wires.empty()) {
            exact.pop(wires);
        }
        return false;
    }
};

struct PlainFamilySearch {
    OverlapSearch search;
    std::size_t scanned = 0;

    bool descend(std::vector<Mask>& family, int remaining, Mask highest) {
        if (!remaining) {
            ++scanned;
            return search.inspect(family);
        }
        for (Mask next : unions(family, false, highest)) {
            const std::size_t index = std::lower_bound(family.begin(), family.end(), next) - family.begin();
            family.insert(family.begin() + index, next);
            if (descend(family, remaining - 1, next)) {
                return true;
            }
            family.erase(family.begin() + index);
        }
        return false;
    }
};

int main(int argc, char** argv) {
    const int plain_gates = argc >= 2 ? std::stoi(argv[1]) : 1;
    const auto first = argc >= 3 ? std::stoul(argv[2]) : 0;
    const auto last = argc >= 4 ? std::stoul(argv[3]) : std::numeric_limits<std::size_t>::max();
    if (plain_gates < 0 || plain_gates > 5 || last < first) {
        return 2;
    }
    std::vector<Mask> roots = vertices;
    std::sort(roots.begin(), roots.end());
    const std::string_view mode = argc >= 5 ? argv[4] : "";
    OverlapSearch search;
    search.apply_graph_charges = mode == "charges" || mode == "stream" || mode == "safe-stream";
    std::size_t index = 0, scanned = 0;
    if (mode == "stream" || mode == "safe-stream") {
        PlainFamilySearch stream;
        stream.search.apply_graph_charges = true;
        stream.search.disjoint_tags = mode == "safe-stream";
        if (!plain_gates) {
            if (stream.descend(roots, 0, 0)) {
                return 1;
            }
        } else {
            const auto first_unions = unions(roots, false);
            for (Mask next : first_unions) {
                const auto i = index++;
                if (i < first || i >= last) {
                    continue;
                }
                auto family = roots;
                family.insert(std::lower_bound(family.begin(), family.end(), next), next);
                const std::size_t earlier = stream.scanned;
                if (stream.descend(family, plain_gates - 1, next)) {
                    return 1;
                }
                if (stream.search.disjoint_tags) {
                    std::cout << "completed first union index " << i << ", untagged families "
                              << stream.scanned - earlier << std::endl;
                }
            }
        }
        scanned = stream.scanned;
        search = std::move(stream.search);
    } else {
        if (plain_gates > 3) {
            return 2;
        }
        std::set<std::vector<Mask>> families{roots};
        for (int nodes = 0; nodes < plain_gates; ++nodes) {
            std::set<std::vector<Mask>> next;
            for (const auto& old : families) {
                for (Mask value : unions(old, false)) {
                    auto child = old;
                    child.insert(std::lower_bound(child.begin(), child.end(), value), value);
                    next.insert(std::move(child));
                }
            }
            families = std::move(next);
        }
        for (const auto& plain : families) {
            if (const auto i = index++; i >= first && i < last) {
                ++scanned;
                if (search.inspect(plain)) {
                    return 1;
                }
            }
        }
    }
    std::cout << "ungated families " << scanned << ", quiet profiles " << search.at_most_two_omissions
              << ", candidate profiles " << search.dirty_pairs << ", relaxed cover checks "
              << search.relaxed_cover_checks << ", relaxed covers " << search.relaxed_pairs
              << ", exact tagged families " << search.exact.families
              << ", exact cover checks " << search.exact.covers_checked << ", other proved profiles "
              << search.other_proven_profiles << '\n';
    return 0;
}
