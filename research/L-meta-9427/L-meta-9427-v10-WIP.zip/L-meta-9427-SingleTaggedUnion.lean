import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem singleTaggedUnionIsMerge (d e : Finset ℕ) (D : Finset (Finset ℕ))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (budget : ((D \ markedSeeds d e).filter carriesTag).card ≤ 1)
    (w : Finset ℕ) (hw : w ∈ D) (p : 40 ∈ w) (q : 41 ∈ w) :
    w = insert 40 d ∪ insert 41 e := by
  have outsideP : 40 ∉ actualRows := by decide
  have outsideQ : 41 ∉ actualRows := by decide
  have rawTag (x : Finset ℕ) (hx : x ∈ markedSeeds d e) (hp : 40 ∈ x) :
      x = insert 40 d := by
    simp only [markedSeeds, Finset.mem_insert] at hx
    rcases hx with rfl | rfl | ordinary
    · rfl
    · rcases Finset.mem_insert.mp hp with eq | found
      · omega
      · exact (outsideP (eRows found)).elim
    · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp ordinary
      exact (outsideP (rootRowsBound u hp)).elim
  have otherTag (x : Finset ℕ) (hx : x ∈ markedSeeds d e) (hq : 41 ∈ x) :
      x = insert 41 e := by
    simp only [markedSeeds, Finset.mem_insert] at hx
    rcases hx with rfl | rfl | ordinary
    · rcases Finset.mem_insert.mp hq with eq | found
      · omega
      · exact (outsideQ (dRows found)).elim
    · rfl
    · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp ordinary
      exact (outsideQ (rootRowsBound u hq)).elim
  have paid : w ∉ markedSeeds d e := by
    intro wh
    exact (eraseSeedFacts d e dRows eRows w wh).choose_spec.2.2.2 ⟨p, q⟩
  have costs : w ∈ (D \ markedSeeds d e).filter carriesTag :=
    Finset.mem_filter.mpr ⟨Finset.mem_sdiff.mpr ⟨hw, paid⟩, Or.inl p⟩
  obtain ⟨a, ha, b, hb, aw, bw, joined⟩ := build w hw paid
  have taggedChild (x : Finset ℕ) (hx : x ∈ D) (inside : x ⊂ w) (tag : carriesTag x) :
      x ∈ markedSeeds d e := by
    by_contra costly
    have paidX : x ∈ (D \ markedSeeds d e).filter carriesTag :=
      Finset.mem_filter.mpr ⟨Finset.mem_sdiff.mpr ⟨hx, costly⟩, tag⟩
    exact (Finset.ssubset_iff_subset_ne.mp inside).2
      (Finset.card_le_one.mp budget x paidX w costs)
  have onlyOneTag (x : Finset ℕ) (hx : x ∈ D) (inside : x ⊂ w) :
      ¬(40 ∈ x ∧ 41 ∈ x) := by
    rintro ⟨p, q⟩
    have seed := taggedChild x hx inside (Or.inl p)
    exact (eraseSeedFacts d e dRows eRows x seed).choose_spec.2.2.2 ⟨p, q⟩
  have eitherP : 40 ∈ a ∨ 40 ∈ b := Finset.mem_union.mp (joined ▸ p)
  have eitherQ : 41 ∈ a ∨ 41 ∈ b := Finset.mem_union.mp (joined ▸ q)
  rcases eitherP with pa | pb <;> rcases eitherQ with qa | qb
  · exact (onlyOneTag a ha aw ⟨pa, qa⟩).elim
  · rw [joined, rawTag a (taggedChild a ha aw (Or.inl pa)) pa,
      otherTag b (taggedChild b hb bw (Or.inr qb)) qb]
  · rw [joined, rawTag b (taggedChild b hb bw (Or.inl pb)) pb,
      otherTag a (taggedChild a ha aw (Or.inr qa)) qa, Finset.union_comm]
  · exact (onlyOneTag b hb bw ⟨pb, qb⟩).elim

end PEqualNP.Outside.L_meta_9427
