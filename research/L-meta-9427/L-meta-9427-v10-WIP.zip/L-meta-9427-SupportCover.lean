import Mathlib

namespace PEqualNP.Outside.L_meta_9427

structure CoverOperand where
  support : Finset (Fin 11)
  firstTag : Bool
  secondTag : Bool
  deriving DecidableEq

def operandRows (d e : Finset ℕ) (w : CoverOperand) : Finset ℕ :=
  rowsOf w.support ∪ (if w.firstTag then d else ∅) ∪ (if w.secondTag then e else ∅)

def supportedTerm (d e : Finset ℕ) (g : CoverOperand × CoverOperand) : Finset ℕ :=
  operandRows d e g.1 ∩ operandRows d e g.2 ∪
    if (g.1.firstTag || g.2.firstTag) && (g.1.secondTag || g.2.secondTag)
    then {40} else ∅

def selectOperand (label : Finset ℕ → Finset (Fin 11)) (w : Finset ℕ) : CoverOperand :=
  ⟨label w, decide (40 ∈ w), decide (41 ∈ w)⟩

private theorem selectedOperandRows (d e w : Finset ℕ)
    (label : Finset ℕ → Finset (Fin 11)) (shape : projectionFacts d e ∅ ∅ w (label w))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows) :
    operandRows d e (selectOperand label w) = w ∩ actualRows := by
  classical
  have plain (x : ℕ) (h : x ∈ rowsOf (label w)) : x ∈ w ∩ actualRows := by
    obtain ⟨u, _, root⟩ := Finset.mem_biUnion.mp h
    exact Finset.mem_inter.mpr ⟨shape.1 h, rootRowsBound u root⟩
  ext x
  constructor
  · intro included
    rcases Finset.mem_union.mp included with p | q
    · rcases Finset.mem_union.mp p with keep | useD
      · exact plain x keep
      · by_cases flag : 40 ∈ w
        · have atD : x ∈ d := by simpa [selectOperand, flag] using useD
          exact Finset.mem_inter.mpr ⟨(shape.2.1 flag).1 atD, dRows atD⟩
        · simp [selectOperand, flag] at useD
    · by_cases flag : 41 ∈ w
      · have atE : x ∈ e := by simpa [selectOperand, flag] using q
        exact Finset.mem_inter.mpr ⟨(shape.2.2.1 flag).1 atE, eRows atE⟩
      · simp [selectOperand, flag] at q
  · intro actual
    obtain ⟨inW, inside⟩ := Finset.mem_inter.mp actual
    rcases shape.2.2.2 x inW inside with ordinary | ⟨flag, atD⟩ | ⟨flag, atE⟩
    · exact Finset.mem_union.mpr (Or.inl (Finset.mem_union.mpr (Or.inl ordinary)))
    · exact Finset.mem_union.mpr (Or.inl (Finset.mem_union.mpr (Or.inr
        (by simpa [selectOperand, flag] using atD))))
    · exact Finset.mem_union.mpr (Or.inr (by simpa [selectOperand, flag] using atE))

private theorem selectedSupportTerm (d e a b : Finset ℕ)
    (label : Finset ℕ → Finset (Fin 11))
    (fa : projectionFacts d e ∅ ∅ a (label a)) (fb : projectionFacts d e ∅ ∅ b (label b))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows) :
    supportedTerm d e (selectOperand label a, selectOperand label b) = productTerm a b := by
  have flag :
      (((selectOperand label a).firstTag || (selectOperand label b).firstTag) &&
        ((selectOperand label a).secondTag || (selectOperand label b).secondTag)) = true ↔
      {40, 41} ⊆ a ∪ b := by
    simp [selectOperand, Bool.and_eq_true, Bool.or_eq_true, Finset.insert_subset_iff,
      Finset.singleton_subset_iff, Finset.mem_union]
  unfold supportedTerm productTerm
  dsimp only
  rw [if_congr flag rfl rfl,
    selectedOperandRows d e a label fa dRows eRows,
    selectedOperandRows d e b label fb dRows eRows]
  ext r
  simp only [Finset.mem_union, Finset.mem_inter]
  tauto

private theorem supportCoverFromFamily (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dFrom : ∃ a ∈ D, ∃ b ∈ D, a ⊆ actualRows ∧ b ⊆ actualRows ∧ d = a ∩ b)
    (eFrom : ∃ a ∈ D, ∃ b ∈ D, a ⊆ actualRows ∧ b ⊆ actualRows ∧ e = a ∩ b)
    (build : ∀ t ∈ D, t ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ t ∧ b ⊂ t ∧ t = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows) :
    ∃ (S T X Y : Finset (Fin 11)) (G : Finset (CoverOperand × CoverOperand)),
      d = rowsOf S ∩ rowsOf T ∧ e = rowsOf X ∩ rowsOf Y ∧
      G.card = B.card ∧ G.image (supportedTerm d e) = B := by
  classical
  obtain ⟨p, pD, q, qD, pRows, qRows, dEq⟩ := dFrom
  obtain ⟨r, rD, s, sD, rRows, sRows, eEq⟩ := eFrom
  have dRows : d ⊆ actualRows := by rw [dEq]; exact Finset.inter_subset_left.trans pRows
  have eRows : e ⊆ actualRows := by rw [eEq]; exact Finset.inter_subset_left.trans rRows
  obtain ⟨label, replay, _, _⟩ := projectionWithSmallSeedImages d e D ∅ ∅ dRows eRows
    (by simp) (by simp) (by simp [rowsOf]) (by simp [rowsOf]) build
  have roots (x y tag : Finset ℕ) (xD : x ∈ D) (yD : y ∈ D)
      (xRows : x ⊆ actualRows) (yRows : y ⊆ actualRows) (eq : tag = x ∩ y) :
      tag = rowsOf (label x) ∩ rowsOf (label y) :=
    eq.trans (congrArg₂ (· ∩ ·) (untaggedRows d e x ∅ ∅ (label x) (replay x xD) xRows)
      (untaggedRows d e y ∅ ∅ (label y) (replay y yD) yRows))
  have fromTerm (t : Finset ℕ) (ht : t ∈ B) :
      ∃ g : CoverOperand × CoverOperand, supportedTerm d e g = t := by
    obtain ⟨a, aD, b, bD, eq, _⟩ := pairs t ht
    exact ⟨(selectOperand label a, selectOperand label b),
      (selectedSupportTerm d e a b label (replay a aD) (replay b bD) dRows eRows).trans eq.symm⟩
  let pick (t : Finset ℕ) : CoverOperand × CoverOperand :=
    if h : t ∈ B then (fromTerm t h).choose else (⟨∅, false, false⟩, ⟨∅, false, false⟩)
  have picked (t : Finset ℕ) (ht : t ∈ B) : supportedTerm d e (pick t) = t := by
    simpa [pick, ht] using (fromTerm t ht).choose_spec
  let G := B.image pick
  have injective : Set.InjOn pick (B : Set (Finset ℕ)) :=
    fun a ha b hb h => (picked a ha).symm.trans ((congrArg (supportedTerm d e) h).trans (picked b hb))
  refine ⟨label p, label q, label r, label s, G, roots p q d pD qD pRows qRows dEq,
    roots r s e rD sD rRows sRows eEq, Finset.card_image_of_injOn injective, ?_⟩
  ext t
  constructor
  · intro model
    obtain ⟨g, hg, rfl⟩ := Finset.mem_image.mp model
    obtain ⟨q, hq, rfl⟩ := Finset.mem_image.mp hg
    rw [picked q hq]
    exact hq
  · intro h
    exact Finset.mem_image.mpr ⟨pick t, Finset.mem_image_of_mem _ h, picked t h⟩

end PEqualNP.Outside.L_meta_9427
