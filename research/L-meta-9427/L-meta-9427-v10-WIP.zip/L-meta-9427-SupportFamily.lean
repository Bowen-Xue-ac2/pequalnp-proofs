import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private def sourceWord (d e : Finset ℕ) (i : Fin 13) : Finset ℕ :=
  if before : i.val < 11 then rootSet ⟨i.val, before⟩
  else if i.val = 11 then insert 40 d else insert 41 e

private def supportRows (d e : Finset ℕ) (s : Finset (Fin 13)) : Finset ℕ :=
  s.biUnion (sourceWord d e)

private theorem sourceWordsAreSeeds (d e : Finset ℕ) :
    Finset.univ.image (sourceWord d e) = markedSeeds d e := by
  ext w
  constructor
  · intro fromIndex
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp fromIndex
    by_cases root : i.val < 11
    · simp only [sourceWord, dif_pos root]
      exact Finset.mem_insert_of_mem (Finset.mem_insert_of_mem (Finset.mem_image_of_mem _ (Finset.mem_univ _)))
    · by_cases first : i.val = 11
      · simp [sourceWord, root, first, markedSeeds]
      · simp [sourceWord, root, first, markedSeeds]
  · intro seed
    simp only [markedSeeds, Finset.mem_insert] at seed
    rcases seed with rfl | rfl | fromRoot
    · exact Finset.mem_image.mpr ⟨(11 : Fin 13), Finset.mem_univ _, rfl⟩
    · exact Finset.mem_image.mpr ⟨(12 : Fin 13), Finset.mem_univ _, rfl⟩
    · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp fromRoot
      exact Finset.mem_image.mpr ⟨⟨u.val, u.isLt.trans (by decide)⟩, Finset.mem_univ _,
        by simp [sourceWord, u.isLt]⟩

private theorem labelByThirteenSources (d e : Finset ℕ) (D : Finset (Finset ℕ))
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) :
    ∃ label : Finset ℕ → Finset (Fin 13),
      (∀ w ∈ D, supportRows d e (label w) = w) ∧
      (∀ w ∈ D, (label w).card = 1 ↔ w ∈ markedSeeds d e) ∧
      Set.InjOn label (D : Set (Finset ℕ)) ∧
      (∀ w ∈ D, w ∉ markedSeeds d e →
        ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ label a ⊂ label w ∧ label b ⊂ label w ∧
          label w = label a ∪ label b) := by
  classical
  let X := markedSeeds d e
  have witness (w : Finset ℕ) (hw : w ∈ X) : ∃ i : Fin 13, sourceWord d e i = w := by
    change w ∈ markedSeeds d e at hw
    rw [← sourceWordsAreSeeds] at hw
    obtain ⟨i, _, eq⟩ := Finset.mem_image.mp hw
    exact ⟨i, eq⟩
  let seed (w : Finset ℕ) : Finset (Fin 13) :=
    if h : w ∈ X then {(witness w h).choose} else ∅
  obtain ⟨label, rooted, gate⟩ := labelUnionFamily D X seed build
  have singleton (w : Finset ℕ) (wD : w ∈ D) (wX : w ∈ X) :
      label w = {(witness w wX).choose} := by rw [rooted w wD wX]; simp [seed, wX]
  have value (w : Finset ℕ) (hw : w ∈ D) : supportRows d e (label w) = w := by
    induction hn : w.card using Nat.strong_induction_on generalizing w with
    | ind n earlier =>
      by_cases seedWord : w ∈ X
      · rw [singleton w hw seedWord]
        simpa [supportRows] using (witness w seedWord).choose_spec
      · obtain ⟨a, aD, b, bD, aSub, bSub, eq, words⟩ := gate w hw seedWord
        have aEarlier : a.card < n := hn ▸ Finset.card_lt_card aSub
        have bEarlier : b.card < n := hn ▸ Finset.card_lt_card bSub
        calc
          supportRows d e (label w) = supportRows d e (label a) ∪ supportRows d e (label b) := by
            rw [words]; simp [supportRows, Finset.union_biUnion]
          _ = a ∪ b := by rw [earlier a.card aEarlier a aD rfl, earlier b.card bEarlier b bD rfl]
          _ = w := eq.symm
  have inj : Set.InjOn label (D : Set (Finset ℕ)) := by
    intro a aD b bD eq
    exact (value a aD).symm.trans ((congrArg (supportRows d e) eq).trans (value b bD))
  refine ⟨label, value, ?_, inj, ?_⟩
  · intro w wD
    constructor
    · intro one
      obtain ⟨i, found⟩ := Finset.card_eq_one.mp one
      have wEq : sourceWord d e i = w := by simpa [found, supportRows] using value w wD
      rw [← sourceWordsAreSeeds]
      exact Finset.mem_image.mpr ⟨i, Finset.mem_univ _, wEq⟩
    · intro h
      simp [singleton w wD h]
  · intro w wD wX
    obtain ⟨a, aD, b, bD, aSub, bSub, _, eq⟩ := gate w wD wX
    refine ⟨a, aD, b, bD, aSub, bSub, ?_, ?_, eq⟩
    · exact Finset.ssubset_iff_subset_ne.mpr
        ⟨eq.symm ▸ Finset.subset_union_left, fun same =>
          (Finset.ssubset_iff_subset_ne.mp aSub).2 (inj aD wD same)⟩
    · exact Finset.ssubset_iff_subset_ne.mpr
        ⟨eq.symm ▸ Finset.subset_union_right, fun same =>
          (Finset.ssubset_iff_subset_ne.mp bSub).2 (inj bD wD same)⟩

private theorem supportedUnionFamilyCost (d e : Finset ℕ) (D : Finset (Finset ℕ))
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) :
    ∃ S : Finset (Finset (Fin 13)),
      S.image (supportRows d e) = D ∧
      (S.filter fun s => s.card ≠ 1).card = (D \ markedSeeds d e).card ∧
      (∀ s ∈ S, s.card ≠ 1 → ∃ a ∈ S, ∃ b ∈ S, a ⊂ s ∧ b ⊂ s ∧ s = a ∪ b) := by
  obtain ⟨label, values, one, injective, valid⟩ := labelByThirteenSources d e D build
  let S := D.image label
  refine ⟨S, ?_, ?_, ?_⟩
  · ext w
    constructor
    · intro hw
      obtain ⟨s, hs, rfl⟩ := Finset.mem_image.mp hw
      obtain ⟨a, ha, rfl⟩ := Finset.mem_image.mp hs
      rwa [values a ha]
    · intro wD
      exact Finset.mem_image.mpr ⟨label w, Finset.mem_image_of_mem _ wD, values w wD⟩
  · have paid : (S.filter fun s => s.card ≠ 1) = (D \ markedSeeds d e).image label := by
      ext s
      constructor
      · intro hs
        obtain ⟨inS, plural⟩ := Finset.mem_filter.mp hs
        obtain ⟨w, wD, rfl⟩ := Finset.mem_image.mp inS
        exact Finset.mem_image.mpr ⟨w, Finset.mem_sdiff.mpr ⟨wD, fun h => plural ((one w wD).2 h)⟩, rfl⟩
      · intro hs
        obtain ⟨w, wPaid, rfl⟩ := Finset.mem_image.mp hs
        obtain ⟨wD, notSeed⟩ := Finset.mem_sdiff.mp wPaid
        exact Finset.mem_filter.mpr ⟨Finset.mem_image_of_mem _ wD, fun h => notSeed ((one w wD).1 h)⟩
    rw [paid, Finset.card_image_of_injOn]
    intro w wPaid q qPaid eq
    exact injective (Finset.mem_sdiff.mp wPaid).1 (Finset.mem_sdiff.mp qPaid).1 eq
  · intro s hs plural
    obtain ⟨w, wD, rfl⟩ := Finset.mem_image.mp hs
    have notSeed : w ∉ markedSeeds d e := fun h => plural ((one w wD).2 h)
    obtain ⟨a, aD, b, bD, _, _, la, lb, eq⟩ := valid w wD notSeed
    exact ⟨label a, Finset.mem_image_of_mem _ aD, label b, Finset.mem_image_of_mem _ bD, la, lb, eq⟩

end PEqualNP.Outside.L_meta_9427

