import Mathlib

namespace PEqualNP.Outside.L_meta_9427

noncomputable def redundantUnions (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11)) : Finset (Finset ℕ) := by
  classical
  exact (D \ X).filter fun w => ∃ a ∈ D, a ⊂ w ∧ label a = label w

private theorem redundantIff (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11)) (w : Finset ℕ) :
    w ∈ redundantUnions D X label ↔
      w ∈ D \ X ∧ ∃ a ∈ D, a ⊂ w ∧ label a = label w := by
  classical
  simp [redundantUnions]

private theorem projectionUnionDeficit (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11))
    (root : ∀ w ∈ D, w ∈ X → (label w).card ≤ 1) :
    ((D.image label).filter (fun w => 1 < w.card)).card +
      (redundantUnions D X label).card ≤ (D \ X).card := by
  classical
  let redundant := redundantUnions D X label
  have sub : ((D.image label).filter fun w => 1 < w.card) ⊆
      ((D \ X) \ redundant).image label := by
    intro s hs
    obtain ⟨included, big⟩ := Finset.mem_filter.mp hs
    obtain ⟨w, hw, eq⟩ := Finset.mem_image.mp included
    let candidates := D.filter fun t => label t = s
    have any : candidates.Nonempty := ⟨w, Finset.mem_filter.mpr ⟨hw, eq⟩⟩
    obtain ⟨q, hq, minQ⟩ := Finset.exists_min_image candidates Finset.card any
    obtain ⟨qD, qEq⟩ := Finset.mem_filter.mp hq
    have qX : q ∉ X := by
      intro hX
      have small := root q qD hX
      rw [qEq] at small
      exact (Nat.not_le_of_gt big) small
    have qNew : q ∉ redundant := by
      intro discarded
      obtain ⟨_, a, ha, smaller, same⟩ := (redundantIff D X label q).mp discarded
      have aCand : a ∈ candidates := Finset.mem_filter.mpr ⟨ha, same.trans qEq⟩
      exact (Nat.not_lt_of_ge (minQ a aCand)) (Finset.card_lt_card smaller)
    exact Finset.mem_image.mpr ⟨q,
      Finset.mem_sdiff.mpr ⟨Finset.mem_sdiff.mpr ⟨qD, qX⟩, qNew⟩, qEq⟩
  have counted := (Finset.card_le_card sub).trans Finset.card_image_le
  have valid : redundant ⊆ D \ X := by
    intro s hs
    exact ((redundantIff D X label s).mp hs).1
  have equation := Finset.card_sdiff_add_card_eq_card valid
  change ((D.image label).filter (fun w => 1 < w.card)).card + redundant.card ≤ (D \ X).card
  omega

private theorem firstTaggedUnion (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11)) (tag : ℕ)
    (roots : ∀ w ∈ D, w ∈ X → tag ∈ w → label w = ∅)
    (build : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b ∧ label w = label a ∪ label b) :
    ∀ w ∈ D, tag ∈ w → (label w).Nonempty →
      ∃ t ∈ redundantUnions D X label, t ⊆ w ∧ tag ∈ t := by
  intro w hw ht real
  induction hsize : w.card using Nat.strong_induction_on generalizing w with
  | ind n ih =>
    by_cases seed : w ∈ X
    · rw [roots w hw seed ht] at real
      exact (Finset.not_nonempty_empty real).elim
    obtain ⟨a, ha, b, hb, haSub, hbSub, raw, eq⟩ := build w hw seed
    have visit (child other : Finset ℕ) (hc : child ∈ D) (ho : other ∈ D)
        (hcSub : child ⊂ w) (hoSub : other ⊂ w) (inChild : tag ∈ child)
        (tagUnion : label w = label child ∪ label other) :
        ∃ t ∈ redundantUnions D X label, t ⊆ w ∧ tag ∈ t := by
      by_cases live : (label child).Nonempty
      · have smaller : child.card < n := by
          rw [← hsize]
          exact Finset.card_lt_card hcSub
        obtain ⟨t, ht, ts, tp⟩ := ih child.card smaller child hc inChild live rfl
        exact ⟨t, ht, ts.trans hcSub.1, tp⟩
      · have empty : label child = ∅ := Finset.not_nonempty_iff_eq_empty.mp live
        have sameLabel : label other = label w := by rw [tagUnion, empty, Finset.empty_union]
        have counted : w ∈ redundantUnions D X label :=
          (redundantIff D X label w).mpr
            ⟨Finset.mem_sdiff.mpr ⟨hw, seed⟩, other, ho, hoSub, sameLabel⟩
        exact ⟨w, counted, Finset.Subset.rfl, ht⟩
    have choice : tag ∈ a ∨ tag ∈ b := Finset.mem_union.mp (raw ▸ ht)
    rcases choice with h | h
    · exact visit a b ha hb haSub hbSub h eq
    · exact visit b a hb ha hbSub haSub h (by rw [eq, Finset.union_comm])

private theorem redundantEmptyDoubleTag (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11))
    (noDoubleSeed : ∀ w ∈ D, w ∈ X → ¬(40 ∈ w ∧ 41 ∈ w))
    (build : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b ∧ label w = label a ∪ label b)
    (w : Finset ℕ) (hw : w ∈ D) (h40 : 40 ∈ w) (h41 : 41 ∈ w) (empty : label w = ∅) :
    w ∈ redundantUnions D X label := by
  have seed : w ∉ X := fun h => noDoubleSeed w hw h ⟨h40, h41⟩
  obtain ⟨a, ha, b, hb, haSub, _, _, eq⟩ := build w hw seed
  have aLe : label a ⊆ label w := by rw [eq]; exact Finset.subset_union_left
  have same : label a = label w := by
    apply Finset.Subset.antisymm aLe
    rw [empty]
    exact Finset.empty_subset _
  exact (redundantIff D X label w).mpr
    ⟨Finset.mem_sdiff.mpr ⟨hw, seed⟩, a, ha, haSub, same⟩

def carriesTag (w : Finset ℕ) : Prop := 40 ∈ w ∨ 41 ∈ w

instance (w : Finset ℕ) : Decidable (carriesTag w) := by
  unfold carriesTag
  infer_instance

noncomputable def redundantTaggedUnions (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11)) : Finset (Finset ℕ) :=
  (redundantUnions D X label).filter carriesTag

private theorem splitTagUnionDeficit (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11))
    (roots : ∀ w ∈ D, w ∈ X → carriesTag w → label w = ∅)
    (build : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b ∧ label w = label a ∪ label b)
    (a b : Finset ℕ) (ha : a ∈ D) (hb : b ∈ D)
    (p : 40 ∈ a) (q : 41 ∈ b) (noP : 40 ∉ b)
    (aLive : (label a).Nonempty) (bLive : (label b).Nonempty) :
    2 ≤ (redundantTaggedUnions D X label).card := by
  obtain ⟨u, hu, _, pu⟩ := firstTaggedUnion D X label 40
    (fun w hw hx tag => roots w hw hx (Or.inl tag)) build a ha p aLive
  obtain ⟨v, hv, vb, qv⟩ := firstTaggedUnion D X label 41
    (fun w hw hx tag => roots w hw hx (Or.inr tag)) build b hb q bLive
  have distinct : u ≠ v := fun eq => noP (vb (eq ▸ pu))
  have count : 1 < (redundantTaggedUnions D X label).card := Finset.one_lt_card.mpr
    ⟨u, Finset.mem_filter.mpr ⟨hu, Or.inl pu⟩, v,
      Finset.mem_filter.mpr ⟨hv, Or.inr qv⟩, distinct⟩
  omega

private theorem doubleTagUnionTaggedDeficit (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11))
    (roots : ∀ w ∈ D, w ∈ X →
      ((40 ∈ w ∨ 41 ∈ w) → label w = ∅) ∧ ¬(40 ∈ w ∧ 41 ∈ w))
    (build : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b ∧ label w = label a ∪ label b)
    (w₀ : Finset ℕ) (hw₀ : w₀ ∈ D) (h₀40 : 40 ∈ w₀) (h₀41 : 41 ∈ w₀)
    (live₀ : (label w₀).Nonempty) :
    2 ≤ (redundantTaggedUnions D X label).card := by
  classical
  let double := D.filter fun w => 40 ∈ w ∧ 41 ∈ w ∧ (label w).Nonempty
  have existsDouble : double.Nonempty := ⟨w₀, Finset.mem_filter.mpr ⟨hw₀, h₀40, h₀41, live₀⟩⟩
  obtain ⟨w, found, shortest⟩ := Finset.exists_min_image double Finset.card existsDouble
  obtain ⟨hw, h40, h41, live⟩ := Finset.mem_filter.mp found
  have seed : w ∉ X := fun h => (roots w hw h).2 ⟨h40, h41⟩
  obtain ⟨a, ha, b, hb, haSub, hbSub, raw, eq⟩ := build w hw seed
  have tooSmall (u : Finset ℕ) (hu : u ∈ D) (proper : u ⊂ w)
      (active : (label u).Nonempty) : ¬(40 ∈ u ∧ 41 ∈ u) := by
    intro tags
    have small := Finset.card_lt_card proper
    have minimal := shortest u (Finset.mem_filter.mpr ⟨hu, tags.1, tags.2, active⟩)
    exact (Nat.not_lt_of_ge minimal) small

  have first (tag : ℕ) (isTag : tag = 40 ∨ tag = 41) (u : Finset ℕ) (hu : u ∈ D)
      (tagIn : tag ∈ u) (active : (label u).Nonempty) :
      ∃ v ∈ redundantUnions D X label, v ⊆ u ∧ tag ∈ v := by
    apply firstTaggedUnion D X label tag _ build u hu tagIn active
    intro v hv seedV tagged
    apply (roots v hv seedV).1
    rcases isTag with rfl | rfl
    · exact Or.inl tagged
    · exact Or.inr tagged
  have two (u v : Finset ℕ) (hu : u ∈ redundantUnions D X label)
      (hv : v ∈ redundantUnions D X label) (uTag : carriesTag u) (vTag : carriesTag v)
      (different : u ≠ v) :
      2 ≤ (redundantTaggedUnions D X label).card := by
    exact Finset.one_lt_card.mpr
      ⟨u, Finset.mem_filter.mpr ⟨hu, uTag⟩, v, Finset.mem_filter.mpr ⟨hv, vTag⟩, different⟩
  have visible (tag : ℕ) (same : tag = 40 ∨ tag = 41) (u : Finset ℕ) (inside : tag ∈ u) :
      carriesTag u := by
    rcases same with rfl | rfl
    · exact Or.inl inside
    · exact Or.inr inside
  have splitLive (u v : Finset ℕ) (hu : u ∈ D) (hv : v ∈ D)
      (uLive : (label u).Nonempty) (vLive : (label v).Nonempty)
      (p q : ℕ) (pTag : p = 40 ∨ p = 41) (qTag : q = 40 ∨ q = 41)
      (pu : p ∈ u) (qv : q ∈ v) (pv : p ∉ v) :
      2 ≤ (redundantTaggedUnions D X label).card := by
    obtain ⟨s, hs, _, sTag⟩ := first p pTag u hu pu uLive
    obtain ⟨t, ht, tSub, tTag⟩ := first q qTag v hv qv vLive
    apply two s t hs ht (visible p pTag s sTag) (visible q qTag t tTag)
    intro eq
    exact pv (tSub (eq ▸ sTag))
  have oneEmpty (u v : Finset ℕ) (hu : u ∈ D) (hv : v ∈ D)
      (uSub : u ⊂ w) (vSub : v ⊂ w) (uLive : (label u).Nonempty) (vEmpty : label v = ∅)
      (wUnion : w = u ∪ v) (supportUnion : label w = label u ∪ label v) :
      2 ≤ (redundantTaggedUnions D X label).card := by
    have uSame : label u = label w := by rw [supportUnion, vEmpty, Finset.union_empty]
    have wRedundant : w ∈ redundantUnions D X label :=
      (redundantIff D X label w).mpr
        ⟨Finset.mem_sdiff.mpr ⟨hw, seed⟩, u, hu, uSub, uSame⟩
    have useTag (p : ℕ) (isTag : p = 40 ∨ p = 41) (present : p ∈ u) :
        2 ≤ (redundantTaggedUnions D X label).card := by
      obtain ⟨t, ht, tSub, tTag⟩ := first p isTag u hu present uLive
      apply two t w ht wRedundant (visible p isTag t tTag) (Or.inl h40)
      intro eq
      have small := Finset.card_lt_card uSub
      have le := Finset.card_le_card tSub
      rw [eq] at le
      omega
    by_cases u40 : 40 ∈ u
    · exact useTag 40 (Or.inl rfl) u40
    by_cases u41 : 41 ∈ u
    · exact useTag 41 (Or.inr rfl) u41
    have v40 : 40 ∈ v := (Finset.mem_union.mp (wUnion ▸ h40)).resolve_left u40
    have v41 : 41 ∈ v := (Finset.mem_union.mp (wUnion ▸ h41)).resolve_left u41
    have vRedundant := redundantEmptyDoubleTag D X label
      (fun v hv hx => (roots v hv hx).2) build v hv v40 v41 vEmpty
    exact two v w vRedundant wRedundant (Or.inl v40) (Or.inl h40) (ne_of_lt vSub)

  by_cases aLive : (label a).Nonempty
  · by_cases bLive : (label b).Nonempty
    · have neitherA := tooSmall a ha haSub aLive
      have neitherB := tooSmall b hb hbSub bLive
      have head40 : 40 ∈ a ∨ 40 ∈ b := Finset.mem_union.mp (raw ▸ h40)
      have head41 : 41 ∈ a ∨ 41 ∈ b := Finset.mem_union.mp (raw ▸ h41)
      rcases head40 with a40 | b40
      · have b41 := head41.resolve_left (fun a41 => neitherA ⟨a40, a41⟩)
        exact splitLive a b ha hb aLive bLive 40 41 (Or.inl rfl) (Or.inr rfl)
          a40 b41 (fun b40 => neitherB ⟨b40, b41⟩)
      · have a41 := head41.resolve_right (fun b41 => neitherB ⟨b40, b41⟩)
        exact splitLive b a hb ha bLive aLive 40 41 (Or.inl rfl) (Or.inr rfl)
          b40 a41 (fun a40 => neitherA ⟨a40, a41⟩)
    · exact oneEmpty a b ha hb haSub hbSub aLive (Finset.not_nonempty_iff_eq_empty.mp bLive) raw eq
  · by_cases bLive : (label b).Nonempty
    · exact oneEmpty b a hb ha hbSub haSub bLive (Finset.not_nonempty_iff_eq_empty.mp aLive)
        (by rw [raw, Finset.union_comm]) (by rw [eq, Finset.union_comm])
    · rw [eq, Finset.not_nonempty_iff_eq_empty.mp aLive, Finset.not_nonempty_iff_eq_empty.mp bLive,
        Finset.empty_union] at live
      exact (Finset.not_nonempty_empty live).elim

private theorem doubleTagUnionDeficit (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11))
    (roots : ∀ w ∈ D, w ∈ X →
      ((40 ∈ w ∨ 41 ∈ w) → label w = ∅) ∧ ¬(40 ∈ w ∧ 41 ∈ w))
    (build : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b ∧ label w = label a ∪ label b)
    (w₀ : Finset ℕ) (hw₀ : w₀ ∈ D) (h₀40 : 40 ∈ w₀) (h₀41 : 41 ∈ w₀)
    (live₀ : (label w₀).Nonempty) :
    2 ≤ (redundantUnions D X label).card := by
  exact (doubleTagUnionTaggedDeficit D X label roots build w₀ hw₀ h₀40 h₀41 live₀).trans
    (Finset.card_le_card (Finset.filter_subset _ _))

end PEqualNP.Outside.L_meta_9427
