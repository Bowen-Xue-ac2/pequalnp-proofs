import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem sourceWordFlags (d e : Finset ℕ)
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows) (i : Fin 13) :
    (40 ∈ sourceWord d e i ↔ i = 11) ∧ (41 ∈ sourceWord d e i ↔ i = 12) := by
  have outside40 : 40 ∉ actualRows := by decide
  have outside41 : 41 ∉ actualRows := by decide
  have d41 : 41 ∉ d := fun h => outside41 (dRows h)
  have e40 : 40 ∉ e := fun h => outside40 (eRows h)
  by_cases ordinary : i.val < 11
  · have unequal41 : i ≠ 12 := fun equal => by
      rw [equal] at ordinary
      exact (by decide : ¬ (12 : Fin 13).val < 11) ordinary
    have unequal40 : i ≠ 11 := fun equal => by
      rw [equal] at ordinary
      exact (by decide : ¬ (11 : Fin 13).val < 11) ordinary
    have no40 : 40 ∉ rootSet ⟨i.val, ordinary⟩ := fun h => outside40 (rootRowsBound _ h)
    have no41 : 41 ∉ rootSet ⟨i.val, ordinary⟩ := fun h => outside41 (rootRowsBound _ h)
    simp [sourceWord, ordinary, unequal40, unequal41, no40, no41]
  by_cases first : i.val = 11
  · have index : i = (11 : Fin 13) := Fin.ext first
    subst i
    simp [sourceWord, d41]
  · have within := i.isLt
    have last : i.val = 12 := by omega
    have index : i = (12 : Fin 13) := Fin.ext last
    subst i
    simp [sourceWord, e40]

private theorem supportRowsFlags (d e : Finset ℕ)
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows) (s : Finset (Fin 13)) :
    (40 ∈ supportRows d e s ↔ (11 : Fin 13) ∈ s) ∧
      (41 ∈ supportRows d e s ↔ (12 : Fin 13) ∈ s) := by
  have flag (r : ℕ) (j : Fin 13) (atSlot : ∀ i : Fin 13, r ∈ sourceWord d e i ↔ i = j) :
      r ∈ supportRows d e s ↔ j ∈ s := by
    constructor
    · intro present
      obtain ⟨i, hs, hit⟩ := Finset.mem_biUnion.mp present
      exact (atSlot i).mp hit ▸ hs
    · intro hs
      exact Finset.mem_biUnion.mpr ⟨j, hs, (atSlot j).mpr rfl⟩
  exact ⟨flag 40 11 (fun i => (sourceWordFlags d e dRows eRows i).1),
    flag 41 12 (fun i => (sourceWordFlags d e dRows eRows i).2)⟩

private theorem untaggedSupportRows (d e : Finset ℕ)
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows) (s : Finset (Fin 13)) :
    supportRows d e s ⊆ actualRows ↔ (11 : Fin 13) ∉ s ∧ (12 : Fin 13) ∉ s := by
  have flags := supportRowsFlags d e dRows eRows s
  constructor
  · intro untagged
    exact ⟨fun h => (show 40 ∉ actualRows by decide) (untagged (flags.1.mpr h)),
      fun h => (show 41 ∉ actualRows by decide) (untagged (flags.2.mpr h))⟩
  · rintro ⟨first, second⟩ r present
    obtain ⟨i, hs, atSource⟩ := Finset.mem_biUnion.mp present
    by_cases root : i.val < 11
    · exact rootRowsBound ⟨i.val, root⟩ (by simpa [sourceWord, root] using atSource)
    · have different : i.val ≠ 11 := by
        intro eq
        have index : i = (11 : Fin 13) := Fin.ext eq
        exact first (index ▸ hs)
      have last : i.val = 12 := by have := i.isLt; omega
      exact (second ((show i = (12 : Fin 13) from Fin.ext last) ▸ hs)).elim

private def supportWeight (s : Finset (Fin 13)) : ℕ :=
  ∑ i ∈ s, 2 ^ i.val

private theorem strictSupportWeight {s t : Finset (Fin 13)} (strict : s ⊂ t) :
    supportWeight s < supportWeight t := by
  obtain ⟨i, inT, outS⟩ := Finset.exists_of_ssubset strict
  have includes : insert i s ⊆ t := Finset.insert_subset_iff.mpr ⟨inT, strict.1⟩
  have bigger : supportWeight s < supportWeight (insert i s) := by
    unfold supportWeight
    rw [Finset.sum_insert outS]
    have positive : 0 < (2 : ℕ) ^ i.val := by positivity
    omega
  refine bigger.trans_le ?_
  exact Finset.sum_le_sum_of_subset_of_nonneg includes (fun _ _ _ => Nat.zero_le _)

private theorem supportedProducerPair (d e w : Finset ℕ) (D : Finset (Finset ℕ))
    (S : Finset (Finset (Fin 13))) (values : S.image (supportRows d e) = D)
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (fromPlain : w ∈ plainIntersections D) :
    ∃ a ∈ S, ∃ b ∈ S, (11 : Fin 13) ∉ a ∧ (12 : Fin 13) ∉ a ∧
      (11 : Fin 13) ∉ b ∧ (12 : Fin 13) ∉ b ∧
      w = supportRows d e a ∩ supportRows d e b := by
  obtain ⟨x, xPlain, y, yPlain, rfl⟩ := Finset.mem_image₂.mp fromPlain
  obtain ⟨xD, xRows⟩ := Finset.mem_filter.mp xPlain
  obtain ⟨yD, yRows⟩ := Finset.mem_filter.mp yPlain
  obtain ⟨a, aS, rfl⟩ := Finset.mem_image.mp (values.symm ▸ xD)
  obtain ⟨b, bS, rfl⟩ := Finset.mem_image.mp (values.symm ▸ yD)
  have aPure := (untaggedSupportRows d e dRows eRows a).mp xRows
  have bPure := (untaggedSupportRows d e dRows eRows b).mp yRows
  exact ⟨a, aS, b, bS, aPure.1, aPure.2, bPure.1, bPure.2, rfl⟩

end PEqualNP.Outside.L_meta_9427

