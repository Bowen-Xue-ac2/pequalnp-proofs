import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def baseSets : Finset (Finset ℕ) := Finset.univ.image rootSet

def markedSeeds (d e : Finset ℕ) : Finset (Finset ℕ) :=
  insert (insert 40 d) (insert (insert 41 e) baseSets)

def productTerm (a b : Finset ℕ) : Finset ℕ :=
  a ∩ b ∩ actualRows ∪ if {40, 41} ⊆ a ∪ b then {40} else ∅

private theorem markUnchanged (tag : ℕ) (outside : tag ∉ edgeRows) (s : Finset ℕ) :
    insert tag s ∩ edgeRows = s ∩ edgeRows := by
  ext r
  by_cases eq : r = tag
  · subst r
    simp [outside]
  · simp [eq]

private theorem projectMarkedSeed (s : Finset ℕ) (tag : ℕ) (outside : tag ∉ edgeRows)
    (plain : s ∈ baseSets ∨ s ∩ edgeRows = ∅) :
    ∃ a : Finset (Fin 11), a.card ≤ 1 ∧ rowsOf a ⊆ insert tag s ∧
      rowsOf a ∩ edgeRows = insert tag s ∩ edgeRows := by
  rcases plain with fixed | zero
  · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp fixed
    refine ⟨{u}, by simp, ?_, ?_⟩
    · simpa [rowsOf] using (Finset.subset_insert tag (rootSet u))
    · simp [rowsOf, markUnchanged tag outside]
  · refine ⟨∅, by simp, by simp [rowsOf], ?_⟩
    simp [rowsOf, markUnchanged tag outside, zero]

private theorem junkOnRoots (s : Finset ℕ)
    (produced : ∃ u v : Fin 11, s = rootSet u ∩ rootSet v)
    (junk : ¬s ⊆ edgeRows) :
    s ∈ baseSets ∨ s ∩ edgeRows = ∅ := by
  obtain ⟨u, v, rfl⟩ := produced
  rcases rootJunkPair u v junk with eq | zero
  · subst v
    exact Or.inl (by simp [baseSets])
  · exact Or.inr zero

private theorem costFromRootProducers (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dRoots : ∃ u v : Fin 11, d = rootSet u ∩ rootSet v)
    (eRoots : ∃ u v : Fin 11, e = rootSet u ∩ rootSet v)
    (dJunk : ¬d ⊆ edgeRows) (eJunk : ¬e ⊆ edgeRows)
    (build : ∀ w ∈ D \ markedSeeds d e, ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (cover : B.biUnion id = insert 40 edgeRows)
    (terms : ∀ t ∈ B, t ∈ Finset.image₂ productTerm D D ∧ t ⊆ insert 40 edgeRows) :
    23 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  apply projectedCost D (markedSeeds d e) B
  · intro w hw hx
    exact build w (Finset.mem_sdiff.mpr ⟨hw, hx⟩)
  · intro w _ hw
    simp only [markedSeeds, Finset.mem_insert] at hw
    rcases hw with rfl | rfl | ordinary
    · exact projectMarkedSeed d 40 (by decide) (junkOnRoots d dRoots dJunk)
    · exact projectMarkedSeed e 41 (by decide) (junkOnRoots e eRoots eJunk)
    · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp ordinary
      exact ⟨{u}, by simp, by simp [rowsOf], by simp [rowsOf]⟩
  · intro t ht
    obtain ⟨a, ha, b, hb, rfl⟩ := Finset.mem_image₂.mp (terms t ht).1
    have sub := (terms (productTerm a b) ht).2
    have hpos : edgeRows ⊆ actualRows := by decide
    refine ⟨a, ha, b, hb, ?_, ?_⟩
    · intro r hr
      have hterm : r ∈ productTerm a b := Finset.mem_union.mpr (Or.inl hr)
      rcases Finset.mem_insert.mp (sub hterm) with eq | belongs
      · have inRows := (Finset.mem_inter.mp hr).2
        have outside : 40 ∉ actualRows := by decide
        exact (outside (eq ▸ inRows)).elim
      · exact belongs
    · have htag : (if {40, 41} ⊆ a ∪ b then {40} else (∅ : Finset ℕ)) ∩ edgeRows = ∅ := by
        by_cases flag : {40, 41} ⊆ a ∪ b <;>
          simp [flag, show 40 ∉ edgeRows by decide]
      rw [productTerm, Finset.union_inter_distrib_right, htag, Finset.union_empty,
        Finset.inter_assoc, Finset.inter_eq_right.mpr hpos]
  · rw [cover]
    exact Finset.subset_insert _ _

end PEqualNP.Outside.L_meta_9427
