#define main three_term_sweep
#include "L-meta-9427-three-overlap-terms.cpp"
#undef main

#include <limits>
#include <set>

constexpr unsigned edge_count = 16;
std::array<unsigned, positive + 1> minimum_pure{};

void initialize() {
    for (Support s = 1; s < limit; ++s) {
        words[s] = words[s & (s - 1)] | roots[std::countr_zero(s)];
    }
    for (unsigned i = 0; i < roots.size(); ++i) {
        neighbors[i] = compatible(roots[i]);
    }
    for (Edges rows = 1; rows <= positive; ++rows) {
        const unsigned r = std::countr_zero(rows);
        unsigned best = edge_count;
        for (const auto root : roots) {
            if (root & (1u << r)) {
                best = std::min(best, 1 + minimum_pure[rows & ~Edges(root)]);
            }
        }
        minimum_pure[rows] = best;
    }
}

void maximal(std::vector<Edges>& terms) {
    std::sort(terms.begin(), terms.end());
    terms.erase(std::unique(terms.begin(), terms.end()), terms.end());
    const auto all = terms;
    std::erase_if(terms, [&](Edges w) {
        return std::any_of(all.begin(), all.end(), [&](Edges u) { return u != w && (u & w) == w; });
    });
}

struct Cover {
    std::vector<Edges> useful;
    Edges united = 0;
    unsigned pure_budget = edge_count;

    bool pure_can_cover(Edges rows, unsigned count) const {
        return minimum_pure[rows] <= count && unsigned(std::popcount(rows)) <= pure_budget + count;
    }

    bool can_cover(Edges rows, unsigned left, unsigned marks, std::size_t before) const {
        if (pure_can_cover(rows, left)) {
            return true;
        }
        if (!left || !marks || !pure_can_cover(rows & ~united, left - 1)) {
            return false;
        }
        for (std::size_t i = before; i < useful.size(); ++i) {
            const Edges next = rows & ~useful[i];
            if (next != rows && can_cover(next, left - 1, marks - 1, i + 1)) {
                return true;
            }
        }
        return false;
    }
};

bool fits(const Profile& a, const Profile& b, bool overlap, unsigned count,
          unsigned plain_budget, unsigned mark_budget) {
    auto anchor = overlap ? std::vector<Edges>{}
                          : split_tag_terms(a.representative, b.representative, a.compatible, b.compatible);
    const Support same = a.compatible & b.compatible;
    if (same) {
        const auto together = tag_terms(same, a.edges | b.edges);
        anchor.insert(anchor.end(), together.begin(), together.end());
    }
    maximal(anchor);
    Cover cover;
    cover.pure_budget = plain_budget;
    for (const auto* category : {&a.terms, &b.terms, static_cast<const std::vector<Edges>*>(&anchor)}) {
        for (const Edges rows : *category) {
            if (rows && (plain_budget < edge_count || minimum_pure[rows] > 1)) {
                cover.useful.push_back(rows);
                cover.united |= rows;
            }
        }
    }
    maximal(cover.useful);
    for (const auto head : anchor) {
        if (cover.can_cover(positive & ~head, count - 1, mark_budget - 1, 0)) {
            return true;
        }
    }
    return false;
}

#ifndef PNP_PROFILE_LIBRARY_ONLY
int main(int argc, char** argv) {
    const bool overlap = argc > 1 && std::string_view(argv[1]) == "overlap";
    const unsigned terms = argc > 2 ? std::stoul(argv[2]) : 5;
    const std::size_t first = argc > 3 ? std::stoul(argv[3]) : 0;
    const std::size_t last = argc > 4 ? std::stoul(argv[4]) : std::numeric_limits<std::size_t>::max();
    const unsigned plain_budget = argc > 5 ? std::stoul(argv[5]) : edge_count;
    const unsigned mark_budget = argc > 6 ? std::stoul(argv[6]) : terms;
    if (!terms || terms > 7 || last < first || !mark_budget || mark_budget > terms) {
        return 2;
    }
    initialize();
    std::set<Word> pure(words.begin() + 1, words.end());
    if (!overlap) {
        std::map<Word, Word> largest;
        for (Word word : pure) {
            largest[word & negative] |= word;
        }
        pure.clear();
        for (const auto& [_, word] : largest) {
            pure.insert(word);
        }
    }
    std::set<Word> tags;
    for (auto a = pure.begin(); a != pure.end(); ++a) {
        for (auto b = a; b != pure.end(); ++b) {
            if (*a & *b & negative) {
                tags.insert(*a & *b);
            }
        }
    }
    std::map<std::pair<Support, Edges>, std::vector<Word>> grouped;
    for (const auto tag : tags) {
        const Support compatible_roots = compatible(tag);
        if (overlap && !compatible_roots) {
            continue;
        }
        const Edges positive_rows = Edges(tag & (overlap ? words[compatible_roots] : positive)) & positive;
        grouped[{compatible_roots, positive_rows}].push_back(tag & negative);
    }
    std::vector<Profile> profiles;
    std::vector<std::vector<Word>> negative_shapes;
    for (const auto& [key, values] : grouped) {
        const auto [compatible_roots, positive_rows] = key;
        Word unioned_negatives = 0;
        for (const Word value : values) {
            unioned_negatives |= value;
        }
        profiles.push_back({compatible_roots, positive_rows, unioned_negatives, 0, positive_rows,
                            tag_terms(compatible_roots, positive_rows)});
        negative_shapes.push_back(values);
    }
    std::cout << "producer words " << pure.size() << ", tags " << tags.size()
              << ", shapes " << profiles.size() << std::endl;
    if (plain_budget < edge_count || mark_budget < terms) {
        std::cout << "plain union bound " << plain_budget << ", tagged term bound " << mark_budget << std::endl;
    }
    std::uint64_t eligible = 0, possible = 0;
    const auto visit = [&](std::size_t a, std::size_t b) {
        ++eligible;
        const auto& d = profiles[a];
        const auto& e = profiles[b];
        if (fits(d, e, overlap, terms, plain_budget, mark_budget)) {
            ++possible;
            std::cout << "shape " << d.compatible << ' ' << d.edges << ' ' << e.compatible
                      << ' ' << e.edges << '\n';
        }
    };
    if (overlap) {
        for (std::size_t a = first; a < profiles.size() && a < last; ++a) {
            const auto& d = profiles[a];
            for (std::size_t b = a; b < profiles.size(); ++b) {
                const auto& e = profiles[b];
                if (!(d.negatives & e.negatives) || !(d.compatible & e.compatible)) {
                    continue;
                }
                visit(a, b);
            }
        }
    } else {
        std::map<Word, std::vector<std::size_t>> buckets;
        for (std::size_t i = 0; i < negative_shapes.size(); ++i) {
            for (Word value : negative_shapes[i]) {
                buckets[value].push_back(i);
            }
        }
        std::cout << "negative buckets " << buckets.size() << std::endl;
        const std::vector<std::pair<Word,std::vector<std::size_t>>> indexed(buckets.begin(), buckets.end());
        const std::size_t count = profiles.size();
        std::vector<Word> visited((count * (count + 1) / 2 + 63) / 64);
        for (std::size_t a = first; a < indexed.size() && a < last; ++a) {
            for (std::size_t b = a + 1; b < indexed.size(); ++b) {
                if (indexed[a].first & indexed[b].first) {
                    continue;
                }
                for (const std::size_t x : indexed[a].second) {
                    for (const std::size_t y : indexed[b].second) {
                        const auto [lo, hi] = std::minmax(x, y);
                        const std::size_t bit = hi * (hi + 1) / 2 + lo;
                        const Word member = Word{1} << (bit % 64);
                        if (!(visited[bit / 64] & member)) {
                            visited[bit / 64] |= member;
                            visit(lo, hi);
                        }
                    }
                }
            }
        }
    }
    std::cout << "eligible " << eligible << ", shapes with at most " << terms << " terms " << possible << '\n';
}
#endif

