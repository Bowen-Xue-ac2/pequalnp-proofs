import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem projectedClean (a b : Finset ℕ) (A B : Finset (Fin 11))
    (fa : rowsOf A ⊆ a) (fb : rowsOf B ⊆ b)
    (clean : a ∩ b ∩ actualRows ⊆ edgeRows) : rowsOf A ∩ rowsOf B ⊆ edgeRows := by
  intro r hr
  obtain ⟨inA, inB⟩ := Finset.mem_inter.mp hr
  obtain ⟨u, _, atRoot⟩ := Finset.mem_biUnion.mp inA
  exact clean (Finset.mem_inter.mpr
    ⟨Finset.mem_inter.mpr ⟨fa inA, fb inB⟩, rootRowsBound u atRoot⟩)

private theorem overlapTagCarrier (d e a b : Finset ℕ) (A B : Finset (Fin 11))
    (fa : projectionFacts d e ∅ ∅ a A) (fb : projectionFacts d e ∅ ∅ b B)
    (n : ℕ) (nd : n ∈ d) (ne : n ∈ e) (actual : n ∈ actualRows)
    (neg : n ∉ edgeRows) (clean : productTerm a b ⊆ insert 40 edgeRows)
    (tag : 40 ∈ productTerm a b) :
    (40 ∈ a ∧ 41 ∈ a ∧ ¬carriesTag b) ∨ (40 ∈ b ∧ 41 ∈ b ∧ ¬carriesTag a) := by
  obtain ⟨clean, _, produced⟩ := cleanProductFacts a b clean
  have lift {w : Finset ℕ} {s : Finset (Fin 11)}
      (f : projectionFacts d e ∅ ∅ w s) (h : carriesTag w) : n ∈ w := by
    rcases h with h | h
    · exact (f.2.1 h).1 nd
    · exact (f.2.2.1 h).1 ne
  have disjoint (ha : carriesTag a) (hb : carriesTag b) : False :=
    neg (clean (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨lift fa ha, lift fb hb⟩, actual⟩))
  have flags := produced tag
  have left := Finset.mem_union.mp (flags (Finset.mem_insert_self 40 {41}))
  have right := Finset.mem_union.mp
    (flags (Finset.mem_insert_of_mem (Finset.mem_singleton_self 41)))
  rcases left with pa | pb <;> rcases right with qa | qb
  · exact Or.inl ⟨pa, qa, disjoint (Or.inl pa)⟩
  · exact (disjoint (Or.inl pa) (Or.inr qb)).elim
  · exact (disjoint (Or.inr qa) (Or.inl pb)).elim
  · exact Or.inr ⟨pb, qb, fun ha => disjoint ha (Or.inl pb)⟩

def possibleOmission (d e : Finset ℕ) (r : ℕ) : Prop :=
  (∃ w ∈ ({d, e} : Finset (Finset ℕ)), r ∈ w ∧
    ∃ u : Fin 11, r ∈ rootSet u ∧ w ∩ rootSet u ∩ actualRows ⊆ edgeRows) ∨
  (∃ s ∈ ({d, e} : Finset (Finset ℕ)), ∃ t ∈ ({d, e} : Finset (Finset ℕ)),
    r ∈ s ∩ t ∧ s ∩ t ∩ actualRows ⊆ edgeRows)

private theorem possibleOmissionMem {d e : Finset ℕ} {r : ℕ}
    (h : possibleOmission d e r) : r ∈ d ∨ r ∈ e := by
  have tagMem (w : Finset ℕ) (hw : w ∈ ({d, e} : Finset (Finset ℕ))) (hr : r ∈ w) :
      r ∈ d ∨ r ∈ e := by
    rcases Finset.mem_insert.mp hw with rfl | hs
    · exact Or.inl hr
    · obtain rfl := Finset.mem_singleton.mp hs
      exact Or.inr hr
  rcases h with ⟨w, hw, hr, _, _⟩ | ⟨s, hs, _, _, hr, _⟩
  · exact tagMem w hw hr
  · exact tagMem s hs (Finset.mem_inter.mp hr).1

private theorem erasedRowExplained (d e a b : Finset ℕ) (A B : Finset (Fin 11))
    (fa : projectionFacts d e ∅ ∅ a A) (fb : projectionFacts d e ∅ ∅ b B)
    (clean : a ∩ b ∩ actualRows ⊆ edgeRows) (r : ℕ) (actual : r ∈ actualRows)
    (ra : r ∈ a) (rb : r ∈ b) (omitted : r ∉ rowsOf A ∩ rowsOf B) :
    possibleOmission d e r := by
  let tags : Finset (Finset ℕ) := {d, e}
  have dTag : d ∈ tags := Finset.mem_insert_self _ _
  have eTag : e ∈ tags := Finset.mem_insert_of_mem (Finset.mem_singleton_self _)
  have p (s t : Finset ℕ) (hs : s ⊆ a) (ht : t ⊆ b) :
      s ∩ t ∩ actualRows ⊆ edgeRows := by
    intro x hx
    obtain ⟨both, ar⟩ := Finset.mem_inter.mp hx
    obtain ⟨xs, xt⟩ := Finset.mem_inter.mp both
    exact clean (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨hs xs, ht xt⟩, ar⟩)
  have parse (w : Finset ℕ) (S : Finset (Fin 11)) (f : projectionFacts d e ∅ ∅ w S)
      (h : r ∈ w) : r ∈ rowsOf S ∨ ∃ s ∈ tags, r ∈ s ∧ s ⊆ w := by
    rcases f.2.2.2 r h actual with plain | ⟨flag, inD⟩ | ⟨flag, inE⟩
    · exact Or.inl plain
    · exact Or.inr ⟨d, dTag, inD, (f.2.1 flag).1⟩
    · exact Or.inr ⟨e, eTag, inE, (f.2.2.1 flag).1⟩
  rcases parse a A fa ra with plainA | ⟨s, sTag, hs, sa⟩
  · rcases parse b B fb rb with plainB | ⟨t, tTag, ht, tb⟩
    · exact (omitted (Finset.mem_inter.mpr ⟨plainA, plainB⟩)).elim
    · obtain ⟨u, hu, inU⟩ := Finset.mem_biUnion.mp plainA
      have ua : rootSet u ⊆ a := fun x hx => fa.1 (Finset.mem_biUnion.mpr ⟨u, hu, hx⟩)
      have rootClean : t ∩ rootSet u ∩ actualRows ⊆ edgeRows := by
        simpa only [Finset.inter_comm t (rootSet u)] using (p (rootSet u) t ua tb)
      exact Or.inl ⟨t, tTag, ht, u, inU, rootClean⟩
  · rcases parse b B fb rb with plainB | ⟨t, tTag, ht, tb⟩
    · obtain ⟨u, hu, inU⟩ := Finset.mem_biUnion.mp plainB
      have ub : rootSet u ⊆ b := fun x hx => fb.1 (Finset.mem_biUnion.mpr ⟨u, hu, hx⟩)
      exact Or.inl ⟨s, sTag, hs, u, inU, p s (rootSet u) sa ub⟩
    · exact Or.inr ⟨s, sTag, t, tTag, Finset.mem_inter.mpr ⟨hs, ht⟩, p s t sa tb⟩

private theorem actualErasure (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    ∃ (label : Finset ℕ → Finset (Fin 11)) (H : Finset (Fin 11 × Finset (Fin 11)))
        (missing : Finset (Fin 11 × Fin 11)),
      (∀ w ∈ D, projectionFacts d e ∅ ∅ w (label w)) ∧
      (∀ w ∈ D, w ∈ markedSeeds d e → (label w).card ≤ 1) ∧
      (∀ w ∈ D.image label, 1 < w.card →
        ∃ a ∈ D.image label, ∃ b ∈ D.image label, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) ∧
      (∀ h ∈ H, h.2 ∈ D.image label ∧ h.2 ⊆ neighbors h.1) ∧
      (∀ f ∈ orientedEdges, f ∈ missing ∨ ∃ h ∈ H,
        (f.1 = h.1 ∧ f.2 ∈ h.2) ∨ (f.2 = h.1 ∧ f.1 ∈ h.2)) ∧
      (∀ f ∈ missing, ∃ r : Fin 16, f = edgeAt r ∧ possibleOmission d e r.val) ∧
      ((∃ n ∈ d, n ∈ e ∧ n ∉ edgeRows) →
        1 ≤ (redundantTaggedUnions D (markedSeeds d e) label).card) ∧
      2 * H.card + 2 ≤ 2 * B.card + (redundantTaggedUnions D (markedSeeds d e) label).card := by
  classical
  let X := markedSeeds d e
  let seed (w : Finset ℕ) : Finset (Fin 11) :=
    if h : w ∈ X then (eraseSeedFacts d e dRows eRows w h).choose else ∅
  obtain ⟨label, rootLabel, unionLabel⟩ := labelUnionFamily D X seed build
  have roots (w : Finset ℕ) (hw : w ∈ D) (hx : w ∈ X) :
      (label w).card ≤ 1 ∧ projectionFacts d e ∅ ∅ w (label w) ∧
      (carriesTag w → label w = ∅) ∧ ¬(40 ∈ w ∧ 41 ∈ w) := by
    rw [rootLabel w hw hx]
    simpa [seed, hx, carriesTag] using (eraseSeedFacts d e dRows eRows w hx).choose_spec
  have replay := projectionFactsReplay D X d e ∅ ∅ label
    (fun w hw hx => (roots w hw hx).2.1) unionLabel
  obtain ⟨_, builds⟩ := projectedFamily D X label (fun w hw hx => (roots w hw hx).1)
    (fun w hw hx => by
      obtain ⟨a, ha, b, hb, sa, sb, _, eq⟩ := unionLabel w hw hx
      exact ⟨a, ha, b, hb, sa, sb, eq⟩)
  have witnesses (t : {t // t ∈ B}) : ∃ a ∈ D, ∃ b ∈ D,
      t.val = productTerm a b ∧ t.val ⊆ insert 40 edgeRows := pairs t.val t.property
  choose a ha b hb term inside using witnesses
  let projected (t : {t // t ∈ B}) := rowsOf (label (a t)) ∩ rowsOf (label (b t))
  have clean (t : {t // t ∈ B}) : a t ∩ b t ∩ actualRows ⊆ edgeRows := by
    have h := inside t
    rw [term t] at h
    exact (cleanProductFacts _ _ h).1
  have real (t : {t // t ∈ B}) : projected t ⊆ edgeRows :=
    projectedClean _ _ _ _ (replay _ (ha t)).1 (replay _ (hb t)).1 (clean t)
  let live := B.attach.filter fun t => (projected t).Nonempty
  let terms := live.image projected
  let missing := (Finset.univ.filter fun r : Fin 16 => r.val ∉ terms.biUnion id).image edgeAt
  have projectedPairs : ∀ q ∈ terms, ∃ s ∈ D, ∃ t ∈ D,
      rowsOf (label s) ∩ rowsOf (label t) ⊆ edgeRows ∧
      ∀ r : Fin 16, r.val ∈ q → edgeAt r ∉ missing →
        r.val ∈ rowsOf (label s) ∩ rowsOf (label t) := by
    intro q hq
    obtain ⟨t, _, rfl⟩ := Finset.mem_image.mp hq
    exact ⟨a t, ha t, b t, hb t, real t, fun _ h _ => h⟩
  have projectedCover (r : Fin 16) (kept : edgeAt r ∉ missing) : r.val ∈ terms.biUnion id := by
    by_contra omitted
    exact kept (Finset.mem_image.mpr ⟨r, Finset.mem_filter.mpr ⟨Finset.mem_univ _, omitted⟩, rfl⟩)
  obtain ⟨H, count, heads, covers⟩ :=
    headsFromProjectionPartial D terms label missing projectedPairs projectedCover
  have countLive : H.card ≤ live.card :=
    count.trans ((Finset.card_le_card (Finset.filter_subset _ _)).trans Finset.card_image_le)
  have liveSub : live ⊆ B.attach := Finset.filter_subset _ _
  have countB : H.card ≤ B.card := by
    simpa only [Finset.card_attach] using countLive.trans (Finset.card_le_card liveSub)
  have omitted (f : Fin 11 × Fin 11) (hf : f ∈ missing) :
      ∃ r : Fin 16, f = edgeAt r ∧ possibleOmission d e r.val := by
    obtain ⟨r, hr, eq⟩ := Finset.mem_image.mp hf
    refine ⟨r, eq.symm, ?_⟩
    have notKept := (Finset.mem_filter.mp hr).2
    have pos : r.val ∈ edgeRows := Finset.mem_range.mpr r.isLt
    have ar : r.val ∈ actualRows :=
      Finset.mem_range.mpr (r.isLt.trans (by decide : 16 < 40))
    have raw : r.val ∈ B.biUnion id := by
      rw [cover]
      exact Finset.mem_insert_of_mem pos
    obtain ⟨t, ht, rowT⟩ := Finset.mem_biUnion.mp raw
    let w : {t // t ∈ B} := ⟨t, ht⟩
    have atBoth : r.val ∈ a w ∩ b w := by
      have insideW := inside w
      rw [term w] at insideW
      have rowW : r.val ∈ w.val ∩ edgeRows := Finset.mem_inter.mpr ⟨rowT, pos⟩
      rw [term w, (cleanProductFacts _ _ insideW).2.1] at rowW
      exact (Finset.mem_inter.mp rowW).1
    have missingFromPair : r.val ∉ projected w := by
      intro atProj
      have atLive : w ∈ live := Finset.mem_filter.mpr ⟨Finset.mem_attach _ _, ⟨_, atProj⟩⟩
      exact notKept (Finset.mem_biUnion.mpr ⟨projected w, Finset.mem_image_of_mem _ atLive, atProj⟩)
    exact erasedRowExplained d e (a w) (b w) _ _ (replay _ (ha w)) (replay _ (hb w))
      (clean w) r ar (Finset.mem_inter.mp atBoth).1 (Finset.mem_inter.mp atBoth).2 missingFromPair
  refine ⟨label, H, missing, replay, fun w hw hx => (roots w hw hx).1, builds,
    heads, covers, omitted, ?_⟩
  have tagged : 40 ∈ B.biUnion id := by rw [cover]; exact Finset.mem_insert_self _ _
  obtain ⟨t, ht, tag⟩ := Finset.mem_biUnion.mp tagged
  let w : {t // t ∈ B} := ⟨t, ht⟩
  have tagW : 40 ∈ productTerm (a w) (b w) := by rw [← term w]; exact tag
  have cleanW := inside w
  rw [term w] at cleanW
  have chargeOne (s : Finset ℕ) (hs : s ∈ D) (p : 40 ∈ s) (q : 41 ∈ s) :
      1 ≤ (redundantTaggedUnions D X label).card := by
    by_cases active : (label s).Nonempty
    · have charge := doubleTagUnionTaggedDeficit D X label
        (fun v hv hx => (roots v hv hx).2.2) unionLabel s hs p q active
      omega
    · have empty := Finset.not_nonempty_iff_eq_empty.mp active
      have redundant := redundantEmptyDoubleTag D X label
        (fun v hv hx => (roots v hv hx).2.2.2) unionLabel s hs p q empty
      exact Finset.card_pos.mpr ⟨s, Finset.mem_filter.mpr ⟨redundant, Or.inl p⟩⟩
  constructor
  · rintro ⟨n, nd, ne, neg⟩
    rcases overlapTagCarrier d e (a w) (b w) _ _ (replay _ (ha w))
        (replay _ (hb w)) n nd ne (dRows nd) neg cleanW tagW with ⟨p, q, _⟩ | ⟨p, q, _⟩
    · exact chargeOne (a w) (ha w) p q
    · exact chargeOne (b w) (hb w) p q
  change 2 * H.card + 2 ≤ 2 * B.card + (redundantTaggedUnions D X label).card
  by_cases active : (projected w).Nonempty
  · obtain ⟨r, hr⟩ := active
    obtain ⟨left, right⟩ := Finset.mem_inter.mp hr
    obtain ⟨u, hu, _⟩ := Finset.mem_biUnion.mp left
    obtain ⟨v, hv, _⟩ := Finset.mem_biUnion.mp right
    have aActive : (label (a w)).Nonempty := ⟨u, hu⟩
    have bActive : (label (b w)).Nonempty := ⟨v, hv⟩
    have charge : 2 ≤ (redundantTaggedUnions D X label).card := by
      by_cases bothA : 40 ∈ a w ∧ 41 ∈ a w
      · exact doubleTagUnionTaggedDeficit D X label
          (fun s hs hx => (roots s hs hx).2.2) unionLabel (a w) (ha w)
          bothA.1 bothA.2 aActive
      by_cases bothB : 40 ∈ b w ∧ 41 ∈ b w
      · exact doubleTagUnionTaggedDeficit D X label
          (fun s hs hx => (roots s hs hx).2.2) unionLabel (b w) (hb w)
          bothB.1 bothB.2 bActive
      have flags := (cleanProductFacts _ _ cleanW).2.2 tagW
      have hasP := Finset.mem_union.mp (flags (Finset.mem_insert_self 40 {41}))
      have hasQ := Finset.mem_union.mp (flags (Finset.mem_insert_of_mem (Finset.mem_singleton_self 41)))
      rcases hasP with pa | pb <;> rcases hasQ with qa | qb
      · exact (bothA ⟨pa, qa⟩).elim
      · exact splitTagUnionDeficit D X label (fun s hs hx => (roots s hs hx).2.2.1)
          unionLabel (a w) (b w) (ha w) (hb w) pa qb (fun p => bothB ⟨p, qb⟩) aActive bActive
      · exact splitTagUnionDeficit D X label (fun s hs hx => (roots s hs hx).2.2.1)
          unionLabel (b w) (a w) (hb w) (ha w) pb qa (fun p => bothA ⟨p, qa⟩) bActive aActive
      · exact (bothB ⟨pb, qb⟩).elim
    omega
  · have out : w ∉ live := by simp [live, active]
    have smaller : live ⊂ B.attach := Finset.ssubset_iff_subset_ne.mpr
      ⟨liveSub, fun eq => out (eq.symm ▸ Finset.mem_attach _ _)⟩
    have lost := Finset.card_lt_card smaller
    rw [Finset.card_attach] at lost
    omega

end PEqualNP.Outside.L_meta_9427
