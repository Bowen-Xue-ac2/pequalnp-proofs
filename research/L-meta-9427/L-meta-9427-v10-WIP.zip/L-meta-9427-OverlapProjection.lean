import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def projectionFacts (d e : Finset ℕ) (ds es : Finset (Fin 11))
    (w : Finset ℕ) (support : Finset (Fin 11)) : Prop :=
  rowsOf support ⊆ w ∧
  (40 ∈ w → d ⊆ w ∧ ds ⊆ support) ∧
  (41 ∈ w → e ⊆ w ∧ es ⊆ support) ∧
  (∀ r ∈ w, r ∈ actualRows →
    r ∈ rowsOf support ∨ (40 ∈ w ∧ r ∈ d) ∨ (41 ∈ w ∧ r ∈ e))

private theorem untaggedRows (d e w : Finset ℕ) (ds es S : Finset (Fin 11))
    (shape : projectionFacts d e ds es w S) (rows : w ⊆ actualRows) : w = rowsOf S := by
  apply Finset.Subset.antisymm _ shape.1
  intro r hr
  rcases shape.2.2.2 r hr (rows hr) with kept | ⟨tag, _⟩ | ⟨tag, _⟩
  · exact kept
  · exact ((show 40 ∉ actualRows by decide) (rows tag)).elim
  · exact ((show 41 ∉ actualRows by decide) (rows tag)).elim

private theorem projectionFactsUnion (d e a b : Finset ℕ)
    (ds es A B : Finset (Fin 11))
    (fa : projectionFacts d e ds es a A) (fb : projectionFacts d e ds es b B) :
    projectionFacts d e ds es (a ∪ b) (A ∪ B) := by
  have unions : rowsOf (A ∪ B) = rowsOf A ∪ rowsOf B := by
    simp only [rowsOf, Finset.union_biUnion]
  refine ⟨?_, ?_, ?_, ?_⟩
  · rw [unions]
    exact Finset.union_subset_union fa.1 fb.1
  · intro hp
    rcases Finset.mem_union.mp hp with old | old
    · obtain ⟨dLe, dsLe⟩ := fa.2.1 old
      exact ⟨dLe.trans Finset.subset_union_left, dsLe.trans Finset.subset_union_left⟩
    · obtain ⟨dLe, dsLe⟩ := fb.2.1 old
      exact ⟨dLe.trans Finset.subset_union_right, dsLe.trans Finset.subset_union_right⟩
  · intro hq
    rcases Finset.mem_union.mp hq with old | old
    · obtain ⟨eLe, esLe⟩ := fa.2.2.1 old
      exact ⟨eLe.trans Finset.subset_union_left, esLe.trans Finset.subset_union_left⟩
    · obtain ⟨eLe, esLe⟩ := fb.2.2.1 old
      exact ⟨eLe.trans Finset.subset_union_right, esLe.trans Finset.subset_union_right⟩
  · intro r hr actual
    rcases Finset.mem_union.mp hr with ha | hb
    · rcases fa.2.2.2 r ha actual with plain | ⟨flag, atTag⟩ | ⟨flag, atTag⟩
      · exact Or.inl (by rw [unions]; exact Finset.mem_union.mpr (Or.inl plain))
      · exact Or.inr (Or.inl ⟨Finset.mem_union.mpr (Or.inl flag), atTag⟩)
      · exact Or.inr (Or.inr ⟨Finset.mem_union.mpr (Or.inl flag), atTag⟩)
    · rcases fb.2.2.2 r hb actual with plain | ⟨flag, atTag⟩ | ⟨flag, atTag⟩
      · exact Or.inl (by rw [unions]; exact Finset.mem_union.mpr (Or.inr plain))
      · exact Or.inr (Or.inl ⟨Finset.mem_union.mpr (Or.inr flag), atTag⟩)
      · exact Or.inr (Or.inr ⟨Finset.mem_union.mpr (Or.inr flag), atTag⟩)

private theorem projectionFactsReplay (D X : Finset (Finset ℕ)) (d e : Finset ℕ)
    (ds es : Finset (Fin 11)) (label : Finset ℕ → Finset (Fin 11))
    (root : ∀ w ∈ D, w ∈ X → projectionFacts d e ds es w (label w))
    (build : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b ∧ label w = label a ∪ label b) :
    ∀ w ∈ D, projectionFacts d e ds es w (label w) := by
  intro w hw
  induction hwSize : w.card using Nat.strong_induction_on generalizing w with
  | ind n ih =>
    by_cases seed : w ∈ X
    · exact root w hw seed
    obtain ⟨a, ha, b, hb, haSub, hbSub, value, support⟩ := build w hw seed
    have aSmall : a.card < n := by rw [← hwSize]; exact Finset.card_lt_card haSub
    have bSmall : b.card < n := by rw [← hwSize]; exact Finset.card_lt_card hbSub
    have both := projectionFactsUnion d e a b ds es (label a) (label b)
      (ih a.card aSmall a ha rfl) (ih b.card bSmall b hb rfl)
    rw [support, value]
    exact both

def retainedRootPairs (d : Finset ℕ) (image : Finset (Fin 11))
    (missing : Finset (Fin 11 × Fin 11)) : Prop :=
  ∀ u : Fin 11, d ∩ rootSet u ∩ actualRows ⊆ edgeRows →
    ∀ r : Fin 16, r.val ∈ d → r.val ∈ rootSet u → edgeAt r ∉ missing →
      r.val ∈ rowsOf image

private theorem retainOverlapLeft (d e a b : Finset ℕ) (ds es A B : Finset (Fin 11))
    (fa : projectionFacts d e ds es a A) (fb : projectionFacts d e ds es b B)
    (missing : Finset (Fin 11 × Fin 11))
    (retainD : retainedRootPairs d ds missing) (retainE : retainedRootPairs e es missing)
    (clean : a ∩ b ∩ actualRows ⊆ edgeRows)
    (n : ℕ) (nd : n ∈ d) (ne : n ∈ e) (actualN : n ∈ actualRows) (negativeN : n ∉ edgeRows)
    (r : Fin 16) (ra : r.val ∈ a) (rb : r.val ∈ b) (hr : edgeAt r ∉ missing) :
    r.val ∈ rowsOf A := by
  have incident : r.val ∈ actualRows := by
    exact Finset.mem_range.mpr (r.isLt.trans (by decide : 16 < 40))
  have forbidden (aTagged : 40 ∈ a ∨ 41 ∈ a) (bTagged : 40 ∈ b ∨ 41 ∈ b) : False := by
    have na : n ∈ a := by
      rcases aTagged with h | h
      · exact (fa.2.1 h).1 nd
      · exact (fa.2.2.1 h).1 ne
    have nb : n ∈ b := by
      rcases bTagged with h | h
      · exact (fb.2.1 h).1 nd
      · exact (fb.2.2.1 h).1 ne
    exact negativeN (clean (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨na, nb⟩, actualN⟩))
  have keepTag (x : Finset ℕ) (xs : Finset (Fin 11))
      (aTagged : 40 ∈ a ∨ 41 ∈ a) (xLe : x ⊆ a) (xsLe : xs ⊆ A)
      (rx : r.val ∈ x) (retain : retainedRootPairs x xs missing) : r.val ∈ rowsOf A := by
    have pureB : r.val ∈ rowsOf B := by
      rcases fb.2.2.2 r.val rb incident with pure | ⟨flag, _⟩ | ⟨flag, _⟩
      · exact pure
      · exact (forbidden aTagged (Or.inl flag)).elim
      · exact (forbidden aTagged (Or.inr flag)).elim
    obtain ⟨u, hu, ru⟩ := Finset.mem_biUnion.mp pureB
    have comp : x ∩ rootSet u ∩ actualRows ⊆ edgeRows := by
      intro row atPair
      obtain ⟨pair, actual⟩ := Finset.mem_inter.mp atPair
      obtain ⟨inX, inRoot⟩ := Finset.mem_inter.mp pair
      have inB := fb.1 (Finset.mem_biUnion.mpr ⟨u, hu, inRoot⟩)
      exact clean (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨xLe inX, inB⟩, actual⟩)
    obtain ⟨v, hv, rv⟩ := Finset.mem_biUnion.mp (retain u comp r rx ru hr)
    exact Finset.mem_biUnion.mpr ⟨v, xsLe hv, rv⟩
  rcases fa.2.2.2 r.val ra incident with pure | ⟨flag, rx⟩ | ⟨flag, rx⟩
  · exact pure
  · exact keepTag d ds (Or.inl flag) (fa.2.1 flag).1 (fa.2.1 flag).2 rx retainD
  · exact keepTag e es (Or.inr flag) (fa.2.2.1 flag).1 (fa.2.2.1 flag).2 rx retainE

private theorem projectionWithSmallSeedImages (d e : Finset ℕ) (D : Finset (Finset ℕ))
    (ds es : Finset (Fin 11)) (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (dCard : ds.card ≤ 1) (eCard : es.card ≤ 1)
    (dsLe : rowsOf ds ⊆ d) (esLe : rowsOf es ⊆ e)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) :
    ∃ label : Finset ℕ → Finset (Fin 11),
      (∀ w ∈ D, projectionFacts d e ds es w (label w)) ∧
      ((D.image label).filter fun s => 1 < s.card).card ≤ (D \ markedSeeds d e).card ∧
      (∀ w ∈ D.image label, 1 < w.card →
        ∃ a ∈ D.image label, ∃ b ∈ D.image label, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) := by
  classical
  have no40 : 40 ∉ actualRows := by decide
  have no41 : 41 ∉ actualRows := by decide
  have insertReal (r tag : ℕ) (outside : tag ∉ actualRows) (w : Finset ℕ)
      (hr : r ∈ insert tag w) (real : r ∈ actualRows) : r ∈ w := by
    rcases Finset.mem_insert.mp hr with eq | inside
    · exact (outside (eq ▸ real)).elim
    · exact inside
  have seedFor (w : Finset ℕ) (hw : w ∈ markedSeeds d e) :
      ∃ S : Finset (Fin 11), S.card ≤ 1 ∧ projectionFacts d e ds es w S := by
    simp only [markedSeeds, Finset.mem_insert] at hw
    rcases hw with rfl | rfl | ordinary
    · refine ⟨ds, dCard, dsLe.trans (Finset.subset_insert _ _), ?_, ?_, ?_⟩
      · exact fun _ => ⟨Finset.subset_insert _ _, Finset.Subset.rfl⟩
      · intro impossible
        rcases Finset.mem_insert.mp impossible with eq | h
        · omega
        · exact (no41 (dRows h)).elim
      · intro r hr real
        exact Or.inr (Or.inl ⟨Finset.mem_insert_self _ _, insertReal r 40 no40 d hr real⟩)
    · refine ⟨es, eCard, esLe.trans (Finset.subset_insert _ _), ?_, ?_, ?_⟩
      · intro impossible
        rcases Finset.mem_insert.mp impossible with eq | h
        · omega
        · exact (no40 (eRows h)).elim
      · exact fun _ => ⟨Finset.subset_insert _ _, Finset.Subset.rfl⟩
      · intro r hr real
        exact Or.inr (Or.inr ⟨Finset.mem_insert_self _ _, insertReal r 41 no41 e hr real⟩)
    · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp ordinary
      refine ⟨{u}, by simp, by simp [rowsOf], ?_, ?_, ?_⟩
      · intro h
        exact (no40 (rootRowsBound u h)).elim
      · intro h
        exact (no41 (rootRowsBound u h)).elim
      · intro r hr _
        exact Or.inl (by simpa [rowsOf] using hr)
  let seed (w : Finset ℕ) : Finset (Fin 11) :=
    if h : w ∈ markedSeeds d e then (seedFor w h).choose else ∅
  obtain ⟨label, rootLabel, unionLabel⟩ :=
    labelUnionFamily D (markedSeeds d e) seed build
  have roots (w : Finset ℕ) (hw : w ∈ D) (hx : w ∈ markedSeeds d e) :
      (label w).card ≤ 1 ∧ projectionFacts d e ds es w (label w) := by
    rw [rootLabel w hw hx]
    simpa [seed, hx] using (seedFor w hx).choose_spec
  have replay := projectionFactsReplay D (markedSeeds d e) d e ds es label
    (fun w hw hx => (roots w hw hx).2) unionLabel
  obtain ⟨count, buildProjected⟩ := projectedFamily D (markedSeeds d e) label
    (fun w hw hx => (roots w hw hx).1) (fun w hw hx => by
      obtain ⟨a, ha, b, hb, haSub, hbSub, _, eq⟩ := unionLabel w hw hx
      exact ⟨a, ha, b, hb, haSub, hbSub, eq⟩)
  exact ⟨label, replay, count, buildProjected⟩

private theorem costOverlapWithOneMissing (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (ds es : Finset (Fin 11)) (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (dCard : ds.card ≤ 1) (eCard : es.card ≤ 1)
    (dsLe : rowsOf ds ⊆ d) (esLe : rowsOf es ⊆ e)
    (n : ℕ) (nd : n ∈ d) (ne : n ∈ e) (neg : n ∉ edgeRows)
    (missing : Finset (Fin 11 × Fin 11)) (missingSub : missing ⊆ orientedEdges)
    (missingCount : missing.card ≤ 1)
    (keepD : retainedRootPairs d ds missing) (keepE : retainedRootPairs e es missing)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      a ∩ b ∩ actualRows ⊆ edgeRows ∧ t ∩ edgeRows = a ∩ b ∩ edgeRows)
    (cover : edgeRows ⊆ B.biUnion id) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  obtain ⟨label, replay, count, buildProjected⟩ :=
    projectionWithSmallSeedImages d e D ds es dRows eRows dCard eCard dsLe esLe build
  have pairProjected : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      rowsOf (label a) ∩ rowsOf (label b) ⊆ edgeRows ∧
      ∀ r : Fin 16, r.val ∈ t → edgeAt r ∉ missing →
        r.val ∈ rowsOf (label a) ∩ rowsOf (label b) := by
    intro t ht
    obtain ⟨a, ha, b, hb, clean, values⟩ := pairs t ht
    have fa := replay a ha
    have fb := replay b hb
    refine ⟨a, ha, b, hb, ?_, ?_⟩
    · intro r hr
      obtain ⟨inA, inB⟩ := Finset.mem_inter.mp hr
      obtain ⟨u, _, inRoot⟩ := Finset.mem_biUnion.mp inA
      exact clean (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨fa.1 inA, fb.1 inB⟩,
        rootRowsBound u inRoot⟩)
    · intro r inT present
      have hrow : r.val ∈ t ∩ edgeRows :=
        Finset.mem_inter.mpr ⟨inT, Finset.mem_range.mpr r.isLt⟩
      rw [values] at hrow
      obtain ⟨ra, rb⟩ := Finset.mem_inter.mp (Finset.mem_inter.mp hrow).1
      have reverse : b ∩ a ∩ actualRows ⊆ edgeRows := by
        simpa only [Finset.inter_comm a b] using clean
      exact Finset.mem_inter.mpr
        ⟨retainOverlapLeft d e a b ds es (label a) (label b) fa fb missing
          keepD keepE clean n nd ne (dRows nd) neg r ra rb present,
         retainOverlapLeft d e b a ds es (label b) (label a) fb fa missing
          keepD keepE reverse n nd ne (dRows nd) neg r rb ra present⟩
  have bound := projectedCostWithMissing D B label missing missingSub buildProjected pairProjected cover
  omega

end PEqualNP.Outside.L_meta_9427
