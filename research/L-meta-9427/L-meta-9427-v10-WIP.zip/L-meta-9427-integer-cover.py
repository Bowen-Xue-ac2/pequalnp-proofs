"""Choose actual row masks and clean cover terms in a binary linear model."""

import argparse
from collections import defaultdict
import itertools
import json
from pathlib import Path
import runpy

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix


model = runpy.run_path(str(Path(__file__).with_name("L-meta-9427-fixed-intersections.py")))
VERTICES = model["VERTICES"]
TAG_D, TAG_E = model["TAG_D"], model["TAG_E"]
TARGET = model["TARGET"]


def minimal_dependencies(options):
    chosen = []
    for option in sorted(set(map(frozenset, options)), key=lambda x: (len(x), tuple(sorted(x)))):
        if not any(other <= option for other in chosen):
            chosen.append(option)
    return chosen


def solve(d, e, producers, max_support, budget, seconds, overlap_relaxation=False,
          producer_options=()):
    seeds = (*VERTICES, d | TAG_D, e | TAG_E)
    known = set(seeds)
    rows, heads = model["head_options"](seeds, max_support, overlap=overlap_relaxation)
    needed = {support for left, right, _ in heads for support in (left, right)}
    needed.update(producers)
    if producer_options:
        producer_masks = {v for options in producer_options for pair in options for v in pair[:2]}
        needed.update(s for s in range(1,1 << len(VERTICES))
                      if s.bit_count() <= 5 and rows[s] in producer_masks)
    possible = {sub for support in needed for sub in model["subsets"](support)}

    recipes = defaultdict(set)
    for support in possible:
        wire = rows[support]
        if wire in known:
            continue
        recipes[wire].update(
            tuple(v for v in (rows[a], rows[b]) if v not in known)
            for a, b in model["decompositions"](support)
            if rows[a] != wire and rows[b] != wire
        )
    required = {rows[s] for s in producers} - known
    terms = defaultdict(set)
    for left, right, term in heads:
        terms[term].add(tuple(v for v in (rows[left], rows[right]) if v not in known))

    costs = []
    lower = []
    upper = []
    row_indices = []
    col_indices = []
    data = []

    def var(cost):
        i = len(costs)
        costs.append(cost)
        return i

    def constraint(items, lo=-np.inf, hi=np.inf):
        i = len(lower)
        lower.append(lo)
        upper.append(hi)
        for column, coefficient in items:
            row_indices.append(i)
            col_indices.append(column)
            data.append(coefficient)

    wire_ids = {row:var(1) for row in sorted(recipes)}
    term_ids = {term:var(2) for term in sorted(terms)}
    both = {}

    def require_recipe(selected, options):
        options = minimal_dependencies(options)
        if any(not option for option in options):
            return
        available = []
        for option in options:
            operands = tuple(sorted(wire_ids[a] for a in option))
            if len(operands) == 1:
                available.append(operands[0])
                continue
            if operands not in both:
                gate = var(0)
                both[operands] = gate
                for current in operands:
                    constraint(((gate, 1), (current, -1)), hi=0)
            available.append(both[operands])
        constraint([(selected,1)] + [(v,-1) for v in set(available)], hi=0)

    for row, deps in recipes.items():
        require_recipe(wire_ids[row], deps)
    for term, deps in terms.items():
        require_recipe(term_ids[term], deps)
    for row in required:
        constraint(((wire_ids[row],1),), lo=1)
    usable_producers = []
    for options in producer_options:
        choices = [(a,b,raw) for a,b,raw in options
                   if (a in known or a in wire_ids) and (b in known or b in wire_ids)]
        usable_producers.append(choices)
        required_pair = var(0)
        constraint(((required_pair,1),), lo=1)
        require_recipe(required_pair, [tuple(x for x in (a,b) if x not in known)
                                       for a,b,_ in choices])
    for bit in (*range(16), 40):
        constraint([(v,1) for term,v in term_ids.items() if term & (1 << bit)], lo=1)
    constraint([(v,1) for v in term_ids.values()], hi=9)
    constraint([(v,1) for v in wire_ids.values()], lo=1, hi=18)
    constraint([(i,c) for i,c in enumerate(costs) if c], hi=budget)
    matrix = coo_matrix((data,(row_indices,col_indices)), shape=(len(lower),len(costs))).tocsc()
    result = milp(
        np.array(costs), integrality=np.ones(len(costs)), bounds=Bounds(0,1),
        constraints=LinearConstraint(matrix,lower,upper),
        options={"time_limit":seconds,"presolve":True},
    )
    output = {"status":int(result.status),"variables":len(costs),"constraints":len(lower)}
    if result.x is not None:
        family = known | {row for row,v in wire_ids.items() if result.x[v] > .5}
        selected = {term for term,v in term_ids.items() if result.x[v] > .5}
        if usable_producers:
            actual = [next(raw for a,b,raw in opts if a in family and b in family)
                      for opts in usable_producers]
            extension = runpy.run_path(str(Path(__file__).with_name("L-meta-9427-extend-overlap.py")))
            labels = extension["label_family"](family,seeds)
            d,e = actual
            family = set(extension["replace_seeds"](labels,d,e).values())
            known = {*VERTICES,d|TAG_D,e|TAG_E}
            cover = model["checked_cover"](family,selected)
            cost = model["verify"](d,e,family,cover,budget)
            label = "witness"
        elif overlap_relaxation:
            assert model["model"]["union"](selected) == TARGET
            cost = len(family - known) + 2 * len(selected)
            assert cost <= budget
            label, cover = "relaxed_assignment", selected
        else:
            cover = model["checked_cover"](family,selected)
            cost = model["verify"](d,e,family,cover,budget)
            label = "witness"
        output[label] = {
            "d": d, "e": e, "family": sorted(family), "cover": sorted(cover), "cost": cost,
            "unmarked_unions": sum(row < TAG_D for row in family - known),
        }
    if getattr(result,"mip_dual_bound",None) is not None:
        output["numeric_lower_bound"] = float(result.mip_dual_bound)
    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--count", type=int, default=5)
    parser.add_argument("--seconds", type=float, default=4)
    parser.add_argument("--budget", type=int, default=20)
    parser.add_argument("--max-support", type=int, default=4)
    parser.add_argument("--baseline", action="store_true")
    parser.add_argument("--overlap-profiles", type=Path)
    args = parser.parse_args()
    if args.baseline:
        pairs=[(VERTICES[0],VERTICES[9],())]
    elif args.overlap_profiles:
        signatures=json.loads(args.overlap_profiles.read_text())
        candidates=[
            (
                (a["usable_positive"] | b["usable_positive"]).bit_count(),
                (a["compatibility"] & b["compatibility"]).bit_count(),
                a["representative"], b["representative"],
            )
            for a,b in itertools.combinations_with_replacement(signatures,2)
            if a["compatibility"] & b["compatibility"]
        ]
        candidates.sort(reverse=True)
        pairs=[(d,e,()) for _,_,d,e in candidates[args.start:args.start+args.count]]
    else:
        pairs=model["ranked_pairs"]()[args.start:args.start+args.count]
    for i, (d,e,producers) in enumerate(pairs, args.start):
        result=solve(d,e,producers,args.max_support,args.budget,args.seconds,
                     overlap_relaxation=bool(args.overlap_profiles))
        print(json.dumps({"index":i,"budget":args.budget,**result}),flush=True)
        if "witness" in result and result["witness"]["cost"] <= 20:
            break


if __name__ == "__main__":
    main()
