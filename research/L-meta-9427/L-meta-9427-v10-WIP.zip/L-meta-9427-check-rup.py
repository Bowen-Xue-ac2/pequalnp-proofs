"""Replay forward unit-propagation hints against the original DIMACS clauses."""

import argparse
import json
from pathlib import Path
import runpy


def check_rup(source, proof):
    clauses = {n: frozenset(clause) for n, clause in enumerate(source, 1)}
    count = 0
    ended = False
    with proof.open() as records:
        for line in records:
            fields = line.split()
            if fields[1] == "d":
                for column in fields[2:-1]:
                    clauses.pop(int(column), None)
                continue
            index = int(fields[0])
            end = fields.index("0", 1)
            clause = frozenset(int(t) for t in fields[1:end])
            hints = [int(t) for t in fields[end + 1:-1]]
            if any(h <= 0 for h in hints):
                raise ValueError(f"Proof step {index} uses a rule other than unit propagation.")
            assigned = {-literal for literal in clause}
            contradiction = any(-literal in assigned for literal in assigned)
            for hint in hints:
                if contradiction:
                    break
                prior = clauses[hint]
                if prior & assigned:
                    continue
                open_literals = [lit for lit in prior if -lit not in assigned]
                if not open_literals:
                    contradiction = True
                elif len(open_literals) == 1:
                    assigned.add(open_literals[0])
                else:
                    raise ValueError(f"Proof step {index} cites non-unit clause {hint}.")
            if not contradiction or index in clauses:
                raise ValueError(f"Proof step {index} does not justify a new clause.")
            clauses[index] = clause
            count += 1
            ended |= not clause
    if not ended:
        raise ValueError("The proof has no empty clause.")
    return count


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("proof", type=Path)
    parser.add_argument("--count", type=int, default=3)
    args = parser.parse_args()
    module = runpy.run_path(str(Path(__file__).with_name("L-meta-9427-cover-cnf.py")))
    formula = module["any_supports"](args.count, "all")[0]
    steps = check_rup(formula.clauses, args.proof)
    print(json.dumps({"initial_clauses": len(formula.clauses), "checked_steps": steps,
                      "empty_clause_derived": True}))


if __name__ == "__main__":
    main()
