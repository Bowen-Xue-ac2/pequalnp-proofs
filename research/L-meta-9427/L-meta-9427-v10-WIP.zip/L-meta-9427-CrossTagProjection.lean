import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def compatibleCenters (A B : Finset (Fin 11)) : Finset (Fin 11) :=
  A.filter fun u => B ⊆ neighbors u

def producerHeads (A B : Finset (Fin 11)) : Finset (Fin 11 × Finset (Fin 11)) :=
  ((compatibleCenters A B).image fun u => (u, B)) ∪
    ((compatibleCenters B A).image fun v => (v, A))

private theorem compatibleCentersSmall (A B : Finset (Fin 11)) (large : 1 < B.card) :
    (compatibleCenters A B).card ≤ 1 := by
  apply Finset.card_le_one.mpr
  intro u foundU v foundV
  by_contra different
  have sub : B ⊆ neighbors u ∩ neighbors v :=
    fun _ h => Finset.mem_inter.mpr
      ⟨(Finset.mem_filter.mp foundU).2 h, (Finset.mem_filter.mp foundV).2 h⟩
  exact (Nat.not_le_of_gt large) ((Finset.card_le_card sub).trans (commonNeighbors u v different))

private theorem producerHeadCount (A B : Finset (Fin 11))
    (largeA : 1 < A.card) (largeB : 1 < B.card) : (producerHeads A B).card ≤ 2 := by
  have a := Finset.card_image_le (s := compatibleCenters A B) (f := fun u => (u, B))
  have b := Finset.card_image_le (s := compatibleCenters B A) (f := fun v => (v, A))
  have eachA := compatibleCentersSmall A B largeB
  have eachB := compatibleCentersSmall B A largeA
  exact (Finset.card_union_le _ _).trans (Nat.add_le_add (a.trans eachA) (b.trans eachB))

private theorem producerHeadValid (A B : Finset (Fin 11)) (h : Fin 11 × Finset (Fin 11))
    (hh : h ∈ producerHeads A B) : (h.2 = A ∨ h.2 = B) ∧ h.2 ⊆ neighbors h.1 := by
  rcases Finset.mem_union.mp hh with fromA | fromB
  · obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp fromA
    exact ⟨Or.inr rfl, (Finset.mem_filter.mp hu).2⟩
  · obtain ⟨v, hv, rfl⟩ := Finset.mem_image.mp fromB
    exact ⟨Or.inl rfl, (Finset.mem_filter.mp hv).2⟩

private theorem cleanWhenInProducer (A B : Finset (Fin 11)) (u : Fin 11) (hu : u ∈ A)
    (clean : (rowsOf A ∩ rowsOf B) ∩ rootSet u ∩ actualRows ⊆ edgeRows) :
    B ⊆ neighbors u := by
  intro v hv
  refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, (rootSetPair u v).mp ?_⟩
  intro r hr
  obtain ⟨atU, atV⟩ := Finset.mem_inter.mp hr
  have atA : r ∈ rowsOf A := Finset.mem_biUnion.mpr ⟨u, hu, atU⟩
  have atB : r ∈ rowsOf B := Finset.mem_biUnion.mpr ⟨v, hv, atV⟩
  exact clean (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr
    ⟨Finset.mem_inter.mpr ⟨atA, atB⟩, atU⟩, rootRowsBound u atU⟩)

private theorem cleanCrossRowCovered (A B : Finset (Fin 11)) (separate : Disjoint A B)
    (u : Fin 11) (r : Fin 16)
    (inTag : r.val ∈ rowsOf A ∩ rowsOf B) (atU : r.val ∈ rootSet u)
    (clean : (rowsOf A ∩ rowsOf B) ∩ rootSet u ∩ actualRows ⊆ edgeRows) :
    ∃ h ∈ producerHeads A B,
      ((edgeAt r).1 = h.1 ∧ (edgeAt r).2 ∈ h.2) ∨
      ((edgeAt r).2 = h.1 ∧ (edgeAt r).1 ∈ h.2) := by
  obtain ⟨inA, inB⟩ := Finset.mem_inter.mp inTag
  obtain ⟨a, ha, atA⟩ := Finset.mem_biUnion.mp inA
  obtain ⟨b, hb, atB⟩ := Finset.mem_biUnion.mp inB
  have distinct : a ≠ b := fun eq => Finset.disjoint_left.mp separate ha (eq.symm ▸ hb)
  have side : u ∈ A ∨ u ∈ B := by
    rcases (edgeAtMembership r a).mp atA with al | ar <;>
      rcases (edgeAtMembership r b).mp atB with bl | br
    · exact (distinct (al.trans bl.symm)).elim
    · rcases (edgeAtMembership r u).mp atU with ul | ur
      · exact Or.inl (ul.trans al.symm ▸ ha)
      · exact Or.inr (ur.trans br.symm ▸ hb)
    · rcases (edgeAtMembership r u).mp atU with ul | ur
      · exact Or.inr (ul.trans bl.symm ▸ hb)
      · exact Or.inl (ur.trans ar.symm ▸ ha)
    · exact (distinct (ar.trans br.symm)).elim
  rcases side with left | right
  · have compatible := cleanWhenInProducer A B u left clean
    have found : u ∈ compatibleCenters A B := Finset.mem_filter.mpr ⟨left, compatible⟩
    have out := vertexIntersectionMatches u B (Finset.disjoint_left.mp separate left) r atU inB
      (edgeAtOriented r)
    exact ⟨(u, B), Finset.mem_union.mpr (Or.inl (Finset.mem_image_of_mem _ found)),
      out.elim (fun h => Or.inl ⟨h.1, (Finset.mem_inter.mp h.2).1⟩)
        (fun h => Or.inr ⟨h.1, (Finset.mem_inter.mp h.2).1⟩)⟩
  · have backwards : (rowsOf B ∩ rowsOf A) ∩ rootSet u ∩ actualRows ⊆ edgeRows := by
      simpa only [Finset.inter_comm (rowsOf B) (rowsOf A)] using clean
    have compatible := cleanWhenInProducer B A u right backwards
    have found : u ∈ compatibleCenters B A := Finset.mem_filter.mpr ⟨right, compatible⟩
    have out := vertexIntersectionMatches u A (Finset.disjoint_left.mp separate.symm right) r atU inA
      (edgeAtOriented r)
    exact ⟨(u, A), Finset.mem_union.mpr (Or.inr (Finset.mem_image_of_mem _ found)),
      out.elim (fun h => Or.inl ⟨h.1, (Finset.mem_inter.mp h.2).1⟩)
        (fun h => Or.inr ⟨h.1, (Finset.mem_inter.mp h.2).1⟩)⟩

def rawCompatibleCenters (a b : Finset ℕ) : Finset (Fin 11) :=
  Finset.univ.filter fun u => rootSet u ⊆ a ∧ b ∩ rootSet u ∩ actualRows ⊆ edgeRows

private theorem compatibleCentersFromRows (A B : Finset (Fin 11)) :
    compatibleCenters A B ⊆ rawCompatibleCenters (rowsOf A) (rowsOf B) := by
  intro u hu
  obtain ⟨uA, near⟩ := Finset.mem_filter.mp hu
  refine Finset.mem_filter.mpr ⟨Finset.mem_univ _,
    fun r hr => Finset.mem_biUnion.mpr ⟨u, uA, hr⟩, ?_⟩
  intro r hr
  obtain ⟨both, _⟩ := Finset.mem_inter.mp hr
  obtain ⟨inB, atU⟩ := Finset.mem_inter.mp both
  obtain ⟨v, vB, atV⟩ := Finset.mem_biUnion.mp inB
  have adjacent := (Finset.mem_filter.mp (near vB)).2
  exact (rootSetPair u v).mpr adjacent (Finset.mem_inter.mpr ⟨atU, atV⟩)

private theorem producerHeadRawBudget (a b : Finset ℕ) (A B : Finset (Fin 11))
    (ha : a = rowsOf A) (hb : b = rowsOf B) :
    (producerHeads A B).card ≤ (rawCompatibleCenters a b).card + (rawCompatibleCenters b a).card := by
  have counted := (Finset.card_union_le _ _ :
    (producerHeads A B).card ≤
      ((compatibleCenters A B).image fun u => (u, B)).card +
      ((compatibleCenters B A).image fun v => (v, A)).card)
  have l := (Finset.card_image_le (s := compatibleCenters A B) (f := fun u => (u, B))).trans
    (Finset.card_le_card (compatibleCentersFromRows A B))
  have r := (Finset.card_image_le (s := compatibleCenters B A) (f := fun v => (v, A))).trans
    (Finset.card_le_card (compatibleCentersFromRows B A))
  rw [ha, hb]
  exact counted.trans (Nat.add_le_add l r)

private theorem costOverlapWithProducerHeadBound (d e a b c f : Finset ℕ) (D B : Finset (Finset ℕ))
    (dEq : d = a ∩ b) (eEq : e = c ∩ f)
    (aD : a ∈ D) (bD : b ∈ D) (cD : c ∈ D) (fD : f ∈ D)
    (aRows : a ⊆ actualRows) (bRows : b ⊆ actualRows)
    (cRows : c ⊆ actualRows) (fRows : f ⊆ actualRows)
    (dNoRoot : ∀ u : Fin 11, ¬rootSet u ⊆ d)
    (eNoRoot : ∀ u : Fin 11, ¬rootSet u ⊆ e)
    (n : ℕ) (nd : n ∈ d) (ne : n ∈ e) (neg : n ∉ edgeRows)
    (repairCount : ∀ label : Finset ℕ → Finset (Fin 11),
      a = rowsOf (label a) → b = rowsOf (label b) →
      c = rowsOf (label c) → f = rowsOf (label f) →
      ((producerHeads (label a) (label b)) ∪ (producerHeads (label c) (label f))).card ≤ 2)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ x ∈ D, ∃ y ∈ D, x ⊂ w ∧ y ⊂ w ∧ w = x ∪ y)
    (pairs : ∀ t ∈ B, ∃ x ∈ D, ∃ y ∈ D,
      t = productTerm x y ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  have dRows : d ⊆ actualRows := by rw [dEq]; exact Finset.inter_subset_left.trans aRows
  have eRows : e ⊆ actualRows := by rw [eEq]; exact Finset.inter_subset_left.trans cRows
  obtain ⟨label, H, missing, replay, roots, builds, heads, covered, omitted, _, tagCost⟩ :=
    actualErasure d e D B dRows eRows build pairs cover
  have ea := untaggedRows d e a ∅ ∅ (label a) (replay a aD) aRows
  have eb := untaggedRows d e b ∅ ∅ (label b) (replay b bD) bRows
  have ec := untaggedRows d e c ∅ ∅ (label c) (replay c cD) cRows
  have ef := untaggedRows d e f ∅ ∅ (label f) (replay f fD) fRows
  have dValue := dEq.trans (congrArg₂ (· ∩ ·) ea eb)
  have eValue := eEq.trans (congrArg₂ (· ∩ ·) ec ef)
  let R := producerHeads (label a) (label b) ∪ producerHeads (label c) (label f)
  have countR : R.card ≤ 2 := repairCount label ea eb ec ef
  have share (A E : Finset (Fin 11)) (w : Finset ℕ) (eq : w = rowsOf A ∩ rowsOf E)
      (noCopy : ∀ u : Fin 11, ¬rootSet u ⊆ w) : Disjoint A E := by
    apply Finset.disjoint_left.mpr
    intro u inA inE
    apply noCopy u
    intro r hr
    rw [eq]
    exact Finset.mem_inter.mpr
      ⟨Finset.mem_biUnion.mpr ⟨u, inA, hr⟩, Finset.mem_biUnion.mpr ⟨u, inE, hr⟩⟩
  have repairs (r : Fin 16) (why : possibleOmission d e r.val) :
      ∃ h ∈ R, ((edgeAt r).1 = h.1 ∧ (edgeAt r).2 ∈ h.2) ∨
        ((edgeAt r).2 = h.1 ∧ (edgeAt r).1 ∈ h.2) := by
    rcases why with ⟨tag, belongs, atTag, u, atU, clean⟩ | ⟨x, hx, y, hy, _, clean⟩
    · rcases Finset.mem_insert.mp belongs with hit | singleton
      · rw [hit, dValue] at atTag clean
        obtain ⟨h, hh, good⟩ := cleanCrossRowCovered _ _
          (share _ _ d dValue dNoRoot) u r atTag atU clean
        exact ⟨h, Finset.mem_union.mpr (Or.inl hh), good⟩
      · have hit := Finset.mem_singleton.mp singleton
        rw [hit, eValue] at atTag clean
        obtain ⟨h, hh, good⟩ := cleanCrossRowCovered _ _
          (share _ _ e eValue eNoRoot) u r atTag atU clean
        exact ⟨h, Finset.mem_union.mpr (Or.inr hh), good⟩
    · have common (w : Finset ℕ) (hw : w ∈ ({d, e} : Finset (Finset ℕ))) : n ∈ w := by
        rcases Finset.mem_insert.mp hw with rfl | singleton
        · exact nd
        · obtain rfl := Finset.mem_singleton.mp singleton
          exact ne
      exact (neg (clean (Finset.mem_inter.mpr
        ⟨Finset.mem_inter.mpr ⟨common x hx, common y hy⟩, dRows nd⟩))).elim
  have accepts (h : Fin 11 × Finset (Fin 11)) (hh : h ∈ H ∪ R) :
      h.2 ∈ D.image label ∧ h.2 ⊆ neighbors h.1 := by
    rcases Finset.mem_union.mp hh with existing | added
    · exact heads h existing
    · have forProducer (x y : Finset ℕ) (hx : x ∈ D) (hy : y ∈ D)
          (got : h ∈ producerHeads (label x) (label y)) :
          h.2 ∈ D.image label ∧ h.2 ⊆ neighbors h.1 := by
        obtain ⟨fromRaw, allowed⟩ := producerHeadValid (label x) (label y) h got
        exact ⟨fromRaw.elim (fun eq => eq.symm ▸ Finset.mem_image_of_mem _ hx)
          (fun eq => eq.symm ▸ Finset.mem_image_of_mem _ hy), allowed⟩
      exact (Finset.mem_union.mp added).elim (forProducer a b aD bD) (forProducer c f cD fD)
  have complete (edge : Fin 11 × Fin 11) (he : edge ∈ orientedEdges) :
      ∃ h ∈ H ∪ R, (edge.1 = h.1 ∧ edge.2 ∈ h.2) ∨ (edge.2 = h.1 ∧ edge.1 ∈ h.2) := by
    rcases covered edge he with lost | ⟨h, hh, good⟩
    · obtain ⟨r, rfl, why⟩ := omitted edge lost
      obtain ⟨h, hh, good⟩ := repairs r why
      exact ⟨h, Finset.mem_union.mpr (Or.inr hh), good⟩
    · exact ⟨h, Finset.mem_union.mpr (Or.inl hh), good⟩
  have lower := pureCost (D.image label) (H ∪ R) builds accepts complete
  have headCount := Finset.card_union_le H R
  have gateCost := projectionUnionDeficit D (markedSeeds d e) label roots
  have redundantTagCount : (redundantTaggedUnions D (markedSeeds d e) label).card ≤
      (redundantUnions D (markedSeeds d e) label).card :=
    Finset.card_le_card (Finset.filter_subset _ _)
  omega

private theorem costOverlapTwoProducerRepairs (d e a b c f : Finset ℕ) (D B : Finset (Finset ℕ))
    (dEq : d = a ∩ b) (eEq : e = c ∩ f)
    (aD : a ∈ D) (bD : b ∈ D) (cD : c ∈ D) (fD : f ∈ D)
    (aRows : a ⊆ actualRows) (bRows : b ⊆ actualRows)
    (cRows : c ⊆ actualRows) (fRows : f ⊆ actualRows)
    (dNoRoot : ∀ u : Fin 11, ¬rootSet u ⊆ d)
    (eNoRoot : ∀ u : Fin 11, ¬rootSet u ⊆ e)
    (n : ℕ) (nd : n ∈ d) (ne : n ∈ e) (neg : n ∉ edgeRows)
    (repairCount : (rawCompatibleCenters a b).card + (rawCompatibleCenters b a).card +
      (rawCompatibleCenters c f).card + (rawCompatibleCenters f c).card ≤ 2)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ x ∈ D, ∃ y ∈ D, x ⊂ w ∧ y ⊂ w ∧ w = x ∪ y)
    (pairs : ∀ t ∈ B, ∃ x ∈ D, ∃ y ∈ D,
      t = productTerm x y ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  apply costOverlapWithProducerHeadBound d e a b c f D B dEq eEq aD bD cD fD
    aRows bRows cRows fRows dNoRoot eNoRoot n nd ne neg _ build pairs cover
  intro label ea eb ec ef
  have left := producerHeadRawBudget a b (label a) (label b) ea eb
  have right := producerHeadRawBudget c f (label c) (label f) ec ef
  apply (Finset.card_union_le _ _).trans
  omega

end PEqualNP.Outside.L_meta_9427
