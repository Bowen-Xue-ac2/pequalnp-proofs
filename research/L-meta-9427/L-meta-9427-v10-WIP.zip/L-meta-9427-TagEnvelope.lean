import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private def negativeRealRows : Finset ℕ := actualRows \ edgeRows

private theorem rowsOfMonotone {A B : Finset (Fin 11)} (included : A ⊆ B) :
    rowsOf A ⊆ rowsOf B := by
  intro n hn
  obtain ⟨u, hu, atU⟩ := Finset.mem_biUnion.mp hn
  exact Finset.mem_biUnion.mpr ⟨u, included hu, atU⟩

private theorem rowsOfBound (A : Finset (Fin 11)) : rowsOf A ⊆ actualRows := by
  intro n hn
  obtain ⟨u, _, atU⟩ := Finset.mem_biUnion.mp hn
  exact rootRowsBound u atU

private theorem completeBetweenRows (A B : Finset (Fin 11))
    (clean : rowsOf A ∩ rowsOf B ⊆ edgeRows) :
    ∀ u ∈ A, ∀ v ∈ B, edge u v := by
  intro u hu v hv
  apply (rootSetPair u v).mp
  intro r hr
  obtain ⟨atU, atV⟩ := Finset.mem_inter.mp hr
  exact clean (Finset.mem_inter.mpr ⟨Finset.mem_biUnion.mpr ⟨u, hu, atU⟩,
    Finset.mem_biUnion.mpr ⟨v, hv, atV⟩⟩)

private def tagCompatibility (t : Finset ℕ) : Finset (Fin 11) :=
  Finset.univ.filter fun u => t ∩ rootSet u ⊆ edgeRows

private def tagEnvelope (t : Finset ℕ) (C : Finset (Fin 11)) : Finset (Finset ℕ) :=
  insert (t ∩ rowsOf C ∩ edgeRows)
    ((C.image fun u => rootSet u ∩ edgeRows) ∪
      ((Finset.univ.filter fun u => 1 < (C ∩ neighbors u).card).image fun u =>
        (t ∪ rootSet u) ∩ rowsOf (C ∩ neighbors u) ∩ edgeRows))

private theorem coveredByTagEnvelope (t : Finset ℕ) (A B : Finset (Fin 11))
    (clean : (rowsOf A ∪ t) ∩ rowsOf B ⊆ edgeRows) :
    ∃ m ∈ tagEnvelope t (tagCompatibility t), (rowsOf A ∪ t) ∩ rowsOf B ⊆ m := by
  let C := tagCompatibility t
  have opposite : B ⊆ C := by
    intro v hv
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
    intro r hr
    obtain ⟨rt, rv⟩ := Finset.mem_inter.mp hr
    exact clean (Finset.mem_inter.mpr ⟨Finset.mem_union_right _ rt,
      Finset.mem_biUnion.mpr ⟨v, hv, rv⟩⟩)
  have cross := completeBetweenRows A B
    ((Finset.inter_subset_inter Finset.subset_union_left Finset.Subset.rfl).trans clean)
  have small (S : Finset (Fin 11)) (alive : S ≠ ∅) (limit : S.card ≤ 1) :
      ∃ u, S = {u} :=
    Finset.card_eq_one.mp (Nat.le_antisymm limit
      (Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr alive)))
  by_cases bEmpty : B = ∅
  · refine ⟨t ∩ rowsOf C ∩ edgeRows, Finset.mem_insert_self _ _, ?_⟩
    simp [bEmpty, rowsOf]
  by_cases bSmall : B.card ≤ 1
  · obtain ⟨u, hu⟩ := small B bEmpty bSmall
    have center : u ∈ C := opposite (by simp [hu])
    refine ⟨rootSet u ∩ edgeRows, Finset.mem_insert_of_mem
      (Finset.mem_union_left _ (Finset.mem_image_of_mem _ center)), ?_⟩
    intro r hr
    exact Finset.mem_inter.mpr ⟨by simpa [rowsOf, hu] using (Finset.mem_inter.mp hr).2, clean hr⟩
  by_cases aEmpty : A = ∅
  · refine ⟨t ∩ rowsOf C ∩ edgeRows, Finset.mem_insert_self _ _, ?_⟩
    intro r hr
    have ht : r ∈ t := by simpa [aEmpty, rowsOf] using (Finset.mem_inter.mp hr).1
    exact Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr
      ⟨ht, rowsOfMonotone opposite (Finset.mem_inter.mp hr).2⟩, clean hr⟩
  have aSmall := (purePairStar A B cross).resolve_right bSmall
  obtain ⟨u, hu⟩ := small A aEmpty aSmall
  have rootIn : u ∈ A := by simp [hu]
  have box : B ⊆ C ∩ neighbors u := fun v hv =>
    Finset.mem_inter.mpr ⟨opposite hv, Finset.mem_filter.mpr ⟨Finset.mem_univ _, cross u rootIn v hv⟩⟩
  have wide : 1 < (C ∩ neighbors u).card := (Nat.lt_of_not_ge bSmall).trans_le (Finset.card_le_card box)
  have pick : u ∈ Finset.univ.filter (fun v : Fin 11 => 1 < (C ∩ neighbors v).card) :=
    Finset.mem_filter.mpr ⟨Finset.mem_univ _, wide⟩
  refine ⟨(t ∪ rootSet u) ∩ rowsOf (C ∩ neighbors u) ∩ edgeRows,
    Finset.mem_insert_of_mem (Finset.mem_union_right _ (Finset.mem_image_of_mem _ pick)), ?_⟩
  intro r hr
  exact Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr
    ⟨by simpa [hu, rowsOf, Finset.union_comm] using (Finset.mem_inter.mp hr).1,
      rowsOfMonotone box (Finset.mem_inter.mp hr).2⟩, clean hr⟩

private theorem tagEnvelopeDependsOnVisibleRows (t : Finset ℕ) (C : Finset (Fin 11)) :
    tagEnvelope (t ∩ rowsOf C) C = tagEnvelope t C := by
  have onSubset (g : Finset ℕ) (A : Finset (Fin 11)) (inside : A ⊆ C) :
      ((t ∩ rowsOf C) ∪ g) ∩ rowsOf A ∩ edgeRows =
        (t ∪ g) ∩ rowsOf A ∩ edgeRows := by
    ext r
    simp only [Finset.mem_inter, Finset.mem_union]
    constructor
    · rintro ⟨⟨tag | plain, right⟩, edge⟩
      · exact ⟨⟨Or.inl tag.1, right⟩, edge⟩
      · exact ⟨⟨Or.inr plain, right⟩, edge⟩
    · rintro ⟨⟨tag | plain, right⟩, edge⟩
      · exact ⟨⟨Or.inl ⟨tag, rowsOfMonotone inside right⟩, right⟩, edge⟩
      · exact ⟨⟨Or.inr plain, right⟩, edge⟩
  have base : t ∩ rowsOf C ∩ rowsOf C ∩ edgeRows = t ∩ rowsOf C ∩ edgeRows := by
    rw [Finset.inter_assoc t (rowsOf C) (rowsOf C), Finset.inter_self]
  unfold tagEnvelope
  rw [base]
  congr 2
  apply Finset.image_congr
  intro u _
  exact onSubset (rootSet u) (C ∩ neighbors u) Finset.inter_subset_left

private theorem compactPureProducer (A : Finset (Fin 11)) :
    ∃ T : Finset (Fin 11), rowsOf A ⊆ rowsOf T ∧
      rowsOf T ∩ negativeRealRows = rowsOf A ∩ negativeRealRows ∧
      ∀ U : Finset (Fin 11),
        rowsOf U ∩ negativeRealRows = rowsOf A ∩ negativeRealRows → rowsOf U ⊆ rowsOf T := by
  let T := Finset.univ.filter fun u : Fin 11 =>
    rootSet u ∩ negativeRealRows ⊆ rowsOf A ∩ negativeRealRows
  have includes (U : Finset (Fin 11))
      (same : rowsOf U ∩ negativeRealRows = rowsOf A ∩ negativeRealRows) : U ⊆ T := by
    intro u hu
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
    intro r hr
    rw [← same]
    exact Finset.mem_inter.mpr
      ⟨Finset.mem_biUnion.mpr ⟨u, hu, (Finset.mem_inter.mp hr).1⟩, (Finset.mem_inter.mp hr).2⟩
  have fromA := rowsOfMonotone (includes A rfl)
  refine ⟨T, fromA, Finset.Subset.antisymm ?_
    (Finset.inter_subset_inter fromA Finset.Subset.rfl), fun U eq => rowsOfMonotone (includes U eq)⟩
  intro r hr
  obtain ⟨atT, neg⟩ := Finset.mem_inter.mp hr
  obtain ⟨u, inT, atU⟩ := Finset.mem_biUnion.mp atT
  exact (Finset.mem_filter.mp inT).2 (Finset.mem_inter.mpr ⟨atU, neg⟩)

end PEqualNP.Outside.L_meta_9427

