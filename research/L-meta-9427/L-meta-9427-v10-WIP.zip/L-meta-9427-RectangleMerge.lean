import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem extendUnionFamily (d e a b : Finset ℕ) (D : Finset (Finset ℕ))
    (aD : a ∈ D) (bD : b ∈ D)
    (bounded : ∀ w ∈ D, w ⊆ Finset.range 42)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ x ∈ D, ∃ y ∈ D, x ⊂ w ∧ y ⊂ w ∧ w = x ∪ y) :
    let E := insert (a ∪ b) D
    D ⊆ E ∧
    (∀ w ∈ E, w ⊆ Finset.range 42) ∧
    (∀ w ∈ E, w ∉ markedSeeds d e →
      ∃ x ∈ E, ∃ y ∈ E, x ⊂ w ∧ y ⊂ w ∧ w = x ∪ y) ∧
    (E \ markedSeeds d e).card ≤ (D \ markedSeeds d e).card + 1 := by
  let E := insert (a ∪ b) D
  change D ⊆ E ∧ _ ∧ _ ∧ _
  have enlarge : D ⊆ E := Finset.subset_insert _ _
  refine ⟨enlarge, ?_, ?_, ?_⟩
  · intro w hw
    rcases Finset.mem_insert.mp hw with rfl | prior
    · exact Finset.union_subset (bounded a aD) (bounded b bD)
    · exact bounded w prior
  · intro w hw notSeed
    by_cases prior : w ∈ D
    · obtain ⟨x, hx, y, hy, xs, ys, eq⟩ := build w prior notSeed
      exact ⟨x, enlarge hx, y, enlarge hy, xs, ys, eq⟩
    obtain rfl := (Finset.mem_insert.mp hw).resolve_right prior
    refine ⟨a, enlarge aD, b, enlarge bD, ?_, ?_, rfl⟩
    · exact Finset.ssubset_iff_subset_ne.mpr
        ⟨Finset.subset_union_left, fun eq => prior (eq ▸ aD)⟩
    · exact Finset.ssubset_iff_subset_ne.mpr
        ⟨Finset.subset_union_right, fun eq => prior (eq ▸ bD)⟩
  · have smaller : E \ markedSeeds d e ⊆ insert (a ∪ b) (D \ markedSeeds d e) := by
      intro w hw
      obtain ⟨inE, paid⟩ := Finset.mem_sdiff.mp hw
      rcases Finset.mem_insert.mp inE with rfl | prior
      · exact Finset.mem_insert_self _ _
      · exact Finset.mem_insert_of_mem (Finset.mem_sdiff.mpr ⟨prior, paid⟩)
    exact (Finset.card_le_card smaller).trans (Finset.card_insert_le _ _)

private theorem replaceTwoWithCoverTerm (D E B : Finset (Finset ℕ))
    (first second added : Finset ℕ) (enlarge : D ⊆ E)
    (firstIn : first ∈ B) (secondIn : second ∈ B) (different : first ≠ second)
    (firstSub : first ⊆ added) (secondSub : second ⊆ added)
    (newTerm : added ∈ Finset.image₂ productTerm E E) (newClean : added ⊆ insert 40 edgeRows)
    (pairs : ∀ t ∈ B, t ∈ Finset.image₂ productTerm D D ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    ∃ C : Finset (Finset ℕ), C.card + 1 ≤ B.card ∧ C.biUnion id = insert 40 edgeRows ∧
      (∀ t ∈ C, t ∈ Finset.image₂ productTerm E E ∧ t ⊆ insert 40 edgeRows ∧
        ∀ q ∈ Finset.image₂ productTerm E E, q ⊆ insert 40 edgeRows → t ⊆ q → q = t) ∧
      (∀ t ∈ C, ∃ r ∈ t, ∀ q ∈ C, r ∈ q → q = t) := by
  let available := (Finset.image₂ productTerm E E).filter fun t => t ⊆ insert 40 edgeRows
  let rest := (B.erase first).erase second
  let next := insert added rest
  have valid : next ⊆ available := by
    intro t ht
    rcases Finset.mem_insert.mp ht with rfl | kept
    · exact Finset.mem_filter.mpr ⟨newTerm, newClean⟩
    · have old := pairs t (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase kept))
      obtain ⟨a, ha, b, hb, eq⟩ := Finset.mem_image₂.mp old.1
      exact Finset.mem_filter.mpr
        ⟨Finset.mem_image₂.mpr ⟨a, enlarge ha, b, enlarge hb, eq⟩, old.2⟩
  have full : next.biUnion id = insert 40 edgeRows := by
    ext r
    constructor
    · intro h
      obtain ⟨t, ht, row⟩ := Finset.mem_biUnion.mp h
      exact (Finset.mem_filter.mp (valid ht)).2 row
    · intro h
      rw [← cover] at h
      obtain ⟨t, ht, row⟩ := Finset.mem_biUnion.mp h
      by_cases isFirst : t = first
      · exact Finset.mem_biUnion.mpr ⟨added, Finset.mem_insert_self _ _, firstSub (isFirst ▸ row)⟩
      by_cases isSecond : t = second
      · exact Finset.mem_biUnion.mpr ⟨added, Finset.mem_insert_self _ _, secondSub (isSecond ▸ row)⟩
      exact Finset.mem_biUnion.mpr ⟨t, Finset.mem_insert_of_mem
        (Finset.mem_erase.mpr ⟨isSecond, Finset.mem_erase.mpr ⟨isFirst, ht⟩⟩), row⟩
  obtain ⟨C, few, fullC, maximal, unique⟩ := maximalPrivateSubcover _ available next
    valid full (fun _ ht => (Finset.mem_filter.mp ht).2)
  have eraseFirst := Finset.card_erase_add_one firstIn
  have eraseSecond := Finset.card_erase_add_one
    (Finset.mem_erase.mpr ⟨Ne.symm different, secondIn⟩)
  change rest.card + 1 = _ at eraseSecond
  have oneNew : next.card ≤ rest.card + 1 := Finset.card_insert_le _ _
  refine ⟨C, by omega, fullC, ?_, unique⟩
  intro t ht
  obtain ⟨found, limit⟩ := maximal t ht
  obtain ⟨contained, clean⟩ := Finset.mem_filter.mp found
  exact ⟨contained, clean,
    fun q hq good grows => limit q (Finset.mem_filter.mpr ⟨hq, good⟩) grows⟩

private theorem productTermMonotone {a b c f : Finset ℕ} (left : a ⊆ c) (right : b ⊆ f) :
    productTerm a b ⊆ productTerm c f := by
  calc
    productTerm a b = productTerm b a := (productTermSymmetry a b).symm
    _ ⊆ productTerm b c := productTermMonotoneRight b a c left
    _ = productTerm c b := productTermSymmetry c b
    _ ⊆ productTerm c f := productTermMonotoneRight c b f right

private theorem mergedRectangleClean (a b c f : Finset ℕ)
    (ab : productTerm a b ⊆ insert 40 edgeRows) (cf : productTerm c f ⊆ insert 40 edgeRows)
    (af : productTerm a f ⊆ insert 40 edgeRows) (cb : productTerm c b ⊆ insert 40 edgeRows) :
    productTerm (a ∪ c) (b ∪ f) ⊆ insert 40 edgeRows := by
  have left : productTerm (a ∪ c) b ⊆ insert 40 edgeRows := by
    rw [← productTermSymmetry (a ∪ c) b]
    exact mergedTermClean b a c
      ((productTermSymmetry a b).symm ▸ ab) ((productTermSymmetry c b).symm ▸ cb)
  have right : productTerm (a ∪ c) f ⊆ insert 40 edgeRows := by
    rw [← productTermSymmetry (a ∪ c) f]
    exact mergedTermClean f a c
      ((productTermSymmetry a f).symm ▸ af) ((productTermSymmetry c f).symm ▸ cf)
  exact mergedTermClean (a ∪ c) b f left right

private def coverRank (d e : Finset ℕ) (D B : Finset (Finset ℕ)) : ℕ :=
  20 * B.card + (D \ markedSeeds d e).card

private theorem cappedCounterexampleWithOptimalFamily (d e : Finset ℕ)
    (required : Finset (Finset ℕ)) (cap : ℕ)
    (witness : ∃ D B, coverScenario d e D B ∧
      (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧ required ⊆ D ∧ B.card ≤ cap) :
    ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧
      required ⊆ D ∧ B.card ≤ cap ∧
      (∀ a ∈ D, ∀ b ∈ D, ∀ c ∈ D, ∀ f ∈ D,
        productTerm a b ∈ B → productTerm c f ∈ B → productTerm a b ≠ productTerm c f →
        ¬(productTerm a f ⊆ insert 40 edgeRows ∧ productTerm c b ⊆ insert 40 edgeRows)) ∧
      ∀ E C, coverScenario d e E C → (E \ markedSeeds d e).card + 2 * C.card ≤ 20 →
        required ⊆ E → C.card ≤ cap → coverRank d e D B ≤ coverRank d e E C := by
  classical
  let cost (D B : Finset (Finset ℕ)) := (D \ markedSeeds d e).card + 2 * B.card
  let attained (n : ℕ) :=
    ∃ D B, coverScenario d e D B ∧ cost D B ≤ 20 ∧ required ⊆ D ∧ B.card ≤ cap ∧
      coverRank d e D B ≤ n
  have existsRank : ∃ n, attained n := by
    obtain ⟨D, B, valid, budget, requiredD, terms⟩ := witness
    exact ⟨coverRank d e D B, D, B, valid, budget, requiredD, terms, le_rfl⟩
  obtain ⟨D, B, scenario, limit, unaltered, capped, best⟩ := Nat.find_spec existsRank
  have optimal (E C : Finset (Finset ℕ)) (valid : coverScenario d e E C)
      (budget : cost E C ≤ 20) (keeps : required ⊆ E) (fits : C.card ≤ cap) :
      coverRank d e D B ≤ coverRank d e E C :=
    best.trans (Nat.find_min' existsRank (show attained (coverRank d e E C) from
      ⟨E, C, valid, budget, keeps, fits, le_rfl⟩))
  refine ⟨D, B, scenario, limit, unaltered, capped, ?_, optimal⟩
  intro a aD b bD c cD f fD first second different crosses
  obtain ⟨dFrom, eFrom, dJunk, eJunk, bounded, build, low, _, maxCount, cover, terms, _⟩ :=
    scenario
  let P := insert (a ∪ c) D
  let E := insert (b ∪ f) P
  obtain ⟨enlarge, boundP, buildP, countP⟩ := extendUnionFamily d e a c D aD cD bounded build
  obtain ⟨enlarge', boundE, buildE, countE⟩ := extendUnionFamily d e b f P
    (enlarge bD) (enlarge fD) boundP buildP
  have oldSubset : D ⊆ E := enlarge.trans enlarge'
  let add := productTerm (a ∪ c) (b ∪ f)
  have addIn : add ∈ Finset.image₂ productTerm E E := Finset.mem_image₂.mpr
    ⟨a ∪ c, enlarge' (Finset.mem_insert_self _ _), b ∪ f, Finset.mem_insert_self _ _, rfl⟩
  have addClean : add ⊆ insert 40 edgeRows := mergedRectangleClean a b c f
    (terms _ first).2.1 (terms _ second).2.1 crosses.1 crosses.2
  obtain ⟨C, smaller, coverC, termsC, privateC⟩ := replaceTwoWithCoverTerm D E B
    _ _ add oldSubset first second different
    (productTermMonotone Finset.subset_union_left Finset.subset_union_left)
    (productTermMonotone Finset.subset_union_right Finset.subset_union_right)
    addIn addClean (fun t ht => ⟨(terms t ht).1, (terms t ht).2.1⟩) cover
  have atLeast : 1 ≤ (E \ markedSeeds d e).card := low.trans (Finset.card_le_card fun _ hw =>
    Finset.mem_sdiff.mpr ⟨oldSubset (Finset.mem_sdiff.mp hw).1, (Finset.mem_sdiff.mp hw).2⟩)
  have positive : 0 < C.card := by
    apply Finset.card_pos.mpr
    have hasMark : 40 ∈ C.biUnion id := by rw [coverC]; exact Finset.mem_insert_self _ _
    obtain ⟨t, ht, _⟩ := Finset.mem_biUnion.mp hasMark
    exact ⟨t, ht⟩
  change (P \ markedSeeds d e).card ≤ (D \ markedSeeds d e).card + 1 at countP
  change (E \ markedSeeds d e).card ≤ (P \ markedSeeds d e).card + 1 at countE
  have costBound : cost E C ≤ cost D B := by dsimp [cost]; omega
  have newLimit := costBound.trans limit
  have gateBound : (E \ markedSeeds d e).card ≤ 18 := by dsimp [cost] at newLimit; omega
  have newScenario : coverScenario d e E C :=
    ⟨plainIntersectionsMono oldSubset dFrom, plainIntersectionsMono oldSubset eFrom,
      dJunk, eJunk, boundE, buildE, atLeast, gateBound, by omega, coverC, termsC, privateC⟩
  have minimal := optimal E C newScenario newLimit (unaltered.trans oldSubset) (by omega)
  dsimp [coverRank] at minimal
  omega

private theorem cappedCounterexampleWithRequiredWords (d e : Finset ℕ)
    (required : Finset (Finset ℕ)) (cap : ℕ)
    (witness : ∃ D B, coverScenario d e D B ∧
      (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧ required ⊆ D ∧ B.card ≤ cap) :
    ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧
      required ⊆ D ∧ B.card ≤ cap ∧
      ∀ a ∈ D, ∀ b ∈ D, ∀ c ∈ D, ∀ f ∈ D,
        productTerm a b ∈ B → productTerm c f ∈ B → productTerm a b ≠ productTerm c f →
        ¬(productTerm a f ⊆ insert 40 edgeRows ∧ productTerm c b ⊆ insert 40 edgeRows) := by
  obtain ⟨D, B, scenario, cost, keeps, few, noRectangle, _⟩ :=
    cappedCounterexampleWithOptimalFamily d e required cap witness
  exact ⟨D, B, scenario, cost, keeps, few, noRectangle⟩

private theorem cappedCounterexampleHasNoCleanRectangle (d e : Finset ℕ) (cap : ℕ)
    (witness : ∃ D B, coverScenario d e D B ∧
      (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧ B.card ≤ cap) :
    ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧ B.card ≤ cap ∧
      ∀ a ∈ D, ∀ b ∈ D, ∀ c ∈ D, ∀ f ∈ D,
        productTerm a b ∈ B → productTerm c f ∈ B → productTerm a b ≠ productTerm c f →
        ¬(productTerm a f ⊆ insert 40 edgeRows ∧ productTerm c b ⊆ insert 40 edgeRows) := by
  have requiresNothing : ∃ D B, coverScenario d e D B ∧
      (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧ ∅ ⊆ D ∧ B.card ≤ cap := by
    obtain ⟨D, B, scenario, cost, few⟩ := witness
    exact ⟨D, B, scenario, cost, Finset.empty_subset _, few⟩
  obtain ⟨D, B, scenario, cost, _, few, noRectangle⟩ :=
    cappedCounterexampleWithRequiredWords d e ∅ cap requiresNothing
  exact ⟨D, B, scenario, cost, few, noRectangle⟩

private theorem minimumCounterexampleHasNoCleanRectangle (d e : Finset ℕ)
    (witness : ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20) :
    ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧
      ∀ a ∈ D, ∀ b ∈ D, ∀ c ∈ D, ∀ f ∈ D,
        productTerm a b ∈ B → productTerm c f ∈ B → productTerm a b ≠ productTerm c f →
        ¬(productTerm a f ⊆ insert 40 edgeRows ∧ productTerm c b ⊆ insert 40 edgeRows) := by
  have capped : ∃ D B, coverScenario d e D B ∧
      (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧ B.card ≤ 9 := by
    obtain ⟨D, B, scenario, limit⟩ := witness
    have termsBound : B.card ≤ 9 := by
      obtain ⟨_, _, _, _, _, _, _, _, count, _, _, _⟩ := scenario
      exact count
    exact ⟨D, B, scenario, limit, termsBound⟩
  obtain ⟨D, B, scenario, limit, _, noRectangle⟩ :=
    cappedCounterexampleHasNoCleanRectangle d e 9 capped
  exact ⟨D, B, scenario, limit, noRectangle⟩

end PEqualNP.Outside.L_meta_9427

