import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def starRestrictedFamily (F : Finset (Finset (Fin 11))) (center : Fin 11) :
    Finset (Finset (Fin 11)) :=
  (F.filter fun k => usableSupport Finset.univ k neighbors) ∪
    F.image (fun k => k ∩ neighbors center)

private theorem starRestrictionCount (F : Finset (Finset (Fin 11))) (center : Fin 11) :
    ((starRestrictedFamily F center).filter fun k => 1 < k.card).card ≤
      (F.filter fun k => 1 < k.card).card := by
  let use (k : Finset (Fin 11)) := usableSupport Finset.univ k neighbors
  let trim (k : Finset (Fin 11)) := k ∩ neighbors center
  let send (k : Finset (Fin 11)) := if use k then k else trim k
  have image : ((starRestrictedFamily F center).filter fun k => 1 < k.card) ⊆
      (F.filter fun k => 1 < k.card).image send := by
    intro k hk
    obtain ⟨listed, large⟩ := Finset.mem_filter.mp hk
    rcases Finset.mem_union.mp listed with before | copied
    · obtain ⟨old, keeps⟩ := Finset.mem_filter.mp before
      exact Finset.mem_image.mpr ⟨k, Finset.mem_filter.mpr ⟨old, large⟩, if_pos keeps⟩
    · obtain ⟨s, hs, rfl⟩ := Finset.mem_image.mp copied
      have plus : 1 < s.card :=
        large.trans_le (Finset.card_le_card (Finset.inter_subset_left : trim s ⊆ s))
      refine Finset.mem_image.mpr ⟨s, Finset.mem_filter.mpr ⟨hs, plus⟩, ?_⟩
      by_cases prior : use s
      · have hSend : send s = s := if_pos prior
        obtain ⟨u, _, us⟩ := prior
        have both : trim s ⊆ neighbors u ∩ neighbors center :=
          fun _ hx => Finset.mem_inter.mpr
            ⟨us (Finset.mem_inter.mp hx).1, (Finset.mem_inter.mp hx).2⟩
        have equal : u = center := by
          by_contra unequal
          have small := (Finset.card_le_card both).trans (commonNeighbors u center unequal)
          exact (Nat.not_le_of_gt large) small
        have unchanged : trim s = s := Finset.inter_eq_left.mpr (equal ▸ us)
        exact hSend.trans unchanged.symm
      · exact if_neg prior
  exact (Finset.card_le_card image).trans Finset.card_image_le

private theorem starRestrictionBuild (F : Finset (Finset (Fin 11))) (center : Fin 11)
    (build : ∀ k ∈ F, 1 < k.card →
      ∃ a ∈ F, ∃ b ∈ F, a ⊂ k ∧ b ⊂ k ∧ k = a ∪ b) :
    ∀ k ∈ starRestrictedFamily F center, 1 < k.card →
      ∃ a ∈ starRestrictedFamily F center, ∃ b ∈ starRestrictedFamily F center,
        a ⊂ k ∧ b ⊂ k ∧ k = a ∪ b := by
  intro k hk large
  let trim (s : Finset (Fin 11)) := s ∩ neighbors center
  rcases Finset.mem_union.mp hk with reuse | copied
  · obtain ⟨old, u, hu, us⟩ := Finset.mem_filter.mp reuse
    obtain ⟨a, ha, b, hb, ai, bi, eq⟩ := build k old large
    exact ⟨a, Finset.mem_union.mpr (Or.inl (Finset.mem_filter.mpr
        ⟨ha, u, hu, ai.1.trans us⟩)),
      b, Finset.mem_union.mpr (Or.inl (Finset.mem_filter.mpr
        ⟨hb, u, hu, bi.1.trans us⟩)), ai, bi, eq⟩
  · obtain ⟨s, hs, eq⟩ := Finset.mem_image.mp copied
    let candidates := F.filter fun s => trim s = k
    have alive : candidates.Nonempty := ⟨s, Finset.mem_filter.mpr ⟨hs, eq⟩⟩
    obtain ⟨s, hs, least⟩ := Finset.exists_min_image candidates Finset.card alive
    obtain ⟨sF, sEq⟩ := Finset.mem_filter.mp hs
    have sLarge : 1 < s.card := by
      rw [← sEq] at large
      exact large.trans_le (Finset.card_le_card (Finset.inter_subset_left : trim s ⊆ s))
    obtain ⟨a, ha, b, hb, ai, bi, together⟩ := build s sF sLarge
    have proper (v : Finset (Fin 11)) (hv : v ∈ F) (small : v ⊂ s) : trim v ⊂ k := by
      apply Finset.ssubset_iff_subset_ne.mpr
      refine ⟨?_, fun same => ?_⟩
      · rw [← sEq]
        exact Finset.inter_subset_inter small.1 Finset.Subset.rfl
      · have inSet : v ∈ candidates := Finset.mem_filter.mpr ⟨hv, same⟩
        exact (Nat.not_lt_of_ge (least v inSet)) (Finset.card_lt_card small)
    refine ⟨trim a, Finset.mem_union.mpr (Or.inr (Finset.mem_image_of_mem _ ha)),
      trim b, Finset.mem_union.mpr (Or.inr (Finset.mem_image_of_mem _ hb)),
      proper a ha ai, proper b hb bi, ?_⟩
    have unionTrim : trim (a ∪ b) = trim a ∪ trim b := Finset.union_inter_distrib_right _ _ _
    calc
      k = trim s := sEq.symm
      _ = trim (a ∪ b) := congrArg trim together
      _ = trim a ∪ trim b := unionTrim

private theorem pureCostWithStarRepair
    (F : Finset (Finset (Fin 11))) (H : Finset (Fin 11 × Finset (Fin 11)))
    (center : Fin 11) (producer : Finset (Fin 11)) (available : producer ∈ F)
    (build : ∀ k ∈ F, 1 < k.card →
      ∃ a ∈ F, ∃ b ∈ F, a ⊂ k ∧ b ⊂ k ∧ k = a ∪ b)
    (heads : ∀ h ∈ H, h.2 ∈ F ∧ h.2 ⊆ neighbors h.1)
    (cover : ∀ f ∈ orientedEdges,
      (f.1 = center ∧ f.2 ∈ producer ∩ neighbors center) ∨
      (f.2 = center ∧ f.1 ∈ producer ∩ neighbors center) ∨
      ∃ h ∈ H, (f.1 = h.1 ∧ f.2 ∈ h.2) ∨ (f.2 = h.1 ∧ f.1 ∈ h.2)) :
    21 ≤ (F.filter fun s => 1 < s.card).card + 2 * H.card := by
  let repair := (center, producer ∩ neighbors center)
  let completed := insert repair H
  have accepted : ∀ h ∈ completed,
      h.2 ∈ starRestrictedFamily F center ∧ h.2 ⊆ neighbors h.1 := by
    intro h hh
    rcases Finset.mem_insert.mp hh with rfl | belongs
    · exact ⟨Finset.mem_union.mpr (Or.inr (Finset.mem_image_of_mem _ available)),
        Finset.inter_subset_right⟩
    · obtain ⟨old, near⟩ := heads h belongs
      exact ⟨Finset.mem_union.mpr (Or.inl (Finset.mem_filter.mpr
        ⟨old, h.1, Finset.mem_univ _, near⟩)), near⟩
  have total (f : Fin 11 × Fin 11) (hf : f ∈ orientedEdges) : ∃ h ∈ completed,
      (f.1 = h.1 ∧ f.2 ∈ h.2) ∨ (f.2 = h.1 ∧ f.1 ∈ h.2) := by
    rcases cover f hf with left | right | ⟨h, hh, kept⟩
    · exact ⟨repair, Finset.mem_insert_self _ _, Or.inl left⟩
    · exact ⟨repair, Finset.mem_insert_self _ _, Or.inr right⟩
    · exact ⟨h, Finset.mem_insert_of_mem hh, kept⟩
  have cost := pureCost (starRestrictedFamily F center) completed
    (starRestrictionBuild F center build) accepted total
  have gateCount := starRestrictionCount F center
  have headCount : completed.card ≤ H.card + 1 := Finset.card_insert_le _ _
  omega

end PEqualNP.Outside.L_meta_9427
