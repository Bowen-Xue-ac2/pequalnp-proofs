#define PNP_PROFILE_LIBRARY_ONLY
#include "L-meta-9427-five-term-profiles.cpp"

int main() {
    initialize();
    std::set<Word> pure(words.begin() + 1, words.end());
    std::set<Word> tags;
    for (auto a = pure.begin(); a != pure.end(); ++a) {
        for (auto b = a; b != pure.end(); ++b) {
            if (*a & *b & negative) {
                tags.insert(*a & *b);
            }
        }
    }
    std::array<std::map<Edges, Word>, roots.size()> missing;
    unsigned count = 0;
    for (Word d : tags) {
        const Support comp = compatible(d);
        if (!comp) {
            continue;
        }
        Support whole = 0;
        for (unsigned i = 0; i < roots.size(); ++i) {
            if ((d & roots[i]) == roots[i]) {
                whole |= 1u << i;
            }
        }
        if (std::popcount(whole) != 1) {
            continue;
        }
        ++count;
        const unsigned u = std::countr_zero(whole);
        const Edges omit = Edges(d & words[comp] & ~roots[u]) & positive;
        missing[u].try_emplace(omit, d);
    }
    std::cout << "single-root tag masks " << count << '\n';
    for (unsigned i = 0; i < roots.size(); ++i) {
        unsigned largest = 0;
        unsigned needsCharge = 0;
        for (const auto& [omit,d] : missing[i]) {
            const auto left = positive & ~omit;
            const unsigned pure = std::popcount(left) + minimum_pure[left];
            largest = std::max(largest, unsigned(std::popcount(omit)));
            if (pure < 21) {
                ++needsCharge;
                std::cout << "root " << i << " omission " << omit << " retained bound " << pure
                          << " representative " << d << '\n';
            }
        }
        std::cout << "root " << i << ", distinct shapes " << missing[i].size()
                  << ", max missing " << largest << ", need charge " << needsCharge << '\n';
    }
}

