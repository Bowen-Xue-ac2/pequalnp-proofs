#include <algorithm>
#include <bit>
#include <cstdint>
#include <iostream>
#include <set>
#include <unordered_map>
#include <vector>

using Mask = std::uint64_t;
constexpr Mask tag_d = Mask{1} << 40;
constexpr Mask tag_e = Mask{1} << 41;
constexpr Mask low = (Mask{1} << 16) - 1;
constexpr Mask negatives = (tag_d - 1) ^ low;
constexpr unsigned target = (1u << 17) - 1;
constexpr int or_limit = 2;
constexpr int cover_limit = 9;
const std::vector<Mask> vertices = {
    2147418115, 663661903884, 34144976944, 728266375360,
    21653750532, 103293914128, 26322415680, 344922804352,
    414195942664, 581968119809, 1065151898146,
};

// Proper-subset OR children precede their parent. Untagged nodes have only
// untagged ancestors, so they can be enumerated before choosing the two
// tagged intersections. Making all seeds available costs no OR gates.
std::vector<Mask> unions(const std::vector<Mask>& wires, bool tagged) {
    std::vector<Mask> result;
    for (std::size_t i = 0; i < wires.size(); ++i) {
        for (std::size_t j = i + 1; j < wires.size(); ++j) {
            const Mask a = wires[i];
            const Mask b = wires[j];
            const Mask c = a | b;
            if (c == a || c == b || (bool(c & (tag_d | tag_e)) != tagged)) {
                continue;
            }
            if (std::find(wires.begin(), wires.end(), c) == wires.end()) {
                result.push_back(c);
            }
        }
    }
    std::sort(result.begin(), result.end());
    result.erase(std::unique(result.begin(), result.end()), result.end());
    return result;
}

bool cover(const std::vector<unsigned>& terms, unsigned uncovered, int left,
           std::unordered_map<unsigned, int>& impossible, std::vector<unsigned>& chosen) {
    if (!uncovered) {
        return true;
    }
    if (!left || (impossible.contains(uncovered) && impossible[uncovered] >= left)) {
        return false;
    }
    int fewest = int(terms.size()) + 1;
    unsigned edge = 0;
    for (unsigned bit = 1; bit <= (1u << 16); bit <<= 1) {
        if (uncovered & bit) {
            int n = std::ranges::count_if(terms, [bit](unsigned t) { return t & bit; });
            if (n < fewest) {
                fewest = n;
                edge = bit;
            }
        }
    }
    for (unsigned t : terms) {
        if (t & edge) {
            chosen.push_back(t);
            if (cover(terms, uncovered & ~t, left - 1, impossible, chosen)) {
                return true;
            }
            chosen.pop_back();
        }
    }
    impossible[uncovered] = left;
    return false;
}

struct Search {
    std::uint64_t families = 0;
    std::uint64_t covers_checked = 0;

    bool inspect(Mask d, Mask e, const std::vector<Mask>& wires, bool tags_merged) {
        ++families;
        if (!tags_merged && (d & e & negatives)) {
            return false;
        }
        std::vector<unsigned> terms;
        unsigned available = 0;
        for (std::size_t i = 0; i < wires.size(); ++i) {
            for (std::size_t j = i; j < wires.size(); ++j) {
                const Mask a = wires[i];
                const Mask b = wires[j];
                if (a & b & negatives) {
                    continue;
                }
                unsigned t = unsigned(a & b & low);
                if (((a | b) & (tag_d | tag_e)) == (tag_d | tag_e)) {
                    t |= 1u << 16;
                }
                if (t) {
                    terms.push_back(t);
                    available |= t;
                }
            }
        }
        if (available != target) {
            return false;
        }
        std::sort(terms.begin(), terms.end());
        terms.erase(std::unique(terms.begin(), terms.end()), terms.end());
        std::vector<unsigned> maximal;
        for (unsigned t : terms) {
            if (!std::ranges::any_of(terms, [t](unsigned s) { return s != t && (s | t) == s; })) {
                maximal.push_back(t);
            }
        }
        std::sort(maximal.begin(), maximal.end(), [](unsigned a, unsigned b) {
            return std::popcount(a) > std::popcount(b);
        });
        int upper = 0;
        for (std::size_t i = 0; i < maximal.size() && i < cover_limit; ++i) {
            upper += std::popcount(maximal[i]);
        }
        if (upper < std::popcount(target)) {
            return false;
        }
        ++covers_checked;
        std::vector<unsigned> chosen;
        std::unordered_map<unsigned, int> impossible;
        if (!cover(maximal, target, cover_limit, impossible, chosen)) {
            return false;
        }
        std::cout << "candidate d=" << d << " e=" << e << " wires:";
        for (Mask wire : wires) {
            std::cout << ' ' << wire;
        }
        std::cout << " cover:";
        for (unsigned t : chosen) {
            const Mask actual = (t & low) | ((t >> 16) ? tag_d : 0);
            std::cout << ' ' << actual;
        }
        std::cout << '\n';
        return true;
    }

    bool tagged(Mask d, Mask e, std::vector<Mask>& wires, int used, bool tags_merged) {
        if (used && inspect(d, e, wires, tags_merged)) {
            return true;
        }
        if (used == or_limit) {
            return false;
        }
        for (Mask value : unions(wires, true)) {
            wires.push_back(value);
            const bool merged = (value & (tag_d | tag_e)) == (tag_d | tag_e);
            if (tagged(d, e, wires, used + 1, tags_merged || merged)) {
                return true;
            }
            wires.pop_back();
        }
        return false;
    }
};

int main() {
    Search search;
    std::vector<Mask> seeds = vertices;
    std::sort(seeds.begin(), seeds.end());
    std::set<std::vector<Mask>> current{seeds};
    for (int r = 0; r <= or_limit; ++r) {
        std::set<std::vector<Mask>> next;
        for (const auto& untagged : current) {
            std::set<Mask> junk;
            for (Mask a : untagged) {
                for (Mask b : untagged) {
                    if (a & b & negatives) {
                        junk.insert(a & b);
                    }
                }
            }
            for (auto d = junk.begin(); d != junk.end(); ++d) {
                for (auto e = d; e != junk.end(); ++e) {
                    std::vector<Mask> wires = untagged;
                    wires.push_back(*d | tag_d);
                    wires.push_back(*e | tag_e);
                    if (search.tagged(*d, *e, wires, r, false)) {
                        return 1;
                    }
                }
            }
            if (r < or_limit) {
                for (Mask value : unions(untagged, false)) {
                    auto family = untagged;
                    family.push_back(value);
                    std::sort(family.begin(), family.end());
                    next.insert(std::move(family));
                }
            }
        }
        std::cout << "untagged_ORs=" << r << " untagged_families=" << current.size()
                  << " total_families=" << search.families
                  << " full_cover_tests=" << search.covers_checked << std::endl;
        current = std::move(next);
    }
    std::cout << "No cover with at most two OR gates and nine cover terms.\n";
}
