import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem markedTermsByPaidCount (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (operand : {t // t ∈ B} × Bool → {w // w ∈ D}) (distinct : Function.Injective operand) :
    (B.attach.filter (fun t =>
        carriesTag (operand (t, false)).val ∨ carriesTag (operand (t, true)).val)).card ≤
      ((D \ markedSeeds d e).filter carriesTag).card + 2 := by
  classical
  let marked := B.attach.filter fun t =>
    carriesTag (operand (t, false)).val ∨ carriesTag (operand (t, true)).val
  let choice (t : {t // t ∈ B}) :=
    (t, !decide (carriesTag (operand (t, false)).val))
  let pick (t : {t // t ∈ B}) := (operand (choice t)).val
  have picksDistinct : Set.InjOn pick (marked : Set {t // t ∈ B}) := by
    intro a _ b _ eq
    exact congrArg Prod.fst (distinct (Subtype.ext eq))
  have picksTagged : marked.image pick ⊆ D.filter carriesTag := by
    intro w hw
    obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hw
    refine Finset.mem_filter.mpr ⟨(operand (choice t)).property, ?_⟩
    have either := (Finset.mem_filter.mp ht).2
    by_cases left : carriesTag (operand (t, false)).val
    · simpa [pick, choice, left]
    · simpa [pick, choice, left] using either.resolve_left left
  let paid := (D \ markedSeeds d e).filter carriesTag
  let taggedSeeds : Finset (Finset ℕ) := {insert 40 d, insert 41 e}
  have allCounted : D.filter carriesTag ⊆ paid ∪ taggedSeeds := by
    intro w hw
    obtain ⟨wD, mark⟩ := Finset.mem_filter.mp hw
    by_cases seed : w ∈ markedSeeds d e
    · simp only [markedSeeds, Finset.mem_insert] at seed
      rcases seed with rfl | rfl | base
      · exact Finset.mem_union_right _ (Finset.mem_insert_self _ _)
      · exact Finset.mem_union_right _ (Finset.mem_insert_of_mem (Finset.mem_singleton_self _))
      · obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp base
        rcases mark with h | h
        · exact ((show 40 ∉ actualRows by decide) (rootRowsBound v h)).elim
        · exact ((show 41 ∉ actualRows by decide) (rootRowsBound v h)).elim
    · exact Finset.mem_union_left _ (Finset.mem_filter.mpr ⟨Finset.mem_sdiff.mpr ⟨wD, seed⟩, mark⟩)
  have seeds : taggedSeeds.card ≤ 2 := by
    exact (Finset.card_insert_le _ _).trans (by simp)
  change marked.card ≤ paid.card + 2
  calc
    marked.card = (marked.image pick).card := (Finset.card_image_of_injOn picksDistinct).symm
    _ ≤ (D.filter carriesTag).card := Finset.card_le_card picksTagged
    _ ≤ (paid ∪ taggedSeeds).card := Finset.card_le_card allCounted
    _ ≤ paid.card + taggedSeeds.card := Finset.card_union_le _ _
    _ ≤ paid.card + 2 := Nat.add_le_add_left seeds _

private theorem pureTermBudget (D : Finset (Finset (Fin 11)))
    (H : Finset (Fin 11 × Finset (Fin 11))) (E : Finset (Fin 11 × Fin 11))
    (unionBudget termBudget : ℕ)
    (edges : E ⊆ orientedEdges)
    (paid : (D.filter fun s => 1 < s.card).card ≤ unionBudget)
    (terms : H.card ≤ termBudget)
    (build : ∀ w ∈ D, 1 < w.card →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (heads : ∀ h ∈ H, h.2 ∈ D ∧ h.2 ⊆ neighbors h.1)
    (covers : ∀ f ∈ E, ∃ h ∈ H,
      (f.1 = h.1 ∧ f.2 ∈ h.2) ∨ (f.2 = h.1 ∧ f.1 ∈ h.2)) :
    E.card ≤ unionBudget + termBudget ∧
      ∃ C : Finset (Fin 11), C.card ≤ termBudget ∧
        ∀ f ∈ E, f.1 ∈ C ∨ f.2 ∈ C := by
  exact ⟨(purePartialCost D H E edges build heads covers).trans (Nat.add_le_add paid terms),
    H.image Prod.fst, Finset.card_image_le.trans terms, coverCenters H E covers⟩

end PEqualNP.Outside.L_meta_9427

