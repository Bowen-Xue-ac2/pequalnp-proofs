import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem maximalPrivateSubcover {α : Type} [DecidableEq α]
    (room : Finset α) (T C : Finset (Finset α))
    (sub : C ⊆ T) (full : C.biUnion id = room)
    (bounds : ∀ t ∈ T, t ⊆ room) :
    ∃ B : Finset (Finset α), B.card ≤ C.card ∧ B.biUnion id = room ∧
      (∀ t ∈ B, t ∈ T ∧ ∀ q ∈ T, t ⊆ q → q = t) ∧
      ∀ t ∈ B, ∃ r ∈ t, ∀ q ∈ B, r ∈ q → q = t := by
  classical
  have maximal (t : Finset α) (ht : t ∈ C) :
      ∃ q ∈ T, t ⊆ q ∧ ∀ r ∈ T, q ⊆ r → r = q := by
    let extensions := T.filter fun q => t ⊆ q
    have alive : extensions.Nonempty := ⟨t, Finset.mem_filter.mpr ⟨sub ht, Finset.Subset.rfl⟩⟩
    obtain ⟨q, hq, optimal⟩ := Finset.exists_max_image extensions Finset.card alive
    obtain ⟨qT, grows⟩ := Finset.mem_filter.mp hq
    refine ⟨q, qT, grows, ?_⟩
    intro r hr qr
    have rExt : r ∈ extensions := Finset.mem_filter.mpr ⟨hr, grows.trans qr⟩
    exact (Finset.eq_of_subset_of_card_le qr (optimal r rExt)).symm
  let chooseTerm (t : Finset α) := if ht : t ∈ C then (maximal t ht).choose else ∅
  have chosen (t : Finset α) (ht : t ∈ C) :
      chooseTerm t ∈ T ∧ t ⊆ chooseTerm t ∧
        ∀ q ∈ T, chooseTerm t ⊆ q → q = chooseTerm t := by
    simpa [chooseTerm, ht] using (maximal t ht).choose_spec
  let wide := C.image chooseTerm
  have wideMax (t : Finset α) (ht : t ∈ wide) :
      t ∈ T ∧ ∀ q ∈ T, t ⊆ q → q = t := by
    obtain ⟨r, hr, rfl⟩ := Finset.mem_image.mp ht
    exact ⟨(chosen r hr).1, (chosen r hr).2.2⟩
  have wideCover : wide.biUnion id = room := by
    ext x
    constructor
    · intro hx
      obtain ⟨t, ht, atT⟩ := Finset.mem_biUnion.mp hx
      exact bounds t (wideMax t ht).1 atT
    · intro hx
      rw [← full] at hx
      obtain ⟨t, ht, atT⟩ := Finset.mem_biUnion.mp hx
      exact Finset.mem_biUnion.mpr ⟨chooseTerm t, Finset.mem_image_of_mem _ ht, (chosen t ht).2.1 atT⟩
  let candidates := wide.powerset.filter fun D => D.biUnion id = room
  have alive : candidates.Nonempty :=
    ⟨wide, Finset.mem_filter.mpr ⟨Finset.mem_powerset.mpr Finset.Subset.rfl, wideCover⟩⟩
  obtain ⟨B, hB, best⟩ := Finset.exists_min_image candidates Finset.card alive
  obtain ⟨small, fullB⟩ := Finset.mem_filter.mp hB
  have leWide : B ⊆ wide := Finset.mem_powerset.mp small
  refine ⟨B, (Finset.card_le_card leWide).trans Finset.card_image_le, fullB,
    fun t ht => wideMax t (leWide ht), ?_⟩
  intro t ht
  by_contra noPrivate
  have smaller := Finset.card_lt_card (Finset.erase_ssubset ht)
  have other (r : α) (hr : r ∈ t) : ∃ q ∈ B.erase t, r ∈ q := by
    by_contra noOther
    apply noPrivate
    refine ⟨r, hr, fun q hq hit => ?_⟩
    by_contra different
    exact noOther ⟨q, Finset.mem_erase.mpr ⟨different, hq⟩, hit⟩
  have equal : (B.erase t).biUnion id = room := by
    ext r
    constructor
    · intro h
      rw [← fullB]
      obtain ⟨q, hq, row⟩ := Finset.mem_biUnion.mp h
      exact Finset.mem_biUnion.mpr ⟨q, Finset.mem_of_mem_erase hq, row⟩
    · intro h
      rw [← fullB] at h
      obtain ⟨q, hq, row⟩ := Finset.mem_biUnion.mp h
      by_cases same : q = t
      · obtain ⟨r', hr', hit⟩ := other r (same ▸ row)
        exact Finset.mem_biUnion.mpr ⟨r', hr', hit⟩
      · exact Finset.mem_biUnion.mpr ⟨q, Finset.mem_erase.mpr ⟨same, hq⟩, row⟩
  have admitted : B.erase t ∈ candidates := Finset.mem_filter.mpr
    ⟨Finset.mem_powerset.mpr ((Finset.erase_subset t B).trans leWide), equal⟩
  exact (Nat.not_lt_of_ge (best _ admitted)) smaller

private theorem productTermMonotoneRight (a b c : Finset ℕ) (bc : b ⊆ c) :
    productTerm a b ⊆ productTerm a c := by
  intro r hr
  rcases Finset.mem_union.mp hr with real | marker
  · obtain ⟨both, actual⟩ := Finset.mem_inter.mp real
    obtain ⟨inA, inB⟩ := Finset.mem_inter.mp both
    exact Finset.mem_union.mpr (Or.inl (Finset.mem_inter.mpr
      ⟨Finset.mem_inter.mpr ⟨inA, bc inB⟩, actual⟩))
  · have flag : {40,41} ⊆ a ∪ b := by
      by_contra impossible
      simp [impossible] at marker
    have grows := flag.trans (Finset.union_subset_union Finset.Subset.rfl bc)
    exact Finset.mem_union.mpr (Or.inr (by simpa only [ite_eq_left flag, ite_eq_left grows] using marker))

private theorem mergedTermClean (a b c : Finset ℕ)
    (first : productTerm a b ⊆ insert 40 edgeRows) (second : productTerm a c ⊆ insert 40 edgeRows) :
    productTerm a (b ∪ c) ⊆ insert 40 edgeRows := by
  intro r hr
  rcases Finset.mem_union.mp hr with normal | marker
  · obtain ⟨both, actual⟩ := Finset.mem_inter.mp normal
    obtain ⟨inA, other⟩ := Finset.mem_inter.mp both
    rcases Finset.mem_union.mp other with inB | inC
    · exact first (Finset.mem_union.mpr (Or.inl (Finset.mem_inter.mpr
        ⟨Finset.mem_inter.mpr ⟨inA, inB⟩, actual⟩)))
    · exact second (Finset.mem_union.mpr (Or.inl (Finset.mem_inter.mpr
        ⟨Finset.mem_inter.mpr ⟨inA, inC⟩, actual⟩)))
  · split at marker
    · exact Finset.mem_insert.mpr (Or.inl (Finset.mem_singleton.mp marker))
    · exact (Finset.notMem_empty _ marker).elim

private theorem mergeRepeatedOperand (d e a b c : Finset ℕ) (D B : Finset (Finset ℕ))
    (aD : a ∈ D) (bD : b ∈ D) (cD : c ∈ D)
    (first : productTerm a b ∈ B) (second : productTerm a c ∈ B)
    (different : productTerm a b ≠ productTerm a c)
    (bounded : ∀ t ∈ D, t ⊆ Finset.range 42)
    (build : ∀ t ∈ D, t ∉ markedSeeds d e →
      ∃ x ∈ D, ∃ y ∈ D, x ⊂ t ∧ y ⊂ t ∧ t = x ∪ y)
    (pairs : ∀ t ∈ B, t ∈ Finset.image₂ productTerm D D ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    ∃ D' B' : Finset (Finset ℕ), D ⊆ D' ∧
      (∀ t ∈ D', t ⊆ Finset.range 42) ∧
      (∀ t ∈ D', t ∉ markedSeeds d e →
        ∃ x ∈ D', ∃ y ∈ D', x ⊂ t ∧ y ⊂ t ∧ t = x ∪ y) ∧
      B'.card + 1 ≤ B.card ∧ B'.biUnion id = insert 40 edgeRows ∧
      (∀ t ∈ B', t ∈ Finset.image₂ productTerm D' D' ∧ t ⊆ insert 40 edgeRows ∧
        ∀ r ∈ Finset.image₂ productTerm D' D', r ⊆ insert 40 edgeRows → t ⊆ r → r = t) ∧
      (∀ t ∈ B', ∃ r ∈ t, ∀ q ∈ B', r ∈ q → q = t) ∧
      (D' \ markedSeeds d e).card + 2 * B'.card + 1 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  let w := b ∪ c
  let D' := insert w D
  let P := Finset.image₂ productTerm D' D'
  let T := P.filter fun t => t ⊆ insert 40 edgeRows
  let merged := productTerm a w
  let rest := (B.erase (productTerm a b)).erase (productTerm a c)
  let C := insert merged rest
  have enlarge : D ⊆ D' := Finset.subset_insert _ _
  have allBounded (t : Finset ℕ) (ht : t ∈ D') : t ⊆ Finset.range 42 := by
    rcases Finset.mem_insert.mp ht with rfl | old
    · exact Finset.union_subset (bounded b bD) (bounded c cD)
    · exact bounded t old
  have newBuild (t : Finset ℕ) (ht : t ∈ D') (notSeed : t ∉ markedSeeds d e) :
      ∃ x ∈ D', ∃ y ∈ D', x ⊂ t ∧ y ⊂ t ∧ t = x ∪ y := by
    by_cases before : t ∈ D
    · obtain ⟨x, hx, y, hy, xs, ys, eq⟩ := build t before notSeed
      exact ⟨x, enlarge hx, y, enlarge hy, xs, ys, eq⟩
    obtain rfl := (Finset.mem_insert.mp ht).resolve_right before
    refine ⟨b, enlarge bD, c, enlarge cD, ?_, ?_, rfl⟩
    · exact Finset.ssubset_iff_subset_ne.mpr ⟨Finset.subset_union_left, fun eq => before (eq ▸ bD)⟩
    · exact Finset.ssubset_iff_subset_ne.mpr ⟨Finset.subset_union_right, fun eq => before (eq ▸ cD)⟩
  have inT : C ⊆ T := by
    intro q hq
    rcases Finset.mem_insert.mp hq with rfl | old
    · exact Finset.mem_filter.mpr
        ⟨Finset.mem_image₂.mpr ⟨a, enlarge aD, w, Finset.mem_insert_self _ _, rfl⟩,
          mergedTermClean a b c (pairs _ first).2 (pairs _ second).2⟩
    · have original := pairs q (Finset.mem_of_mem_erase (Finset.mem_of_mem_erase old))
      obtain ⟨x, xD, y, yD, eq⟩ := Finset.mem_image₂.mp original.1
      exact Finset.mem_filter.mpr ⟨Finset.mem_image₂.mpr ⟨x, enlarge xD, y, enlarge yD, eq⟩, original.2⟩
  have hasRows : C.biUnion id = insert 40 edgeRows := by
    ext r
    constructor
    · intro h
      obtain ⟨q, hq, row⟩ := Finset.mem_biUnion.mp h
      exact (Finset.mem_filter.mp (inT hq)).2 row
    · intro h
      rw [← cover] at h
      obtain ⟨q, hq, hit⟩ := Finset.mem_biUnion.mp h
      by_cases eq : q = productTerm a b
      · exact Finset.mem_biUnion.mpr ⟨merged, Finset.mem_insert_self _ _,
          productTermMonotoneRight a b w Finset.subset_union_left (eq ▸ hit)⟩
      by_cases eq' : q = productTerm a c
      · exact Finset.mem_biUnion.mpr ⟨merged, Finset.mem_insert_self _ _,
          productTermMonotoneRight a c w Finset.subset_union_right (eq' ▸ hit)⟩
      exact Finset.mem_biUnion.mpr ⟨q, Finset.mem_insert_of_mem
        (Finset.mem_erase.mpr ⟨eq', Finset.mem_erase.mpr ⟨eq, hq⟩⟩), hit⟩
  obtain ⟨B', few, coverage, maximal, privateRows⟩ := maximalPrivateSubcover _ T C
    inT hasRows (fun _ h => (Finset.mem_filter.mp h).2)
  have secondLeft : productTerm a c ∈ B.erase (productTerm a b) :=
    Finset.mem_erase.mpr ⟨Ne.symm different, second⟩
  have eraseFirst := Finset.card_erase_add_one first
  have eraseSecond := Finset.card_erase_add_one secondLeft
  have addOne : C.card ≤ rest.card + 1 := Finset.card_insert_le _ _
  change rest.card + 1 = _ at eraseSecond
  have fewer : B'.card + 1 ≤ B.card := by omega
  have gateCount : (D' \ markedSeeds d e).card ≤ (D \ markedSeeds d e).card + 1 := by
    have contained : D' \ markedSeeds d e ⊆ insert w (D \ markedSeeds d e) := by
      intro t ht
      obtain ⟨tD, paid⟩ := Finset.mem_sdiff.mp ht
      rcases Finset.mem_insert.mp tD with rfl | old
      · exact Finset.mem_insert_self _ _
      · exact Finset.mem_insert_of_mem (Finset.mem_sdiff.mpr ⟨old, paid⟩)
    exact (Finset.card_le_card contained).trans (Finset.card_insert_le _ _)
  refine ⟨D', B', enlarge, allBounded, newBuild, fewer, coverage, ?_, privateRows, by omega⟩
  intro t ht
  obtain ⟨inTerms, max⟩ := maximal t ht
  obtain ⟨before, clean⟩ := Finset.mem_filter.mp inTerms
  exact ⟨before, clean, fun r rOld rClean grows => max r (Finset.mem_filter.mpr ⟨rOld, rClean⟩) grows⟩

private def plainIntersections (D : Finset (Finset ℕ)) : Finset (Finset ℕ) :=
  let untagged := D.filter (· ⊆ actualRows)
  Finset.image₂ (· ∩ ·) untagged untagged

private def coverScenario (d e : Finset ℕ) (D B : Finset (Finset ℕ)) : Prop :=
  d ∈ plainIntersections D ∧ e ∈ plainIntersections D ∧
  ¬d ⊆ edgeRows ∧ ¬e ⊆ edgeRows ∧
  (∀ w ∈ D, w ⊆ Finset.range 42) ∧
  (∀ w ∈ D, w ∉ markedSeeds d e →
    ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) ∧
  1 ≤ (D \ markedSeeds d e).card ∧ (D \ markedSeeds d e).card ≤ 18 ∧ B.card ≤ 9 ∧
  B.biUnion id = insert 40 edgeRows ∧
  (∀ t ∈ B, t ∈ Finset.image₂ productTerm D D ∧ t ⊆ insert 40 edgeRows ∧
    ∀ q ∈ Finset.image₂ productTerm D D, q ⊆ insert 40 edgeRows → t ⊆ q → q = t) ∧
  (∀ t ∈ B, ∃ r ∈ t, ∀ q ∈ B, r ∈ q → q = t)

private theorem plainIntersectionsMono {D E : Finset (Finset ℕ)} (h : D ⊆ E) :
    plainIntersections D ⊆ plainIntersections E := by
  intro t hT
  obtain ⟨a, ha, b, hb, rfl⟩ := Finset.mem_image₂.mp hT
  obtain ⟨haD, haRows⟩ := Finset.mem_filter.mp ha
  obtain ⟨hbD, hbRows⟩ := Finset.mem_filter.mp hb
  exact Finset.mem_image₂.mpr
    ⟨a, Finset.mem_filter.mpr ⟨h haD, haRows⟩, b, Finset.mem_filter.mpr ⟨h hbD, hbRows⟩, rfl⟩

private theorem productTermSymmetry (a b : Finset ℕ) : productTerm b a = productTerm a b := by
  unfold productTerm
  rw [Finset.inter_comm b a, Finset.union_comm b a]

private theorem minimalCounterexampleSeparate (d e : Finset ℕ)
    (witness : ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20) :
    ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧
      ∀ a ∈ D, ∀ b ∈ D, ∀ c ∈ D, productTerm a b ∈ B → productTerm a c ∈ B →
        productTerm a b = productTerm a c := by
  classical
  let cost (D B : Finset (Finset ℕ)) := (D \ markedSeeds d e).card + 2 * B.card
  let attainable (n : ℕ) := ∃ D B, coverScenario d e D B ∧ cost D B ≤ n
  have nonempty : ∃ n, attainable n := ⟨20, witness⟩
  obtain ⟨D, B, scenario, minimal⟩ := Nat.find_spec nonempty
  have limit : cost D B ≤ 20 := minimal.trans (Nat.find_min' nonempty witness)
  refine ⟨D, B, scenario, limit, ?_⟩
  intro a aD b bD c cD first second
  by_contra different
  obtain ⟨dFrom, eFrom, dJunk, eJunk, bounded, build, low, _, kBound, cover, terms, _⟩ :=
    scenario
  obtain ⟨E, C, enlarge, bounded', build', fewer, cover', terms', private', reduced⟩ :=
    mergeRepeatedOperand d e a b c D B aD bD cD first second different bounded build
      (fun t ht => ⟨(terms t ht).1, (terms t ht).2.1⟩) cover
  have keepsPaid : D \ markedSeeds d e ⊆ E \ markedSeeds d e := fun _ hw =>
    Finset.mem_sdiff.mpr ⟨enlarge (Finset.mem_sdiff.mp hw).1, (Finset.mem_sdiff.mp hw).2⟩
  have atLeast : 1 ≤ (E \ markedSeeds d e).card := low.trans (Finset.card_le_card keepsPaid)
  have termsAlive : 0 < C.card := by
    apply Finset.card_pos.mpr
    have synthetic : 40 ∈ C.biUnion id := by
      rw [cover']
      exact Finset.mem_insert_self _ _
    obtain ⟨t, ht, _⟩ := Finset.mem_biUnion.mp synthetic
    exact ⟨t, ht⟩
  change (E \ markedSeeds d e).card + 2 * C.card + 1 ≤ cost D B at reduced
  have limit' : (E \ markedSeeds d e).card ≤ 18 := by omega
  have scenario' : coverScenario d e E C :=
    ⟨plainIntersectionsMono enlarge dFrom, plainIntersectionsMono enlarge eFrom,
      dJunk, eJunk, bounded', build', atLeast, limit', by omega, cover', terms', private'⟩
  have attainable' : attainable (cost E C) := ⟨E, C, scenario', Nat.le_refl _⟩
  have optimal := Nat.find_min' nonempty attainable'
  change cost E C + 1 ≤ cost D B at reduced
  omega

private theorem plainIntersectionsBound (D : Finset (Finset ℕ)) (w : Finset ℕ)
    (fromPlain : w ∈ plainIntersections D) : w ⊆ actualRows := by
  obtain ⟨a, ha, b, _, rfl⟩ := Finset.mem_image₂.mp fromPlain
  exact Finset.inter_subset_left.trans (Finset.mem_filter.mp ha).2

private theorem everyOperandDirty (d e : Finset ℕ) (D : Finset (Finset ℕ))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (dJunk : ¬d ⊆ edgeRows) (eJunk : ¬e ⊆ edgeRows)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) :
    ∀ w ∈ D, ¬w ∩ actualRows ⊆ edgeRows := by
  have roots : ∀ u : Fin 11, ¬rootSet u ⊆ edgeRows := by decide +kernel
  have seed (w : Finset ℕ) (hw : w ∈ markedSeeds d e) :
      ¬w ∩ actualRows ⊆ edgeRows := by
    intro clean
    simp only [markedSeeds, Finset.mem_insert] at hw
    rcases hw with rfl | rfl | pure
    · exact dJunk fun r hr => clean (Finset.mem_inter.mpr ⟨Finset.mem_insert_of_mem hr, dRows hr⟩)
    · exact eJunk fun r hr => clean (Finset.mem_inter.mpr ⟨Finset.mem_insert_of_mem hr, eRows hr⟩)
    · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp pure
      exact roots u fun r hr => clean (Finset.mem_inter.mpr ⟨hr, rootRowsBound u hr⟩)
  intro w hw
  induction h : w.card using Nat.strong_induction_on generalizing w with
  | ind n earlier =>
    by_cases fromSeed : w ∈ markedSeeds d e
    · exact seed w fromSeed
    · obtain ⟨a, ha, _, _, smaller, _, _⟩ := build w hw fromSeed
      have before : a.card < n := h ▸ Finset.card_lt_card smaller
      intro clean
      exact earlier a.card before a ha rfl (fun r hr =>
        clean (Finset.mem_inter.mpr ⟨smaller.1 (Finset.mem_inter.mp hr).1, (Finset.mem_inter.mp hr).2⟩))

private theorem minimalCounterexampleDistinctOperands (d e : Finset ℕ)
    (witness : ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20) :
    ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧
      ∃ operand : {t // t ∈ B} × Bool → {w // w ∈ D},
        Function.Injective operand ∧
        ∀ t : {t // t ∈ B}, productTerm (operand (t, false)).val (operand (t, true)).val = t.val := by
  classical
  obtain ⟨D, B, scenario, limit, separate⟩ := minimalCounterexampleSeparate d e witness
  refine ⟨D, B, scenario, limit, ?_⟩
  obtain ⟨dFrom, eFrom, dJunk, eJunk, _, build, _, _, _, _, terms, _⟩ := scenario
  have dirty := everyOperandDirty d e D (plainIntersectionsBound D d dFrom)
    (plainIntersectionsBound D e eFrom) dJunk eJunk build
  have arguments (t : {t // t ∈ B}) : ∃ a : {w // w ∈ D}, ∃ b : {w // w ∈ D},
      productTerm a.val b.val = t.val ∧ a ≠ b := by
    obtain ⟨a, ha, b, hb, eq⟩ := Finset.mem_image₂.mp (terms t.val t.property).1
    refine ⟨⟨a, ha⟩, ⟨b, hb⟩, eq, ?_⟩
    intro same
    have words : a = b := congrArg Subtype.val same
    subst b
    have clean : productTerm a a ⊆ insert 40 edgeRows := eq.symm ▸ (terms t.val t.property).2.1
    apply dirty a ha
    intro r hr
    obtain ⟨inA, inRows⟩ := Finset.mem_inter.mp hr
    have inside : r ∈ productTerm a a := Finset.mem_union.mpr (Or.inl
      (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨inA, inA⟩, inRows⟩))
    rcases Finset.mem_insert.mp (clean inside) with mark | real
    · exact ((show 40 ∉ actualRows by decide) (mark ▸ inRows)).elim
    · exact real
  choose a b hm using arguments
  let operand (x : {t // t ∈ B} × Bool) := if x.2 then b x.1 else a x.1
  have value (t : {t // t ∈ B}) (i : Bool) :
      productTerm (operand (t, i)).val (operand (t, !i)).val = t.val := by
    cases i
    · simpa [operand] using (hm t).1
    · simpa [operand, productTermSymmetry (a t).val (b t).val] using (hm t).1
  refine ⟨operand, ?_, fun t => value t false⟩
  rintro ⟨t, i⟩ ⟨q, j⟩ same
  have atOnce : productTerm (operand (t, i)).val (operand (t, !i)).val ∈ B :=
    (value t i).symm ▸ t.property
  have onceMore : productTerm (operand (t, i)).val (operand (q, !j)).val ∈ B := by
    rw [same, value]
    exact q.property
  have sameTerm := separate _ (operand (t, i)).property _ (operand (t, !i)).property
    _ (operand (q, !j)).property atOnce onceMore
  rw [value, same, value] at sameTerm
  have termsEqual : t = q := Subtype.ext sameTerm
  subst q
  refine Prod.ext rfl ?_
  cases i <;> cases j
  · rfl
  · exact ((hm t).2 (by simpa only [operand, Bool.false_eq_true, if_false, if_true] using same)).elim
  · exact ((hm t).2 (by simpa only [operand, Bool.false_eq_true, if_false, if_true] using same.symm)).elim
  · rfl

private theorem minimalCounterexampleOperandCount (d e : Finset ℕ)
    (witness : ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20) :
    ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧
      2 * B.card ≤ D.card := by
  obtain ⟨D, B, scenario, limit, operand, injective, _⟩ :=
    minimalCounterexampleDistinctOperands d e witness
  refine ⟨D, B, scenario, limit, ?_⟩
  have useCount := Fintype.card_le_of_injective operand injective
  simpa [Fintype.card_prod, Fintype.card_coe, Nat.mul_comm] using useCount

end PEqualNP.Outside.L_meta_9427
