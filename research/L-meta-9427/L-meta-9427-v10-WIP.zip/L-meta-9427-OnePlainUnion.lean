import Mathlib

namespace PEqualNP.Outside.L_meta_9427

set_option maxHeartbeats 4000000 in
private theorem distinctRootsAtMostOneRealRow :
    ∀ u v : Fin 11, u ≠ v → ((rootSet u ∩ rootSet v) ∩ edgeRows).card ≤ 1 := by
  decide +kernel

private theorem tagFromOneComposite (z w : Finset ℕ) (D : Finset (Finset ℕ))
    (onlyOne : ∀ x ∈ D, x ⊆ actualRows → x ∈ baseSets ∨ x = z)
    (producers : w ∈ plainIntersections D) (dirty : ¬w ⊆ edgeRows)
    (u v : Fin 11) (composite : z = rootSet u ∪ rootSet v) :
    w ∈ D ∨ (w ∩ edgeRows).card ≤ 1 := by
  obtain ⟨a, aPlain, b, bPlain, rfl⟩ := Finset.mem_image₂.mp producers
  obtain ⟨aD, aRows⟩ := Finset.mem_filter.mp aPlain
  obtain ⟨bD, bRows⟩ := Finset.mem_filter.mp bPlain
  have crossing (s : Fin 11) (rD : rootSet s ∈ D)
      (bad : ¬rootSet s ∩ z ⊆ edgeRows) :
      rootSet s ∩ z ∈ D ∨ ((rootSet s ∩ z) ∩ edgeRows).card ≤ 1 := by
    by_cases first : s = u
    · exact Or.inl (by simpa [composite, first] using rD)
    by_cases second : s = v
    · exact Or.inl (by simpa [composite, second, Finset.union_comm] using rD)
    have parts : rootSet s ∩ z = (rootSet s ∩ rootSet u) ∪ (rootSet s ∩ rootSet v) := by
      rw [composite, Finset.inter_union_distrib_left]
    have faces : (rootSet s ∩ z) ∩ edgeRows =
        ((rootSet s ∩ rootSet u) ∩ edgeRows) ∪ ((rootSet s ∩ rootSet v) ∩ edgeRows) := by
      rw [parts, Finset.union_inter_distrib_right]
    right
    rw [faces]
    by_cases good : rootSet s ∩ rootSet u ⊆ edgeRows
    · have badRight : ¬rootSet s ∩ rootSet v ⊆ edgeRows :=
        fun h => bad (parts.symm ▸ Finset.union_subset good h)
      have empty := (rootJunkPair s v badRight).resolve_left second
      simpa only [empty, Finset.union_empty] using distinctRootsAtMostOneRealRow s u first
    · have empty := (rootJunkPair s u good).resolve_left first
      simpa only [empty, Finset.empty_union] using distinctRootsAtMostOneRealRow s v second
  rcases onlyOne a aD aRows with aRoot | rfl <;> rcases onlyOne b bD bRows with bRoot | rfl
  · obtain ⟨p, _, rfl⟩ := Finset.mem_image.mp aRoot
    obtain ⟨q, _, rfl⟩ := Finset.mem_image.mp bRoot
    by_cases same : p = q
    · exact Or.inl (by simpa [same] using aD)
    · exact Or.inr (distinctRootsAtMostOneRealRow p q same)
  · obtain ⟨x, _, rfl⟩ := Finset.mem_image.mp aRoot
    exact crossing x aD dirty
  · obtain ⟨x, _, rfl⟩ := Finset.mem_image.mp bRoot
    rw [Finset.inter_comm]
    exact crossing x bD (by simpa only [Finset.inter_comm] using dirty)
  · exact Or.inl (by simpa using aD)

private theorem smallTagsHaveAtMostTwoOmissions (d e : Finset ℕ)
    (smallD : (d ∩ edgeRows).card ≤ 1) (smallE : (e ∩ edgeRows).card ≤ 1) :
    (potentialOmissions d e).card ≤ 2 := by
  classical
  let R := (Finset.univ : Finset (Fin 16)).filter fun r => possibleOmission d e r.val
  have includes : R.image Fin.val ⊆ (d ∩ edgeRows) ∪ (e ∩ edgeRows) := by
    intro n hn
    obtain ⟨r, hr, rfl⟩ := Finset.mem_image.mp hn
    have pos : r.val ∈ edgeRows := Finset.mem_range.mpr r.isLt
    exact (possibleOmissionMem (Finset.mem_filter.mp hr).2).elim
      (fun h => Finset.mem_union_left _ (Finset.mem_inter.mpr ⟨h,pos⟩))
      (fun h => Finset.mem_union_right _ (Finset.mem_inter.mpr ⟨h,pos⟩))
  have noCollision : (R.image Fin.val).card = R.card :=
    Finset.card_image_of_injective _ (fun _ _ h => Fin.ext h)
  change (R.image edgeAt).card ≤ 2
  calc
    _ ≤ R.card := Finset.card_image_le
    _ = (R.image Fin.val).card := noCollision.symm
    _ ≤ ((d ∩ edgeRows) ∪ (e ∩ edgeRows)).card := Finset.card_le_card includes
    _ ≤ (d ∩ edgeRows).card + (e ∩ edgeRows).card := Finset.card_union_le _ _
    _ ≤ 2 := Nat.add_le_add smallD smallE

private theorem costFromSmallOrCopiedTags (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dMode : d ∈ D ∨ (d ∩ edgeRows).card ≤ 1)
    (eMode : e ∈ D ∨ (e ∩ edgeRows).card ≤ 1)
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  rcases dMode with dCopy | smallD <;> rcases eMode with eCopy | smallE
  · exact (show 21 ≤ 23 by decide).trans
      (costFromPresentTaggedMasks d e D B dCopy eCopy dRows eRows build pairs cover)
  · exact costWithOneCopiedTagAndAtMostOneOtherRow d e D B dCopy dRows eRows smallE build pairs cover
  · obtain ⟨sameCost, sameTerms, swappedBuild⟩ := swapTagFamily d e D dRows eRows build
    let R := D.image swapTagWord
    have copy : e ∈ R :=
      Finset.mem_image.mpr ⟨e, eCopy, swapTagWordReal e eRows⟩
    have swappedPairs (t : Finset ℕ) (ht : t ∈ B) :
        ∃ a ∈ R, ∃ b ∈ R, t = productTerm a b ∧ t ⊆ insert 40 edgeRows := by
      obtain ⟨a, ha, b, hb, fact, clean⟩ := pairs t ht
      refine ⟨swapTagWord a, Finset.mem_image_of_mem _ ha, swapTagWord b, Finset.mem_image_of_mem _ hb, ?_, clean⟩
      exact fact.trans (swapTagProduct a b).symm
    have lower := costWithOneCopiedTagAndAtMostOneOtherRow e d R B copy eRows dRows smallD
      swappedBuild swappedPairs cover
    rwa [sameCost] at lower
  · exact costWithSmallOmissionSet d e D B dRows eRows
      (smallTagsHaveAtMostTwoOmissions d e smallD smallE) build pairs cover

private theorem costWithAtMostOnePlainUnion (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dFrom : d ∈ plainIntersections D) (eFrom : e ∈ plainIntersections D)
    (dDirty : ¬d ⊆ edgeRows) (eDirty : ¬e ⊆ edgeRows)
    (few : (D.filter (· ⊆ actualRows) \ baseSets).card ≤ 1)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  let U := D.filter (· ⊆ actualRows) \ baseSets
  have dRows := plainIntersectionsBound D d dFrom
  have eRows := plainIntersectionsBound D e eFrom
  by_cases empty : U = ∅
  · have seed (w : Finset ℕ) (hw : w ∈ D.filter (· ⊆ actualRows)) : w ∈ baseSets := by
      by_contra no
      exact Finset.notMem_empty w (empty ▸ Finset.mem_sdiff.mpr ⟨hw,no⟩)
    have bare (w : Finset ℕ) (hw : w ∈ plainIntersections D) :
        ∃ a b : Fin 11, w = rootSet a ∩ rootSet b := by
      obtain ⟨x, hx, y, hy, rfl⟩ := Finset.mem_image₂.mp hw
      obtain ⟨p, _, rfl⟩ := Finset.mem_image.mp (seed x hx)
      obtain ⟨q, _, rfl⟩ := Finset.mem_image.mp (seed y hy)
      exact ⟨p, q, rfl⟩
    apply (show 21 ≤ 23 by decide).trans (costFromRootProducers d e D B (bare d dFrom)
      (bare e eFrom) dDirty eDirty _ cover _)
    · intro w hw
      exact build w (Finset.mem_sdiff.mp hw).1 (Finset.mem_sdiff.mp hw).2
    · intro t ht
      obtain ⟨a, ha, b, hb, eq, clean⟩ := pairs t ht
      exact ⟨Finset.mem_image₂.mpr ⟨a, ha, b, hb, eq.symm⟩, clean⟩
  obtain ⟨z, singleton⟩ := Finset.card_eq_one.mp (Nat.le_antisymm few
    (Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr empty)))
  have justOne (w : Finset ℕ) (hw : w ∈ D) (plain : w ⊆ actualRows) :
      w ∈ baseSets ∨ w = z := by
    by_cases prior : w ∈ baseSets
    · exact Or.inl prior
    refine Or.inr (Finset.mem_singleton.mp ?_)
    rw [← singleton]
    exact Finset.mem_sdiff.mpr ⟨Finset.mem_filter.mpr ⟨hw, plain⟩, prior⟩
  have zU : z ∈ U := by
    have isSingleton : U = {z} := singleton
    rw [isSingleton]
    exact Finset.mem_singleton_self _
  obtain ⟨fromD, new⟩ := Finset.mem_sdiff.mp zU
  obtain ⟨zD, zRows⟩ := Finset.mem_filter.mp fromD
  have paid : z ∉ markedSeeds d e := by
    intro h
    simp only [markedSeeds, Finset.mem_insert] at h
    rcases h with rfl | rfl | plain
    · exact (show 40 ∉ actualRows by decide) (zRows (Finset.mem_insert_self _ _))
    · exact (show 41 ∉ actualRows by decide) (zRows (Finset.mem_insert_self _ _))
    · exact new plain
  obtain ⟨a, aD, b, bD, la, lb, joined⟩ := build z zD paid
  have aRoot := (justOne a aD (la.1.trans zRows)).resolve_right (Finset.ssubset_iff_subset_ne.mp la).2
  have bRoot := (justOne b bD (lb.1.trans zRows)).resolve_right (Finset.ssubset_iff_subset_ne.mp lb).2
  obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp aRoot
  obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp bRoot
  exact costFromSmallOrCopiedTags d e D B (tagFromOneComposite z d D justOne dFrom dDirty u v joined)
    (tagFromOneComposite z e D justOne eFrom eDirty u v joined)
    dRows eRows build pairs cover

end PEqualNP.Outside.L_meta_9427

