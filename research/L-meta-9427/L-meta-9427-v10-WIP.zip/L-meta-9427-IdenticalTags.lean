import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem nonSingletonProducerSupport (a : Finset ℕ) (A : Finset (Fin 11))
    (ground : a = rowsOf A) (alive : a.Nonempty) (notSeed : a ∉ baseSets) :
    1 < A.card := by
  by_contra no
  have finite : A.card ≤ 1 := by omega
  have srcNonempty : A.Nonempty := by
    by_contra empty
    have nil := Finset.not_nonempty_iff_eq_empty.mp empty
    have noRows : a = ∅ := by simp [ground, nil, rowsOf]
    exact (Finset.not_nonempty_iff_eq_empty.mpr noRows) alive
  obtain ⟨u, eq⟩ := Finset.card_eq_one.mp (Nat.le_antisymm finite (Finset.card_pos.mpr srcNonempty))
  apply notSeed
  rw [ground, eq]
  simpa [rowsOf] using (show rootSet u ∈ baseSets from
    Finset.mem_image_of_mem rootSet (Finset.mem_univ u))

private theorem costFromIdenticalTagsWithoutRoot (d : Finset ℕ) (D B : Finset (Finset ℕ))
    (dFrom : d ∈ plainIntersections D) (dirty : ¬d ⊆ edgeRows)
    (noRoot : ∀ v : Fin 11, ¬rootSet v ⊆ d)
    (build : ∀ w ∈ D, w ∉ markedSeeds d d →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d d).card + 2 * B.card := by
  classical
  obtain ⟨a, aPlain, b, bPlain, eq⟩ := Finset.mem_image₂.mp dFrom
  obtain ⟨aD, aRows⟩ := Finset.mem_filter.mp aPlain
  obtain ⟨bD, bRows⟩ := Finset.mem_filter.mp bPlain
  have negRow : ∃ n ∈ d, n ∉ edgeRows := by
    by_contra none
    exact dirty (fun r hr => by by_contra no; exact none ⟨r,hr,no⟩)
  obtain ⟨n, inD, neg⟩ := negRow
  have both : n ∈ a ∩ b := eq.symm ▸ inD
  have contains (v : Fin 11) (q : Finset ℕ) (h : d = rootSet v ∩ q) : ¬rootSet v ⊆ q := by
    intro copy
    exact noRoot v (fun _ hx => h.symm ▸ Finset.mem_inter.mpr ⟨hx, copy hx⟩)
  by_cases ar : a ∈ baseSets
  · obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp ar
    have equal : d = rootSet v ∩ b := eq.symm
    exact (show 21 ≤ 22 by decide).trans (costFromSameVertexIntersections d d b b v D B
      equal equal bD bD bRows bRows (contains v b equal) (contains v b equal) build pairs cover)
  by_cases br : b ∈ baseSets
  · obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp br
    have equal : d = rootSet v ∩ a := eq.symm.trans (Finset.inter_comm a _)
    exact (show 21 ≤ 22 by decide).trans (costFromSameVertexIntersections d d a a v D B
      equal equal aD aD aRows aRows (contains v a equal) (contains v a equal) build pairs cover)
  apply costOverlapWithProducerHeadBound d d a b a b D B eq.symm eq.symm
    aD bD aD bD aRows bRows aRows bRows noRoot noRoot n inD inD neg _ build pairs cover
  intro label ah bh _ _
  rw [Finset.union_self]
  exact producerHeadCount (label a) (label b)
    (nonSingletonProducerSupport a _ ah ⟨n, (Finset.mem_inter.mp both).1⟩ ar)
    (nonSingletonProducerSupport b _ bh ⟨n, (Finset.mem_inter.mp both).2⟩ br)

end PEqualNP.Outside.L_meta_9427

