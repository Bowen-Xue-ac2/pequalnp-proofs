import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def rootRows : List ℕ :=
  [2147418115, 663661903884, 34144976944, 728266375360, 21653750532,
    103293914128, 26322415680, 344922804352, 414195942664, 581968119809,
    1065151898146]

def row (u : Fin 11) : ℕ :=
  rootRows[u.val]?.getD 0

def positive : ℕ := 65535

def negative : ℕ := 1099511562240

def edge (u v : Fin 11) : Prop :=
  u ≠ v ∧ (row u &&& row v &&& positive ≠ 0)

instance (u v : Fin 11) : Decidable (edge u v) := by
  unfold edge
  infer_instance

def neighbors (u : Fin 11) : Finset (Fin 11) :=
  Finset.univ.filter (edge u)

def orientedEdges : Finset (Fin 11 × Fin 11) :=
  Finset.univ.filter fun p => p.1 < p.2 ∧ edge p.1 p.2

def isCover (s : Finset (Fin 11)) : Prop :=
  ∀ e ∈ orientedEdges, e.1 ∈ s ∨ e.2 ∈ s

instance (s : Finset (Fin 11)) : Decidable (isCover s) := by
  unfold isCover
  infer_instance

set_option maxHeartbeats 1500000 in
private theorem rootPair :
    ∀ (u v : Fin 11), row u &&& row v &&& negative ≠ 0 →
      u = v ∨ row u &&& row v &&& positive = 0 := by
  decide +kernel

set_option maxHeartbeats 1500000 in
private theorem cleanPair :
    ∀ (u v : Fin 11), row u &&& row v &&& negative = 0 ↔ edge u v := by
  decide +kernel

set_option maxHeartbeats 1500000 in
private theorem commonNeighbors :
    ∀ (u v : Fin 11), u ≠ v → ((neighbors u) ∩ (neighbors v)).card ≤ 1 := by
  decide +kernel

set_option maxHeartbeats 1500000 in
private theorem edgeCount : orientedEdges.card = 16 := by
  decide +kernel

def triangleA : Finset (Fin 11) := {1, 4, 8}
def triangleB : Finset (Fin 11) := {3, 6, 7}
def fiveCycle : Finset (Fin 11) := {0, 9, 5, 2, 10}

def edgesA : Finset (Fin 11 × Fin 11) := {(1, 4), (1, 8), (4, 8)}
def edgesB : Finset (Fin 11 × Fin 11) := {(3, 6), (3, 7), (6, 7)}
def edgesCycle : Finset (Fin 11 × Fin 11) := {(0, 9), (5, 9), (2, 5), (2, 10), (0, 10)}

private theorem coverPart (s part : Finset (Fin 11)) (es : Finset (Fin 11 × Fin 11))
    (n : ℕ) (hs : isCover s)
    (he : es ⊆ orientedEdges)
    (inside : ∀ e ∈ es, e.1 ∈ part ∧ e.2 ∈ part)
    (lower : ∀ t ∈ part.powerset, (∀ e ∈ es, e.1 ∈ t ∨ e.2 ∈ t) → n ≤ t.card) :
    n ≤ (s ∩ part).card := by
  apply lower _ (Finset.mem_powerset.mpr Finset.inter_subset_right)
  intro e eh
  rcases hs e (he eh) with hu | hv
  · exact Or.inl (Finset.mem_inter.mpr ⟨hu, (inside e eh).1⟩)
  · exact Or.inr (Finset.mem_inter.mpr ⟨hv, (inside e eh).2⟩)

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
private theorem coverNumber (s : Finset (Fin 11)) (hs : isCover s) : 7 ≤ s.card := by
  have hA := coverPart s triangleA edgesA 2 hs (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  have hB := coverPart s triangleB edgesB 2 hs (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  have hC := coverPart s fiveCycle edgesCycle 3 hs (by decide +kernel)
    (by decide +kernel) (by decide +kernel)
  let a := s ∩ triangleA
  let b := s ∩ triangleB
  let c := s ∩ fiveCycle
  have ab : Disjoint a b :=
    (show Disjoint triangleA triangleB by decide +kernel).mono
      Finset.inter_subset_right Finset.inter_subset_right
  have uC : Disjoint (a ∪ b) c :=
    (show Disjoint (triangleA ∪ triangleB) fiveCycle by decide +kernel).mono
      (Finset.union_subset (Finset.inter_subset_right.trans Finset.subset_union_left)
        (Finset.inter_subset_right.trans Finset.subset_union_right))
      Finset.inter_subset_right
  have hu : (a ∪ b) ∪ c ⊆ s :=
    Finset.union_subset (Finset.union_subset Finset.inter_subset_left
      Finset.inter_subset_left) Finset.inter_subset_left
  have hc := Finset.card_le_card hu
  rw [Finset.card_union_of_disjoint uC, Finset.card_union_of_disjoint ab] at hc
  change 2 ≤ a.card at hA
  change 2 ≤ b.card at hB
  change 3 ≤ c.card at hC
  omega

end PEqualNP.Outside.L_meta_9427
