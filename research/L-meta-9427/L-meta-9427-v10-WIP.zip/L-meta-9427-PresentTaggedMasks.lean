import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem costFromPresentTaggedMasks (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dD : d ∈ D) (eD : e ∈ D) (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    23 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  let erase (w : Finset ℕ) := w ∩ actualRows
  let F := D.image erase
  have removeTag (r : Finset ℕ) (tag : ℕ) (valid : r ⊆ actualRows) (outside : tag ∉ actualRows) :
      erase (insert tag r) = r := by
    ext s
    constructor
    · intro hs
      obtain ⟨inside, actual⟩ := Finset.mem_inter.mp hs
      exact (Finset.mem_insert.mp inside).elim (fun eq => (outside (eq ▸ actual)).elim) id
    · intro hr
      exact Finset.mem_inter.mpr ⟨Finset.mem_insert_of_mem hr, valid hr⟩
  have best (s : Finset ℕ) (hs : s ∈ F) (nonBase : s ∉ baseSets) :
      ∃ x ∈ D, x ∉ markedSeeds d e ∧ erase x = s ∧
      ∀ y ∈ D, erase y = s → x.card ≤ y.card := by
    let candidates := D.filter fun w => erase w = s
    obtain ⟨w, hw, eq⟩ := Finset.mem_image.mp hs
    have alive : candidates.Nonempty := ⟨w, Finset.mem_filter.mpr ⟨hw, eq⟩⟩
    obtain ⟨x, hx, minimum⟩ := Finset.exists_min_image candidates Finset.card alive
    obtain ⟨xD, xEq⟩ := Finset.mem_filter.mp hx
    have minD (y : Finset ℕ) (yD : y ∈ D) (yEq : erase y = s) : x.card ≤ y.card :=
      minimum y (Finset.mem_filter.mpr ⟨yD, yEq⟩)
    have copy (r : Finset ℕ) (tag : ℕ) (rD : r ∈ D) (valid : r ⊆ actualRows)
        (outside : tag ∉ actualRows) (fromTag : x = insert tag r) : False := by
      have raw : r = s := (removeTag r tag valid outside).symm.trans (fromTag ▸ xEq)
      have erased : erase r = r := Finset.inter_eq_left.mpr valid
      have smaller : r ⊂ x := by
        rw [fromTag]
        exact Finset.ssubset_iff_subset_ne.mpr ⟨Finset.subset_insert _ _, fun eq =>
          outside (valid (eq.symm ▸ Finset.mem_insert_self _ _))⟩
      exact (Nat.not_lt_of_ge (minD r rD (erased.trans raw))) (Finset.card_lt_card smaller)
    refine ⟨x, xD, ?_, xEq, minD⟩
    intro seed
    simp only [markedSeeds, Finset.mem_insert] at seed
    rcases seed with hd | he | ordinary
    · exact copy d 40 dD dRows (by decide) hd
    · exact copy e 41 eD eRows (by decide) he
    · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp ordinary
      have erased : erase (rootSet u) = rootSet u := Finset.inter_eq_left.mpr (rootRowsBound u)
      exact nonBase (xEq ▸ erased.symm ▸ Finset.mem_image_of_mem rootSet (Finset.mem_univ u))
  have cost : (F \ baseSets).card ≤ (D \ markedSeeds d e).card := by
    have sub : F \ baseSets ⊆ (D \ markedSeeds d e).image erase := by
      intro s hs
      obtain ⟨sF, notBase⟩ := Finset.mem_sdiff.mp hs
      obtain ⟨w, wD, wPaid, eq, _⟩ := best s sF notBase
      exact Finset.mem_image.mpr ⟨w, Finset.mem_sdiff.mpr ⟨wD, wPaid⟩, eq⟩
    exact (Finset.card_le_card sub).trans Finset.card_image_le
  have join (s : Finset ℕ) (hs : s ∈ F) (nonBase : s ∉ baseSets) :
      ∃ a ∈ F, ∃ b ∈ F, a ⊂ s ∧ b ⊂ s ∧ s = a ∪ b := by
    obtain ⟨w, hw, paid, eq, least⟩ := best s hs nonBase
    obtain ⟨a, ha, b, hb, aa, bb, together⟩ := build w hw paid
    have shows (q : Finset ℕ) (hq : q ∈ D) (small : q ⊂ w) : erase q ⊂ s := by
      refine Finset.ssubset_iff_subset_ne.mpr ⟨?_, fun equal =>
        (Nat.not_lt_of_ge (least q hq equal)) (Finset.card_lt_card small)⟩
      rw [← eq]
      exact Finset.inter_subset_inter small.1 Finset.Subset.rfl
    refine ⟨erase a, Finset.mem_image_of_mem _ ha, erase b, Finset.mem_image_of_mem _ hb,
      shows a ha aa, shows b hb bb, ?_⟩
    calc
      s = erase w := eq.symm
      _ = erase (a ∪ b) := congrArg erase together
      _ = erase a ∪ erase b := Finset.union_inter_distrib_right _ _ _
  have seeds (w : Finset ℕ) (_ : w ∈ F) (hx : w ∈ baseSets) :
      ∃ s : Finset (Fin 11), s.card ≤ 1 ∧ rowsOf s ⊆ w ∧
        rowsOf s ∩ edgeRows = w ∩ edgeRows := by
    obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp hx
    exact ⟨{u}, by simp, by simp [rowsOf], by simp [rowsOf]⟩
  have projectedPairs (t : Finset ℕ) (ht : t ∈ B) :
      ∃ x ∈ F, ∃ y ∈ F, x ∩ y ∩ actualRows ⊆ edgeRows ∧
        t ∩ edgeRows = x ∩ y ∩ edgeRows := by
    obtain ⟨a, ha, b, hb, eq, inside⟩ := pairs t ht
    obtain ⟨clean, real, _⟩ := cleanProductFacts a b (eq ▸ inside)
    have positive : edgeRows ⊆ actualRows := by decide
    refine ⟨erase a, Finset.mem_image_of_mem _ ha, erase b, Finset.mem_image_of_mem _ hb, ?_, ?_⟩
    · intro r hr
      obtain ⟨pair, actual⟩ := Finset.mem_inter.mp hr
      obtain ⟨left, right⟩ := Finset.mem_inter.mp pair
      exact clean (Finset.mem_inter.mpr
        ⟨Finset.mem_inter.mpr ⟨(Finset.mem_inter.mp left).1, (Finset.mem_inter.mp right).1⟩, actual⟩)
    · rw [eq, real]
      ext r
      simp only [erase, Finset.mem_inter]
      exact ⟨fun h => ⟨⟨⟨h.1.1, positive h.2⟩, ⟨h.1.2, positive h.2⟩⟩, h.2⟩,
        fun h => ⟨⟨h.1.1.1, h.1.2.1⟩, h.2⟩⟩
  have coverage : edgeRows ⊆ B.biUnion id := by rw [cover]; exact Finset.subset_insert _ _
  have pure := projectedCost F baseSets B join seeds projectedPairs coverage
  omega

end PEqualNP.Outside.L_meta_9427
