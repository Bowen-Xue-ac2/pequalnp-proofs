import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def actualRows : Finset ℕ := Finset.range 40
def edgeRows : Finset ℕ := Finset.range 16

def rootSet (u : Fin 11) : Finset ℕ :=
  actualRows.filter fun i => (row u).testBit i = true

def rowsOf (s : Finset (Fin 11)) : Finset ℕ :=
  s.biUnion rootSet

def edgeAt (r : Fin 16) : Fin 11 × Fin 11 :=
  ([(0,9), (0,10), (1,4), (1,8), (2,5), (2,10), (3,6), (3,7),
    (4,8), (4,10), (5,8), (5,9), (6,7), (6,10), (7,9), (8,9)] :
      List (Fin 11 × Fin 11))[r.val]?.getD (0,0)

private theorem rootRowsBound (u : Fin 11) : rootSet u ⊆ actualRows :=
  Finset.filter_subset _ _

set_option maxHeartbeats 4000000 in
private theorem rootSetPair :
    ∀ (u v : Fin 11), (rootSet u ∩ rootSet v ⊆ edgeRows) ↔ edge u v := by
  decide +kernel

set_option maxHeartbeats 4000000 in
private theorem rootJunkPair :
    ∀ (u v : Fin 11), ¬rootSet u ∩ rootSet v ⊆ edgeRows →
      u = v ∨ (rootSet u ∩ rootSet v) ∩ edgeRows = ∅ := by
  decide +kernel

set_option maxHeartbeats 4000000 in
private theorem edgeAtMembership :
    ∀ (r : Fin 16) (u : Fin 11), r.val ∈ rootSet u ↔
      u = (edgeAt r).1 ∨ u = (edgeAt r).2 := by
  decide +kernel

private theorem edgeAtIndexed :
    ∀ (u v : Fin 11), u < v → edge u v → ∃ r : Fin 16, edgeAt r = (u, v) := by
  decide +kernel

private theorem replayProjection (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11))
    (root : ∀ w ∈ D, w ∈ X → rowsOf (label w) ⊆ w ∧
      rowsOf (label w) ∩ edgeRows = w ∩ edgeRows)
    (build : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b ∧
        label w = label a ∪ label b) :
    ∀ w ∈ D, rowsOf (label w) ⊆ w ∧ rowsOf (label w) ∩ edgeRows = w ∩ edgeRows := by
  intro w hw
  induction hn : w.card using Nat.strong_induction_on generalizing w with
  | ind n ih =>
    by_cases terminal : w ∈ X
    · exact root w hw terminal
    obtain ⟨a, ha, b, hb, haSub, hbSub, hwEq, labelEq⟩ := build w hw terminal
    have aSmaller : a.card < n := by
      rw [← hn]
      exact Finset.card_lt_card haSub
    have bSmaller : b.card < n := by
      rw [← hn]
      exact Finset.card_lt_card hbSub
    obtain ⟨aLe, aEdges⟩ := ih a.card aSmaller a ha rfl
    obtain ⟨bLe, bEdges⟩ := ih b.card bSmaller b hb rfl
    have rowEq : rowsOf (label w) = rowsOf (label a) ∪ rowsOf (label b) := by
      simp only [labelEq, rowsOf, Finset.union_biUnion]
    constructor
    · rw [rowEq, hwEq]
      exact Finset.union_subset_union aLe bLe
    · rw [rowEq, hwEq, Finset.union_inter_distrib_right,
        Finset.union_inter_distrib_right, aEdges, bEdges]

end PEqualNP.Outside.L_meta_9427
