"""Encode the row-cover search in DIMACS and independently replay a SAT witness."""

import argparse
from bisect import bisect_left
from itertools import combinations
import json
from pathlib import Path
import runpy
import subprocess
import tempfile


base = runpy.run_path(str(Path(__file__).with_name("L-meta-9427-model.py")))
vertices = base["VERTEX_ROWS"]
width = base["WIDTH"]
fold = base["union"]


class Formula:
    def __init__(self):
        self.variables = 0
        self.clauses = []
        self.true = self.var()
        self.add(self.true)

    def var(self):
        self.variables += 1
        return self.variables

    def add(self, *literals):
        self.clauses.append(literals)

    def either(self, *literals):
        if not literals:
            return -self.true
        if len(literals) == 1:
            return literals[0]
        result = self.var()
        self.add(-result, *literals)
        for value in literals:
            self.add(result, -value)
        return result

    def both(self, *literals):
        return -self.either(*(-value for value in literals))

    def equal(self, a, b):
        self.add(-a, b)
        self.add(a, -b)

    def choose(self, condition, no, yes):
        if no == yes:
            return no
        result = self.var()
        self.add(condition, -no, result)
        self.add(condition, no, -result)
        self.add(-condition, -yes, result)
        self.add(-condition, yes, -result)
        return result

    def at_least(self, count, bits):
        if count <= 0:
            return self.true
        prefix = [self.true] + [-self.true] * count
        for bit in bits:
            prefix = [self.true] + [
                self.either(prefix[i], self.both(bit, prefix[i - 1]))
                for i in range(1, count + 1)
            ]
        return prefix[count]

    def less(self, left, right):
        result = -self.true
        for a, b in zip(left, right):
            result = self.either(self.both(-a, b),
                                 self.both(self.either(-a, b), self.either(a, -b), result))
        return result

    def constant(self, value, bits=width):
        return [self.true if value >> r & 1 else -self.true for r in range(bits)]

    def word(self):
        return [self.var() for _ in range(width)]

    def select(self, options):
        index = [self.var() for _ in options]
        self.add(*index)
        for a, b in combinations(index, 2):
            self.add(-a, -b)
        value = [self.var() for _ in options[0]]
        for use, word in zip(index, options):
            for bit, source in zip(value, word):
                self.add(-use, -bit, source)
                self.add(-use, bit, -source)
        return index, value

    def pair(self, options, strict=False):
        left_index, left = self.select(options)
        right_index, right = self.select(options)
        for j, use_left in enumerate(left_index):
            for use_right in right_index[:j + strict]:
                self.add(-use_left, -use_right)
        return left_index, right_index, left, right

    def write(self, path):
        with path.open("w") as stream:
            print("p", "cnf", self.variables, len(self.clauses), file=stream)
            for literals in self.clauses:
                print(*literals, 0, file=stream)


def tag_pair(formula, d, e, case):
    formula.add(*d[16:40])
    formula.add(*e[16:40])
    formula.add(-formula.less(e[:40], d[:40]))
    overlap = [formula.both(x, y) for x, y in zip(d[16:40], e[16:40])]
    if case == "safe":
        for shared in overlap:
            formula.add(-shared)
    if case == "overlap":
        formula.add(*overlap)
    return overlap


def output(formula, a, b):
    for r in range(16, 40):
        formula.add(-a[r], -b[r])
    tag = formula.both(formula.either(a[40], b[40]),
                       formula.either(a[41], b[41]))
    return [formula.both(a[r], b[r]) for r in range(16)] + [tag]


def cover_constraints(formula, terms, private):
    private_rows = []
    for bits in zip(*terms):
        formula.add(*bits)
    for index, term in enumerate(terms):
        if index:
            formula.add(formula.less(terms[index - 1], term))
        if private:
            choices = [formula.both(value, *(-other[r] for j, other in enumerate(terms) if j != index))
                       for r, value in enumerate(term)]
            private_rows.append(choices)
            formula.add(*choices)
    return private_rows


def bounded_family(count, unions, case, private, plain_unions=None):
    formula = Formula()
    d, e = formula.word(), formula.word()
    formula.equal(d[40], formula.true)
    formula.equal(d[41], -formula.true)
    formula.equal(e[40], -formula.true)
    formula.equal(e[41], formula.true)
    tag_pair(formula, d, e, case)
    root_words = [formula.constant(v) for v in vertices]

    def gates(wires, length, tagged_only=False):
        live = []
        for _ in range(length):
            active = formula.var()
            al, bl, a, b = formula.pair(wires)
            formula.add(active, al[0])
            formula.add(active, bl[0])
            child = [formula.either(x, y) for x, y in zip(a, b)]
            formula.add(-active, *(formula.both(-x, y) for x, y in zip(a, b)))
            formula.add(-active, *(formula.both(x, -y) for x, y in zip(a, b)))
            if tagged_only:
                formula.add(-active, child[40], child[41])
            if live:
                formula.add(-live[-1], active)
                formula.add(-live[-1], formula.less(wires[-1], child))
            live.append(active)
            wires.append(child)
        return live

    if plain_unions is None:
        wires = [*root_words, d, e]
        live = gates(wires, unions)
        allowed = root_words + wires[len(vertices) + 2:]
    else:
        allowed = list(root_words)
        live = gates(allowed, plain_unions)
        wires = [*allowed, d, e]
        live += gates(wires, unions - plain_unions, tagged_only=True)
    formula.add(*live)
    for tag in (d, e):
        _, _, a, b = formula.pair(allowed)
        for operand in (a, b):
            formula.add(-operand[40])
            formula.add(-operand[41])
        for r in range(40):
            formula.equal(tag[r], formula.both(a[r], b[r]))
    terms = []
    for _ in range(count):
        _, _, a, b = formula.pair(wires, strict=True)
        terms.append(output(formula, a, b))
    cover_constraints(formula, terms, private)
    return formula, d, e, wires, terms


def bounded_supports(count, unions, case, private, plain_unions=None, force_merge=False,
                     distinct_operands=False, direct_compatibility=False, rectangle_free=False,
                     minimum_paid_tags=0, maximum_paid_tags=None, maximal_terms=False,
                     graph_charges=False, live_unions=False, terminal_gate=False, two_overlap_mode=None):
    formula = Formula()
    basis_size = len(vertices) + 2
    atoms = [formula.constant(1 << i, basis_size) for i in range(basis_size)]
    d, e = formula.word(), formula.word()
    formula.equal(d[40], formula.true)
    formula.equal(d[41], -formula.true)
    formula.equal(e[40], -formula.true)
    formula.equal(e[41], formula.true)
    overlap = tag_pair(formula, d, e, case)
    paid_tags = []
    paid_plain = []
    paid_slots = []
    gate_inputs = {}
    restrict_mark_count = bool(minimum_paid_tags or maximum_paid_tags is not None)

    def actual_rows(s, end=40):
        return [formula.either(*(l for l, v in zip(s, vertices) if v >> r & 1),
                               formula.both(s[-2], d[r]), formula.both(s[-1], e[r]))
                for r in range(end)] + s[-2:]

    def gates(pool, length, tagged_only=False):
        live = []
        for _ in range(length):
            active = formula.var()
            al, bl, a, b = formula.pair(pool)
            for choices in (al, bl):
                for j, (lit, available) in enumerate(zip(choices, enabled)):
                    formula.add(-lit, available)
                    if live_unions:
                        consumers[j].append(formula.both(active, lit))
            formula.add(active, al[0])
            formula.add(active, bl[0])
            child = [formula.either(x, y) for x, y in zip(a, b)]
            formula.add(-active, *(formula.both(-x, y) for x, y in zip(a, b)))
            formula.add(-active, *(formula.both(x, -y) for x, y in zip(a, b)))
            if tagged_only:
                formula.add(-active, child[-2], child[-1])
            if live:
                formula.add(-live[-1], active)
                formula.add(-live[-1], formula.less(pool[-1], child))
            live.append(active)
            paid_slots.append(len(pool))
            if terminal_gate:
                gate_inputs[len(pool)] = (a, b)
            pool.append(child)
            enabled.append(active)
            consumers.append([])
            if restrict_mark_count:
                paid_tags.append(formula.both(active, formula.either(*child[-2:])))
            if graph_charges:
                paid_plain.append(formula.both(active, -formula.either(*child[-2:])))
        return live

    def register_marked_union(left, right):
        position = len(supports)
        joined = [formula.either(x, y) for x, y in zip(left, right)]
        supports.append(joined)
        enabled.append(formula.true)
        consumers.append([])
        paid_slots.append(position)
        paid_tags.append(formula.true)
        if terminal_gate:
            gate_inputs[position] = (left, right)
        return position, joined

    if plain_unions is None:
        supports = list(atoms)
        enabled = [formula.true] * len(supports)
        consumers = [[] for _ in supports]
        live = gates(supports, unions)
        allowed = atoms[:-2] + supports[basis_size:]
        producer_enabled = enabled[:basis_size - 2] + enabled[basis_size:]
        producer_slots = [*range(basis_size - 2), *range(basis_size, len(supports))]
    else:
        allowed = atoms[:-2]
        enabled = [formula.true] * len(allowed)
        consumers = [[] for _ in allowed]
        live = gates(allowed, plain_unions)
        producer_enabled = enabled.copy()
        producer_slots = list(range(len(allowed)))
        supports = [*allowed, *atoms[-2:]]
        enabled += [formula.true, formula.true]
        consumers.extend(([], []))
        if force_merge:
            merge = formula.constant((1 << (basis_size - 2)) | (1 << (basis_size - 1)),
                                     basis_size)
            paid_slots.append(len(supports))
            supports.append(merge)
            enabled.append(formula.true)
            consumers.append([])
            paid_tags.append(formula.true)
        elif two_overlap_mode:
            plain_choice, plain_word = formula.select(allowed)
            for j, (lit, available) in enumerate(zip(plain_choice, producer_enabled)):
                formula.add(-lit, available)
                if live_unions:
                    consumers[j].append(lit)
            if two_overlap_mode == "double-chain":
                prior, merge = register_marked_union(*atoms[-2:])
                register_marked_union(merge, plain_word)
                consumers[prior].append(formula.true)
            else:
                _, one_mark = formula.select(atoms[-2:])
                prior, single = register_marked_union(one_mark, plain_word)
                if two_overlap_mode == "single-chain":
                    other_mark = [*one_mark[:-2], one_mark[-1], one_mark[-2]]
                    register_marked_union(single, other_mark)
                    consumers[prior].append(formula.true)
                else:
                    register_marked_union(*atoms[-2:])
        else:
            live += gates(supports, unions - plain_unions, tagged_only=True)
    if not force_merge and not two_overlap_mode:
        formula.add(*live)
    if minimum_paid_tags:
        formula.add(formula.at_least(minimum_paid_tags, paid_tags))
    if maximum_paid_tags is not None:
        formula.add(-formula.at_least(maximum_paid_tags + 1, paid_tags))

    paid_producer_uses = []
    proper_intersections = []
    producer_roots = []
    repair_heads = []

    def compatible_with_root(word, root):
        return formula.both(*(-word[r] for r in range(16, 40) if root >> r & 1))

    def contains_root(word, root):
        return formula.both(*(word[r] for r in range(40) if root >> r & 1))

    for tag in (d, e):
        al, bl, a, b = formula.pair(allowed)
        for choices in (al, bl):
            for lit, available, j in zip(choices, producer_enabled, producer_slots):
                formula.add(-lit, available)
                if live_unions:
                    consumers[j].append(lit)
        formula.add(-a[-2])
        formula.add(-a[-1])
        formula.add(-b[-2])
        formula.add(-b[-1])
        value_a, value_b = actual_rows(a), actual_rows(b)
        for bit, a_bit, b_bit in zip(tag[:40], value_a, value_b):
            formula.equal(bit, formula.both(a_bit, b_bit))
        if graph_charges:
            paid_producer_uses.extend(al[len(vertices):] + bl[len(vertices):])
            proper_intersections.append(formula.both(
                formula.either(*(formula.both(x, -y) for x, y in zip(value_a[:40], value_b[:40]))),
                formula.either(*(formula.both(y, -x) for x, y in zip(value_a[:40], value_b[:40])))))
            producer_roots.append([formula.either(x, y) for x, y in zip(al[:len(vertices)], bl[:len(vertices)])])
            if case != "safe":
                for w, opposite in ((value_a, value_b), (value_b, value_a)):
                    repair_heads.extend(formula.both(contains_root(w, root),
                        compatible_with_root(opposite, root)) for root in vertices)
    terms = []
    selections = []
    negative_pairs = []
    terminal_uses = []
    bare_tag_cut = case == "safe" and plain_unions == unions
    if direct_compatibility or graph_charges:
        tag_ok = [[compatible_with_root(tag, v) for v in vertices] for tag in (d, e)]
        cross_ok = -formula.either(*overlap)
    if direct_compatibility:
        root_ok = [[not (a & b & ((1 << 40) - (1 << 16))) for b in vertices] for a in vertices]
    if graph_charges:
        formula.add(formula.at_least(2, paid_plain))
        formula.add(*paid_producer_uses)
        formula.add(*proper_intersections)
        possible_omissions = []
        for r in range(16):
            explain = [
                formula.both(tag[r], formula.either(*(good for v, good in zip(vertices, compat)
                    if v >> r & 1))) for tag, compat in zip((d, e), tag_ok)
            ]
            possible_omissions.append(formula.either(
                *explain, formula.both(d[r], e[r], cross_ok)))
        formula.add(formula.at_least(3, possible_omissions))
        exact_root = [formula.either(*(formula.both(*(
            tag[r] if v >> r & 1 else -tag[r] for r in range(40))) for v in vertices))
            for tag in (d, e)]
        for i in range(2):
            j = 1 - i
            formula.add(-exact_root[i], -proper_intersections[j], -formula.either(*producer_roots[j]))
            formula.add(proper_intersections[i], formula.at_least(2, (d, e)[j][:16]))
        for v, w in zip(*producer_roots):
            formula.add(-v, -w, *(-proper for proper in proper_intersections))
        whole_roots = [[contains_root(tag, root) for root in vertices] for tag in (d, e)]
        support_priority = sorted(range(len(vertices)),
                                  key=lambda i: (-(vertices[i] & ((1 << 16) - 1)).bit_count(), i))
        projected = []
        for options in whole_roots:
            chosen = []
            excluded = []
            for i in support_priority:
                chosen.append((vertices[i], formula.both(options[i], *excluded)))
                excluded.append(-options[i])
            projected.append([formula.either(*(pick for v, pick in chosen if v >> r & 1))
                              for r in range(16)])
        omissions_after_projection = [
            formula.either(formula.both(d[r], -projected[0][r]),
                           formula.both(e[r], -projected[1][r])) for r in range(16)]
        formula.add(formula.at_least(2, omissions_after_projection))
        if case != "safe":
            root_contained = [*whole_roots[0], *whole_roots[1]]
            formula.add(cross_ok, *root_contained, formula.at_least(3, repair_heads))
            difference = [bit for x, y in zip(d[:40], e[:40])
                          for bit in (formula.both(x, -y), formula.both(-x, y))]
            formula.add(*root_contained, *difference)
            formula.add(*difference, -formula.at_least(2, whole_roots[0]))
            compatible_centers = [formula.either(x, y) for x, y in zip(*tag_ok)]
            formula.add(cross_ok, formula.at_least(2, compatible_centers))

    def positive_term_bits(a, b):
        real_a, real_b = actual_rows(a, 16)[:-2], actual_rows(b, 16)[:-2]
        return [formula.both(x, y) for x, y in zip(real_a, real_b)] + [
            formula.both(formula.either(a[-2], b[-2]), formula.either(a[-1], b[-1]))]

    def make_term(a, b):
        if not direct_compatibility:
            return output(formula, actual_rows(a), actual_rows(b))
        for i, allowed_roots in enumerate(root_ok):
            for j, ok in enumerate(allowed_roots):
                if not ok:
                    formula.add(-a[i], -b[j])
            for marker, compatible in zip((-2, -1), tag_ok):
                formula.add(-a[i], -b[marker], compatible[i])
                formula.add(-b[i], -a[marker], compatible[i])
        for marker in (-2, -1):
            formula.add(-a[marker], -b[marker])
        formula.add(-a[-2], -b[-1], cross_ok)
        formula.add(-a[-1], -b[-2], cross_ok)
        return positive_term_bits(a, b)

    for index in range(count):
        if index == count - 1 and force_merge:
            plain_choice, plain = formula.select(allowed)
            for lit, available, j in zip(plain_choice, producer_enabled, producer_slots):
                formula.add(-lit, available)
                if live_unions:
                    consumers[j].append(lit)
            if live_unions:
                consumers[-1].append(formula.true)
            if distinct_operands:
                selections.append([*plain_choice, *([-formula.true] * 3)])
                selections.append([*([-formula.true] * (len(supports) - 1)), formula.true])
            a, b = plain, merge
        elif index == count - 1 and bare_tag_cut:
            a, b = atoms[-2:]
            if distinct_operands:
                selections.append([*([-formula.true] * len(allowed)), formula.true, -formula.true])
                selections.append([*([-formula.true] * len(allowed)), -formula.true, formula.true])
        else:
            left_index, right_index, a, b = formula.pair(supports, strict=True)
            for choices in (left_index, right_index):
                for j, (lit, available) in enumerate(zip(choices, enabled)):
                    formula.add(-lit, available)
                    if live_unions:
                        consumers[j].append(lit)
            selections.extend((left_index, right_index))
            if terminal_gate:
                terminal_uses.append((right_index, a))
        if case == "overlap":
            for p in a[-2:]:
                for q in b[-2:]:
                    formula.add(-p, -q)
        terms.append(make_term(a, b))
        if rectangle_free:
            negative_pairs.append((actual_rows(a)[16:40], actual_rows(b)[16:40]))
    formula.add(terms[-1][-1])
    if live_unions:
        for j in paid_slots:
            formula.add(-enabled[j], *consumers[j])
    if distinct_operands:
        for uses in zip(*selections):
            for a, b in combinations(uses, 2):
                formula.add(-a, -b)
    if rectangle_free:
        def dirty(a, b):
            return formula.either(*(formula.both(x, y) for x, y in zip(a, b)))

        for (a, b), (c, f) in combinations(negative_pairs, 2):
            formula.add(dirty(a, f), dirty(c, b))
            formula.add(dirty(a, c), dirty(f, b))
    private_rows = cover_constraints(formula, terms, private)
    if terminal_gate:
        terminal_slots = paid_slots[-2:] if two_overlap_mode == "independent" else paid_slots[-1:]
        for slot in terminal_slots:
            for (right_index, left), exclusive in zip(terminal_uses, private_rows):
                for child in gate_inputs[slot]:
                    replacement = positive_term_bits(left, child)
                    formula.add(-right_index[slot], *(formula.both(only, -new)
                        for only, new in zip(exclusive, replacement)))
    raw_words = [actual_rows(s) for s in supports]
    if maximal_terms:
        for (a, enabled_a), (b, enabled_b) in combinations(zip(raw_words, enabled), 2):
            clean = formula.both(enabled_a, enabled_b, *(
                -formula.both(a[r], b[r]) for r in range(16, 40)))
            candidate = [formula.both(a[r], b[r]) for r in range(16)] + [
                formula.both(formula.either(a[40], b[40]), formula.either(a[41], b[41]))]
            for chosen in terms:
                loses_row = formula.either(*(formula.both(x, -y) for x, y in zip(chosen, candidate)))
                for x, y in zip(chosen, candidate):
                    formula.add(-clean, loses_row, x, -y)
    return formula, d, e, raw_words, terms


def any_supports(count, case, producer_width=None):
    formula = Formula()

    def pure_word(limit=None):
        support = [formula.var() for _ in vertices]
        if limit is not None:
            for chosen in combinations(support, limit + 1):
                formula.add(*(-x for x in chosen))
        word = [formula.either(*(x for v, x in zip(vertices, support) if v >> r & 1))
                for r in range(40)]
        return word, support

    producers = [pure_word(producer_width) for _ in range(4)]
    d = [formula.both(x, y) for x, y in zip(producers[0][0], producers[1][0])]
    e = [formula.both(x, y) for x, y in zip(producers[2][0], producers[3][0])]
    tag_pair(formula, d, e, case)

    def operand():
        marks = [formula.var(), formula.var()]
        word, support = pure_word()
        return [formula.either(plain, formula.both(marks[0], pd), formula.both(marks[1], pe))
                for plain, pd, pe in zip(word, d, e)] + marks, support + marks

    operands = []
    terms = []
    for _ in range(count):
        a, b = operand(), operand()
        operands.append((a, b))
        terms.append(output(formula, a[0], b[0]))
    cover_constraints(formula, terms, False)
    return formula, d, e, (), terms, producers, operands


def cut_profiles(formula, d, e, files, shape_case):
    values = set()
    for file in files:
        with file.open() as stream:
            for line in stream:
                items = line.split()
                if len(items) == 3 and items[0] == "profile" and not shape_case:
                    a, b = sorted(int(word) for word in items[1:])
                    values.add(a | (b << 40))
                elif len(items) == 5 and items[0] == "shape" and shape_case:
                    ac, ar, bc, br = map(int, items[1:])
                    a, b = ac | (ar << 11), bc | (br << 11)
                    values.update((a | (b << 27), b | (a << 27)))
    allowed = sorted(values)
    if shape_case:
        def shape_bits(word):
            compatible = [formula.both(*(-word[r] for r in range(16, 40) if root >> r & 1))
                          for root in vertices]
            if shape_case == "overlap":
                rows = [formula.both(word[r], formula.either(*(
                    use for root, use in zip(vertices, compatible) if root >> r & 1)))
                        for r in range(16)]
            else:
                rows = [formula.var() for _ in range(16)]
                for original, enlarged in zip(word[:16], rows):
                    formula.add(-original, enlarged)
            return compatible + rows

        bits = shape_bits(d) + shape_bits(e)
    else:
        bits = [*d[:40], *e[:40]]
    known = {}

    def node(start, end, bit):
        if start == end:
            return -formula.true
        if bit < 0:
            return formula.true
        middle = bisect_left(allowed, (allowed[start] >> (bit + 1) << (bit + 1)) | (1 << bit), start, end)
        key = (bit, node(start, middle, bit - 1), node(middle, end, bit - 1))
        if key not in known:
            known[key] = formula.choose(bits[bit], key[1], key[2])
        return known[key]

    formula.add(node(0, len(allowed), len(bits) - 1))
    return len(allowed)


def run(args):
    if args.unbounded:
        formula, d, e, family, terms, producers, operands = any_supports(
            args.count, args.case, args.producer_width)
    else:
        unions = args.budget - 2 * args.count
        if not 1 <= unions <= 18:
            raise ValueError("The gate budget must leave between one and eighteen unions.")
        if args.plain_unions is not None and not 0 <= args.plain_unions <= unions:
            raise ValueError("The untagged union allocation exceeds the gate budget.")
        if args.force_merge and (not args.support_family or args.case != "overlap"
                                 or args.plain_unions != unions - 1):
            raise ValueError("The forced merge requires one tagged slot in the overlap support search.")
        if (args.distinct_operands or args.direct_compatibility or args.rectangle_free or args.maximal_terms
            or args.graph_charges or args.live_unions or args.terminal_gate or args.two_overlap_mode
            or args.minimum_paid_tags or args.maximum_paid_tags is not None) and not args.support_family:
            raise ValueError("Operand reductions and mark counts require the support search.")
        if not 0 <= args.minimum_paid_tags <= unions:
            raise ValueError("The minimum marked-union count exceeds the union budget.")
        if args.maximum_paid_tags is not None and not args.minimum_paid_tags <= args.maximum_paid_tags <= unions:
            raise ValueError("The maximum marked-union count is outside the permitted range.")
        if args.terminal_gate and (args.plain_unions is None or args.plain_unions >= unions
                                   or args.force_merge or not args.private or not args.distinct_operands):
            raise ValueError("The terminal gate check needs tagged slots and distinct operands with private rows.")
        if args.two_overlap_mode and (args.case != "overlap" or args.plain_unions != unions - 2 or args.force_merge):
            raise ValueError("The specialized overlap family uses two paid marked unions.")
        if args.support_family:
            formula, d, e, family, terms = bounded_supports(
                args.count, unions, args.case, args.private, args.plain_unions, args.force_merge,
                args.distinct_operands, args.direct_compatibility, args.rectangle_free,
                args.minimum_paid_tags, args.maximum_paid_tags, args.maximal_terms, args.graph_charges,
                args.live_unions, args.terminal_gate, args.two_overlap_mode)
        else:
            formula, d, e, family, terms = bounded_family(
                args.count, unions, args.case, args.private, args.plain_unions)

    if args.compatible_vertex is not None:
        vertex = vertices[args.compatible_vertex]
        for r in range(16, 40):
            if vertex >> r & 1:
                formula.add(-d[r])
                formula.add(-e[r])
    if args.shared_negative is not None:
        formula.add(d[args.shared_negative])
        formula.add(e[args.shared_negative])
    retained_profiles = cut_profiles(formula, d, e, args.profiles, args.profile_shapes) if args.profiles else None

    with tempfile.TemporaryDirectory(prefix="pnp-cover-") as directory:
        cnf = Path(directory) / "cover.cnf"
        formula.write(cnf)
        command = [args.cadical, "-q", f"--seed={args.seed}", "-t", str(args.seconds), str(cnf)]
        if args.proof:
            command[1:1] = ["--lrat", "--no-binary"]
            command.append(str(args.proof))
        done = subprocess.run(command, capture_output=True, text=True, check=False)
    data = {"count": args.count, "case": args.case, "variables": formula.variables,
            "clauses": len(formula.clauses), "exit": done.returncode, "unbounded": args.unbounded}
    if args.plain_unions is not None:
        data["plain_unions"] = args.plain_unions
    if args.support_family:
        data["support_family"] = True
    if args.force_merge:
        data["force_merge"] = True
    if args.distinct_operands:
        data["distinct_operands"] = True
    if args.direct_compatibility:
        data["direct_compatibility"] = True
    if args.rectangle_free:
        data["rectangle_free"] = True
    if args.maximal_terms:
        data["maximal_terms"] = True
    if args.graph_charges:
        data["graph_charges"] = True
    if args.live_unions:
        data["live_unions"] = True
    if args.terminal_gate:
        data["terminal_gate"] = True
    if args.two_overlap_mode:
        data["two_overlap_mode"] = args.two_overlap_mode
    if args.minimum_paid_tags:
        data["minimum_paid_tags"] = args.minimum_paid_tags
    if args.maximum_paid_tags is not None:
        data["maximum_paid_tags"] = args.maximum_paid_tags
    if retained_profiles is not None:
        data["retained_profiles"] = retained_profiles
        if args.profile_shapes:
            data["profile_shapes"] = args.profile_shapes
    if args.compatible_vertex is not None:
        data["compatible_vertex"] = args.compatible_vertex
    if args.shared_negative is not None:
        data["shared_negative"] = args.shared_negative
    if done.returncode == 10:
        values = {int(x) for line in done.stdout.splitlines() if line.startswith("v ")
                  for x in line[2:].split()}
        if not values:
            raise RuntimeError("CaDiCaL returned SAT without an assignment.")

        def value(bits):
            return sum(1 << r for r, literal in enumerate(bits) if literal in values)

        edge_cover = {value(t[:16]) | ((t[16] in values) << 40) for t in terms}
        d_raw, e_raw = value(d[:40]), value(e[:40])
        data["assignment"] = {"d": d_raw, "e": e_raw, "cover": sorted(edge_cover)}
        if args.unbounded:
            data["assignment"]["producers"] = [value(s) for _, s in producers]
            data["assignment"]["operands"] = [(value(a[1]), value(b[1])) for a, b in operands]
        else:
            row_family = {value(w) for w in family}
            checked = base["checked_cover"](row_family, edge_cover)
            cost = base["verify_certificate"](d_raw, e_raw, row_family, checked, args.budget)
            data["witness"] = {"d": d_raw, "e": e_raw, "family": sorted(row_family),
                               "cover": sorted(checked), "cost": cost}
    elif done.returncode not in (0, 20):
        raise RuntimeError(done.stderr.strip() or f"Unexpected CaDiCaL exit {done.returncode}.")
    print(json.dumps(data), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("count", type=int)
    parser.add_argument("--case", choices=("all", "safe", "overlap"), default="all")
    parser.add_argument("--budget", type=int, default=20)
    parser.add_argument("--seconds", type=int, default=120)
    parser.add_argument("--cadical", required=True)
    parser.add_argument("--proof", type=Path)
    parser.add_argument("--unbounded", action="store_true")
    parser.add_argument("--producer-width", type=int)
    parser.add_argument("--plain-unions", type=int)
    parser.add_argument("--support-family", action="store_true")
    parser.add_argument("--force-merge", action="store_true")
    parser.add_argument("--distinct-operands", action="store_true")
    parser.add_argument("--direct-compatibility", action="store_true")
    parser.add_argument("--rectangle-free", action="store_true")
    parser.add_argument("--maximal-terms", action="store_true")
    parser.add_argument("--graph-charges", action="store_true")
    parser.add_argument("--live-unions", action="store_true")
    parser.add_argument("--terminal-gate", action="store_true")
    parser.add_argument("--two-overlap-mode", choices=("double-chain", "single-chain", "independent"))
    parser.add_argument("--minimum-paid-tags", type=int, default=0)
    parser.add_argument("--maximum-paid-tags", type=int)
    parser.add_argument("--profiles", type=Path, action="append")
    parser.add_argument("--profile-shapes", choices=("overlap", "safe"))
    parser.add_argument("--compatible-vertex", type=int, choices=range(len(vertices)))
    parser.add_argument("--shared-negative", type=int, choices=range(16, 40))
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--private", action="store_true")
    run(parser.parse_args())


if __name__ == "__main__":
    main()
