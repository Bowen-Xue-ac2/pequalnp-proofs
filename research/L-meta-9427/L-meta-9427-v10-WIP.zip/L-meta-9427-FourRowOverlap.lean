import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def matchingExampleLeft : Finset ℕ := rootSet 6 ∪ rootSet 9

def matchingExampleRight : Finset ℕ := rootSet 7 ∪ rootSet 10

def matchingExampleUnion : Finset ℕ := rootSet 3 ∪ rootSet 4

def matchingExampleD : Finset ℕ := matchingExampleLeft ∩ matchingExampleRight

def matchingExampleE : Finset ℕ := rootSet 1 ∩ matchingExampleUnion

def matchingExampleKept : Finset (Fin 11 × Fin 11) :=
  orientedEdges \ {(1, 4), (6, 7), (6, 10), (7, 9)}

set_option maxHeartbeats 4000000 in
private theorem matchingExampleRows :
    ∀ r : Fin 16, edgeAt r ∈ matchingExampleKept →
      r.val ∉ matchingExampleD ∧ r.val ∉ matchingExampleE := by
  decide +kernel

set_option maxRecDepth 10000 in
set_option maxHeartbeats 12000000 in
private theorem matchingExampleCenters :
    ∀ C : Finset (Fin 11), (∀ f ∈ matchingExampleKept, f.1 ∈ C ∨ f.2 ∈ C) →
      5 ≤ C.card ∧ (C.card = 5 → 7 ∉ C) := by
  decide +kernel

set_option maxHeartbeats 4000000 in
private theorem matchingExampleNoNeighbors :
    (∀ u : Fin 11, ¬(matchingExampleUnion ∩ rootSet u ∩ actualRows ⊆ edgeRows)) ∧
    (∀ u : Fin 11, u ≠ 7 → ¬(matchingExampleLeft ∩ rootSet u ∩ actualRows ⊆ edgeRows)) := by
  decide +kernel

set_option maxHeartbeats 4000000 in
private theorem matchingExampleDistinct :
    matchingExampleUnion ∉ markedSeeds matchingExampleD matchingExampleE ∧
    matchingExampleLeft ∉ markedSeeds matchingExampleD matchingExampleE ∧
    ¬carriesTag matchingExampleUnion ∧ ¬carriesTag matchingExampleLeft ∧
    matchingExampleUnion ≠ matchingExampleLeft := by
  decide +kernel

private theorem costFourRowOverlapExample (D B : Finset (Finset ℕ))
    (W : matchingExampleUnion ∈ D) (U : matchingExampleLeft ∈ D)
    (build : ∀ w ∈ D, w ∉ markedSeeds matchingExampleD matchingExampleE →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds matchingExampleD matchingExampleE).card + 2 * B.card := by
  have dRows : matchingExampleD ⊆ actualRows :=
    Finset.inter_subset_left.trans (Finset.union_subset (rootRowsBound 6) (rootRowsBound 9))
  have eRows : matchingExampleE ⊆ actualRows :=
    Finset.inter_subset_left.trans (rootRowsBound 1)
  have edgeCount : matchingExampleKept.card = 12 := by decide
  apply costByProjectedCenters matchingExampleD matchingExampleE D B dRows eRows
    build pairs cover matchingExampleKept Finset.sdiff_subset
    (fun r hr lost => (possibleOmissionMem lost).elim
      (matchingExampleRows r hr).1 (matchingExampleRows r hr).2)
  intro C hC
  obtain ⟨five, noSeven⟩ := matchingExampleCenters C hC
  obtain ⟨WNotSeed, UNotSeed, WTag, UTag, distinct⟩ := matchingExampleDistinct
  have WUnused : matchingExampleUnion ∈ D \ markedSeeds matchingExampleD matchingExampleE ∧
      ¬carriesTag matchingExampleUnion ∧
      ∀ u ∈ C, ¬(matchingExampleUnion ∩ rootSet u ∩ actualRows ⊆ edgeRows) :=
    ⟨Finset.mem_sdiff.mpr ⟨W, WNotSeed⟩, WTag, fun u _ => matchingExampleNoNeighbors.1 u⟩
  by_cases equal : C.card = 5
  · refine ⟨{matchingExampleUnion, matchingExampleLeft}, ?_, ?_⟩
    · have notMem : matchingExampleUnion ∉ ({matchingExampleLeft} : Finset (Finset ℕ)) := by
        simpa only [Finset.mem_singleton] using distinct
      rw [Finset.card_insert_of_notMem notMem, Finset.card_singleton, edgeCount, equal]
    · intro w hw
      rcases Finset.mem_insert.mp hw with rfl | atU
      · exact WUnused
      · obtain rfl := Finset.mem_singleton.mp atU
        exact ⟨Finset.mem_sdiff.mpr ⟨U, UNotSeed⟩, UTag, fun u hu =>
          matchingExampleNoNeighbors.2 u (fun eq => noSeven equal (eq ▸ hu))⟩
  · refine ⟨{matchingExampleUnion}, ?_, ?_⟩
    · rw [Finset.card_singleton, edgeCount]
      omega
    · intro w hw
      obtain rfl := Finset.mem_singleton.mp hw
      exact WUnused

end PEqualNP.Outside.L_meta_9427
