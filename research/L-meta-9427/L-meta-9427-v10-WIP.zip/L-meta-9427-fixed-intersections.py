"""Exact cover search at fixed choices of the two junk intersections.

Each wire is represented by a subset of the thirteen seed supports.
The union rules are enforced in the same search as the cover. Only
subsets of potential head operands are needed to build those operands.
The initial cases use junk intersections between two vertex seeds, so
their four operands are already available. Every returned witness goes
through the independent checker for the original row-family constraints.
"""

import argparse
import functools
import itertools
import json
from pathlib import Path
import runpy

import z3


model = runpy.run_path(str(Path(__file__).with_name("L-meta-9427-model.py")))
VERTICES = model["VERTEX_ROWS"]
NEGATIVE = model["NEGATIVE_ROWS"]
TARGET = model["TARGET"]
TAG_D, TAG_E = model["TAG_D"], model["TAG_E"]
pair_rows = model["pair_rows"]
checked_cover = model["checked_cover"]
verify = model["verify_certificate"]


def subsets(mask):
    subset = mask
    while subset:
        yield subset
        subset = (subset - 1) & mask


@functools.cache
def decompositions(support):
    options = list(subsets(support))
    return tuple(
        (a, b)
        for i, a in enumerate(options[1:])
        for b in options[i+2:]
        if a | b == support
    )


def head_options(seeds, max_support, overlap=False):
    neighbors = []
    tag_start = len(seeds) - 2
    for j, seed in enumerate(seeds):
        neighbors.append(sum(
            1 << i for i, v in enumerate(seeds) if not seed & v & NEGATIVE
            and not (overlap and i >= tag_start and j >= tag_start)
        ))
    size = 1 << len(seeds)
    available = [0] * size
    masks = [0] * size
    available[0] = size - 1
    heads = []
    for support in range(1, size):
        bit = support & -support
        i = bit.bit_length() - 1
        rest = support ^ bit
        available[support] = available[rest] & neighbors[i]
        masks[support] = masks[rest] | seeds[i]
    for left in range(1, size):
        if left.bit_count() > max_support:
            continue
        for right in subsets(available[left]):
            if right < left or right.bit_count() > max_support:
                continue
            term = pair_rows(masks[left], masks[right])
            if term:
                heads.append((left, right, term))
    return masks, heads


def solve(d, e, budget, milliseconds, producers=(), max_support=13):
    seeds = (*VERTICES, d | TAG_D, e | TAG_E)
    if d & e & NEGATIVE and not any((d | e) & v & NEGATIVE == 0 for v in VERTICES):
        return "unsat", None
    rows, heads = head_options(seeds, max_support)
    if model["union"](term for _, _, term in heads) != TARGET:
        return "unsat", None

    required = {support for left, right, _ in heads for support in (left, right)}
    required.update(producers)
    nodes = {
        sub
        for support in required
        for sub in subsets(support)
        if sub.bit_count() > 1 and rows[sub] not in seeds
    }
    # Boolean variables are indexed by support, while the charged wire
    # variables below are indexed by their actual row-set masks.
    generated = {s: z3.Bool(f"support_{s}") for s in sorted(nodes)}
    by_rows = {}
    for support, variable in generated.items():
        by_rows.setdefault(rows[support], []).append(variable)

    def present(support):
        if rows[support] in seeds:
            return z3.BoolVal(True)
        return generated[support]

    solver = z3.SolverFor("QF_FD")
    solver.set(timeout=milliseconds)
    for support in producers:
        solver.add(present(support))
    for support, variable in generated.items():
        witnesses = [
            z3.And(present(a), present(b))
            for a, b in decompositions(support)
            if rows[a] != rows[support] and rows[b] != rows[support]
        ]
        solver.add(z3.Implies(variable, z3.Or(*witnesses)))

    wires = []
    for row_mask, choices in by_rows.items():
        wire = z3.Bool(f"wire_{row_mask}")
        solver.add(wire == z3.Or(*choices))
        wires.append(wire)

    by_term = {}
    for left, right, term in heads:
        by_term.setdefault(term, []).append(z3.And(present(left), present(right)))
    selected = {term: z3.Bool(f"cover_{term}") for term in sorted(by_term)}
    for term, choices in by_term.items():
        solver.add(z3.Implies(selected[term], z3.Or(*choices)))
    for row in (*range(16), 40):
        solver.add(z3.Or(*(v for term, v in selected.items() if term & (1 << row))))
    solver.add(z3.PbLe([(v, 1) for v in selected.values()], 9))
    solver.add(z3.PbLe([(v, 1) for v in wires], 18))
    solver.add(z3.PbLe([(v, 1) for v in wires] + [(v, 2) for v in selected.values()], budget))
    result = solver.check()
    if result != z3.sat:
        return str(result), None

    answer = solver.model()
    family = set(seeds)
    family.update(rows[s] for s, v in generated.items() if z3.is_true(answer.eval(v)))
    candidate = {term for term, v in selected.items() if z3.is_true(answer.eval(v))}
    if family == set(seeds):
        # The posted statement requires a nonempty set of union nodes.
        # A free slot can be filled with a proper union of two roots.
        if 2 * len(candidate) == budget:
            return "requires_nonempty_family_check", None
        additional = next((a | b for a, b in itertools.combinations(seeds, 2)
                           if a | b not in family and a | b != a and a | b != b), None)
        if additional is None:
            return "requires_nonempty_family_check", None
        family.add(additional)
    cover = checked_cover(family, candidate)
    cost = verify(d, e, family, cover, budget)
    return "sat", {
        "d": d, "e": e, "family": sorted(family), "cover": sorted(cover), "cost": cost,
    }


def ranked_pairs():
    atoms = [(1 << i, v) for i, v in enumerate(VERTICES)]
    options = atoms + [(a | b, u | v) for (a,u), (b,v) in itertools.combinations(atoms, 2)]
    producer = {}
    for (left, a), (right, b) in itertools.combinations_with_replacement(options, 2):
        value = a & b
        if value & NEGATIVE:
            cost = len({s for s in (left,right) if s.bit_count() > 1})
            record = (cost, left, right)
            if value not in producer or record < producer[value]:
                producer[value] = record

    low = model["EDGE_ROWS"]
    projection = {}
    gain = {}
    for value in producer:
        projection[value] = model["union"](v for v in VERTICES if v & value == v)
        compatible = model["union"](
            v & value & low for v in VERTICES if v & value & NEGATIVE == 0
        )
        gain[value] = compatible & ~projection[value]

    valuable = sorted(producer, key=lambda v: (gain[v].bit_count() - producer[v][0],
                                               gain[v].bit_count(), v), reverse=True)[:85]
    roots = {v for v, source in producer.items() if source[0] == 0}
    candidates = []
    for d, e in itertools.combinations_with_replacement(sorted(set(valuable) | roots), 2):
        if d in roots and e in roots:
            continue
        inherited = gain[d] | gain[e]
        if d & e & NEGATIVE == 0:
            inherited |= d & e & low & ~(projection[d] & projection[e])
        elif not any((d | e) & v & NEGATIVE == 0 for v in VERTICES):
            continue
        needed = set(producer[d][1:] + producer[e][1:])
        cost = sum(s.bit_count() > 1 for s in needed)
        score = inherited.bit_count() - cost
        candidates.append((score, inherited.bit_count(), d, e, tuple(sorted(needed))))
    candidates.sort(reverse=True)
    return [(d, e, needs) for _, _, d, e, needs in candidates]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--count", type=int, default=40)
    parser.add_argument("--budget", type=int, default=20)
    parser.add_argument("--milliseconds", type=int, default=550)
    parser.add_argument("--ranked", action="store_true")
    parser.add_argument("--max-support", type=int, default=13)
    args = parser.parse_args()
    if args.ranked:
        pairs = ranked_pairs()
    else:
        possible = sorted({a & b for a in VERTICES for b in VERTICES if a & b & NEGATIVE})
        pairs = [(d, e, ()) for d, e in itertools.combinations_with_replacement(possible, 2)]
    pending = []
    tested = 0
    for index in range(args.start, min(args.start + args.count, len(pairs))):
        d, e, producers = pairs[index]
        result, witness = solve(d, e, args.budget, args.milliseconds, producers, args.max_support)
        tested += 1
        if result == "sat":
            print(json.dumps({"result": result, "index": index, "witness": witness}), flush=True)
            return
        if result != "unsat":
            pending.append({"index": index, "result": result})
    print(json.dumps({"start": args.start, "tested": tested, "total": len(pairs),
                      "unresolved": pending, "budget": args.budget}), flush=True)


if __name__ == "__main__":
    main()
