import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem eraseSeedFacts (d e : Finset ℕ) (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (w : Finset ℕ) (hw : w ∈ markedSeeds d e) :
    ∃ s : Finset (Fin 11), s.card ≤ 1 ∧ projectionFacts d e ∅ ∅ w s ∧
      ((40 ∈ w ∨ 41 ∈ w) → s = ∅) ∧ ¬(40 ∈ w ∧ 41 ∈ w) := by
  have no40 : 40 ∉ actualRows := by decide
  have no41 : 41 ∉ actualRows := by decide
  have erase (t tag : ℕ) (s : Finset ℕ) (h : tag ∉ actualRows)
      (ht : t ∈ insert tag s) (actual : t ∈ actualRows) : t ∈ s := by
    rcases Finset.mem_insert.mp ht with eq | existsT
    · exact (h (eq ▸ actual)).elim
    · exact existsT
  simp only [markedSeeds, Finset.mem_insert] at hw
  rcases hw with rfl | rfl | ordinary
  · have absent : 41 ∉ insert 40 d := by
      intro h
      rcases Finset.mem_insert.mp h with eq | h
      · omega
      · exact no41 (dRows h)
    refine ⟨∅, by simp, ?_, fun _ => rfl, fun h => absent h.2⟩
    refine ⟨by simp [rowsOf], fun _ => ⟨Finset.subset_insert _ _, Finset.empty_subset _⟩,
      fun h => (absent h).elim, ?_⟩
    intro r hr actual
    exact Or.inr (Or.inl ⟨Finset.mem_insert_self _ _, erase r 40 d no40 hr actual⟩)
  · have absent : 40 ∉ insert 41 e := by
      intro h
      rcases Finset.mem_insert.mp h with eq | h
      · omega
      · exact no40 (eRows h)
    refine ⟨∅, by simp, ?_, fun _ => rfl, fun h => absent h.1⟩
    refine ⟨by simp [rowsOf], fun h => (absent h).elim,
      fun _ => ⟨Finset.subset_insert _ _, Finset.empty_subset _⟩, ?_⟩
    intro r hr actual
    exact Or.inr (Or.inr ⟨Finset.mem_insert_self _ _, erase r 41 e no41 hr actual⟩)
  · obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp ordinary
    have noP : 40 ∉ rootSet u := fun h => no40 (rootRowsBound u h)
    have noQ : 41 ∉ rootSet u := fun h => no41 (rootRowsBound u h)
    refine ⟨{u}, by simp, ?_, fun h => (h.elim noP noQ).elim, fun h => noP h.1⟩
    refine ⟨by simp [rowsOf], fun h => (noP h).elim, fun h => (noQ h).elim, ?_⟩
    intro r hr _
    exact Or.inl (by simpa [rowsOf] using hr)

private theorem cleanProductFacts (a b : Finset ℕ)
    (inside : productTerm a b ⊆ insert 40 edgeRows) :
    (a ∩ b ∩ actualRows ⊆ edgeRows) ∧
      (productTerm a b ∩ edgeRows = a ∩ b ∩ edgeRows) ∧
      (40 ∈ productTerm a b → {40, 41} ⊆ a ∪ b) := by
  have no40 : 40 ∉ actualRows := by decide
  constructor
  · intro r normal
    rcases Finset.mem_insert.mp (inside (Finset.mem_union.mpr (Or.inl normal))) with eq | exactRow
    · exact (no40 (eq ▸ (Finset.mem_inter.mp normal).2)).elim
    · exact exactRow
  constructor
  · have htag : (if {40, 41} ⊆ a ∪ b then {40} else (∅ : Finset ℕ)) ∩ edgeRows = ∅ := by
      by_cases flag : {40, 41} ⊆ a ∪ b <;> simp [flag, show 40 ∉ edgeRows by decide]
    have hpos : edgeRows ⊆ actualRows := by decide
    rw [productTerm, Finset.union_inter_distrib_right, htag, Finset.union_empty,
      Finset.inter_assoc, Finset.inter_eq_right.mpr hpos]
  · intro ht
    rcases Finset.mem_union.mp ht with normal | flag
    · exact (no40 (Finset.mem_inter.mp normal).2).elim
    · by_contra h
      have impossible : 40 ∈ (∅ : Finset ℕ) := by simpa [h] using flag
      exact (Finset.notMem_empty 40) impossible

private theorem costOverlapErasingTwoEdges (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (n : ℕ) (nd : n ∈ d) (ne : n ∈ e) (neg : n ∉ edgeRows)
    (missing : Finset (Fin 11 × Fin 11)) (missingSub : missing ⊆ orientedEdges)
    (missingCount : missing.card ≤ 2)
    (keepD : retainedRootPairs d ∅ missing) (keepE : retainedRootPairs e ∅ missing)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  classical
  let seed (w : Finset ℕ) : Finset (Fin 11) :=
    if h : w ∈ markedSeeds d e then (eraseSeedFacts d e dRows eRows w h).choose else ∅
  obtain ⟨label, rootLabel, unionLabel⟩ :=
    labelUnionFamily D (markedSeeds d e) seed build
  have roots (w : Finset ℕ) (hw : w ∈ D) (hx : w ∈ markedSeeds d e) :
      (label w).card ≤ 1 ∧ projectionFacts d e ∅ ∅ w (label w) ∧
      ((40 ∈ w ∨ 41 ∈ w) → label w = ∅) ∧ ¬(40 ∈ w ∧ 41 ∈ w) := by
    rw [rootLabel w hw hx]
    simpa [seed, hx] using (eraseSeedFacts d e dRows eRows w hx).choose_spec
  have replay := projectionFactsReplay D (markedSeeds d e) d e ∅ ∅ label
    (fun w hw hx => (roots w hw hx).2.1) unionLabel
  obtain ⟨count, buildProjected⟩ := projectedFamily D (markedSeeds d e) label
    (fun w hw hx => (roots w hw hx).1) (fun w hw hx => by
      obtain ⟨a, ha, b, hb, haSub, hbSub, _, eq⟩ := unionLabel w hw hx
      exact ⟨a, ha, b, hb, haSub, hbSub, eq⟩)
  have keeps (a b : Finset ℕ) (ha : a ∈ D) (hb : b ∈ D)
      (inside : productTerm a b ⊆ insert 40 edgeRows) :
      rowsOf (label a) ∩ rowsOf (label b) ⊆ edgeRows ∧
      ∀ r : Fin 16, r.val ∈ productTerm a b → edgeAt r ∉ missing →
        r.val ∈ rowsOf (label a) ∩ rowsOf (label b) := by
    obtain ⟨clean, values, _⟩ := cleanProductFacts a b inside
    have fa := replay a ha
    have fb := replay b hb
    constructor
    · intro row hr
      obtain ⟨inA, inB⟩ := Finset.mem_inter.mp hr
      obtain ⟨x, _, atRoot⟩ := Finset.mem_biUnion.mp inA
      exact clean (Finset.mem_inter.mpr
        ⟨Finset.mem_inter.mpr ⟨fa.1 inA, fb.1 inB⟩, rootRowsBound x atRoot⟩)
    · intro r inTerm present
      have inProduct : r.val ∈ productTerm a b ∩ edgeRows :=
        Finset.mem_inter.mpr ⟨inTerm, Finset.mem_range.mpr r.isLt⟩
      rw [values] at inProduct
      obtain ⟨ra, rb⟩ := Finset.mem_inter.mp (Finset.mem_inter.mp inProduct).1
      have rev : b ∩ a ∩ actualRows ⊆ edgeRows := by simpa only [Finset.inter_comm a b] using clean
      exact Finset.mem_inter.mpr
        ⟨retainOverlapLeft d e a b ∅ ∅ (label a) (label b) fa fb missing
          keepD keepE clean n nd ne (dRows nd) neg r ra rb present,
         retainOverlapLeft d e b a ∅ ∅ (label b) (label a) fb fa missing
          keepD keepE rev n nd ne (dRows nd) neg r rb ra present⟩
  have projectedPairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      rowsOf (label a) ∩ rowsOf (label b) ⊆ edgeRows ∧
      ∀ r : Fin 16, r.val ∈ t → edgeAt r ∉ missing →
        r.val ∈ rowsOf (label a) ∩ rowsOf (label b) := by
    intro t ht
    obtain ⟨a, ha, b, hb, rfl, inside⟩ := pairs t ht
    exact ⟨a, ha, b, hb, keeps a b ha hb inside⟩
  have edgeCover : edgeRows ⊆ B.biUnion id := by
    rw [cover]
    exact Finset.subset_insert _ _
  obtain ⟨H, headsCount, heads, covered⟩ :=
    headsFromProjection D B label missing projectedPairs edgeCover
  have pure := pureCostWithMissing (D.image label) H missing missingSub buildProjected heads covered
  have termSubset : retainedTerms B missing ⊆ B := Finset.filter_subset _ _
  have generalHeads := headsCount.trans (Finset.card_le_card termSubset)
  have tagCovered : 40 ∈ B.biUnion id := by rw [cover]; exact Finset.mem_insert_self _ _
  obtain ⟨term, termIn, tagIn⟩ := Finset.mem_biUnion.mp tagCovered
  obtain ⟨a, ha, b, hb, termEq, inside⟩ := pairs term termIn
  rw [termEq] at tagIn inside
  obtain ⟨clean, _, flags⟩ := cleanProductFacts a b inside
  have bothFlags := flags tagIn
  have aOrB40 : 40 ∈ a ∨ 40 ∈ b :=
    Finset.mem_union.mp (bothFlags (Finset.mem_insert_self _ _))
  have aOrB41 : 41 ∈ a ∨ 41 ∈ b :=
    Finset.mem_union.mp (bothFlags (Finset.mem_insert_of_mem (Finset.mem_singleton_self _)))
  have common (w : Finset ℕ) (hw : w ∈ D) (flags : 40 ∈ w ∨ 41 ∈ w) : n ∈ w := by
    have facts := replay w hw
    rcases flags with h | h
    · exact (facts.2.1 h).1 nd
    · exact (facts.2.2.1 h).1 ne
  have forbidden (aFlag : 40 ∈ a ∨ 41 ∈ a) (bFlag : 40 ∈ b ∨ 41 ∈ b) : False :=
    neg (clean (Finset.mem_inter.mpr
      ⟨Finset.mem_inter.mpr ⟨common a ha aFlag, common b hb bFlag⟩, dRows nd⟩))
  have solveCarrier (w : Finset ℕ) (hw : w ∈ D) (w40 : 40 ∈ w) (w41 : 41 ∈ w)
      (side : w = a ∨ w = b) : 21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
    by_cases live : (label w).Nonempty
    · have sz := doubleTagUnionDeficit D (markedSeeds d e) label
        (fun v hv hx => (roots v hv hx).2.2) unionLabel w hw w40 w41 live
      have deficit := projectionUnionDeficit D (markedSeeds d e) label
        (fun v hv hx => (roots v hv hx).1)
      omega
    · have erased : label w = ∅ := Finset.not_nonempty_iff_eq_empty.mp live
      have noTerm : term ∉ retainedTerms B missing := by
        intro retained
        obtain ⟨_, r, real, notMissing⟩ := Finset.mem_filter.mp retained
        rw [termEq] at real
        have kept := (keeps a b ha hb inside).2 r real notMissing
        rcases side with eq | eq
        · have atEmpty := (Finset.mem_inter.mp kept).1
          rw [← eq, erased] at atEmpty
          simpa [rowsOf] using atEmpty
        · have atEmpty := (Finset.mem_inter.mp kept).2
          rw [← eq, erased] at atEmpty
          simpa [rowsOf] using atEmpty
      have strict : retainedTerms B missing ⊂ B := Finset.ssubset_iff_subset_ne.mpr
        ⟨termSubset, fun eq => noTerm (eq.symm ▸ termIn)⟩
      have shorter := Finset.card_lt_card strict
      omega
  rcases aOrB40 with p | p <;> rcases aOrB41 with q | q
  · exact solveCarrier a ha p q (Or.inl rfl)
  · exact (forbidden (Or.inl p) (Or.inr q)).elim
  · exact (forbidden (Or.inr q) (Or.inl p)).elim
  · exact solveCarrier b hb p q (Or.inr rfl)

end PEqualNP.Outside.L_meta_9427
