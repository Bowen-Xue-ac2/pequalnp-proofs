import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem edgeSwap (u v : Fin 11) : edge u v ↔ edge v u := by
  simp only [edge, Nat.land_comm (row u) (row v), ne_comm]

private theorem purePairStar (A B : Finset (Fin 11))
    (compatible : ∀ a ∈ A, ∀ b ∈ B, edge a b) : A.card ≤ 1 ∨ B.card ≤ 1 := by
  by_cases small : A.card ≤ 1
  · exact Or.inl small
  right
  obtain ⟨u, hu, v, hv, huv⟩ := Finset.one_lt_card.mp (Nat.lt_of_not_ge small)
  have sub : B ⊆ neighbors u ∩ neighbors v := by
    intro b hb
    exact Finset.mem_inter.mpr
      ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, compatible u hu b hb⟩,
       Finset.mem_filter.mpr ⟨Finset.mem_univ _, compatible v hv b hb⟩⟩
  exact (Finset.card_le_card sub).trans (commonNeighbors u v huv)

private theorem sumDisjointCard {α β : Type} [DecidableEq β]
    (A : Finset α) (family : α → Finset β) (T : Finset β)
    (sub : ∀ a ∈ A, family a ⊆ T)
    (separate : (A : Set α).PairwiseDisjoint family) :
    (∑ a ∈ A, (family a).card) ≤ T.card := by
  rw [← Finset.card_biUnion separate]
  apply Finset.card_le_card
  intro b hb
  obtain ⟨a, ha, hab⟩ := Finset.mem_biUnion.mp hb
  exact sub a ha hab

private theorem purePartialCost
    (D : Finset (Finset (Fin 11))) (H : Finset (Fin 11 × Finset (Fin 11)))
    (E : Finset (Fin 11 × Fin 11)) (edgeSubset : E ⊆ orientedEdges)
    (build : ∀ w ∈ D, 1 < w.card →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (heads : ∀ h ∈ H, h.2 ∈ D ∧ h.2 ⊆ neighbors h.1)
    (covers : ∀ e ∈ E, ∃ h ∈ H,
      (e.1 = h.1 ∧ e.2 ∈ h.2) ∨ (e.2 = h.1 ∧ e.1 ∈ h.2)) :
    E.card ≤ (D.filter fun s => 1 < s.card).card + H.card := by
  let centers := H.image Prod.fst
  let rowsFor (u : Fin 11) := D.filter fun s => s ⊆ neighbors u
  let fiber (u : Fin 11) := H.filter fun h => h.1 = u
  let leaves (u : Fin 11) := (fiber u).image Prod.snd
  let leafUnion (u : Fin 11) := (leaves u).biUnion id
  let big (u : Fin 11) := (rowsFor u).filter fun s => 1 < s.card
  let ordered (p : Fin 11 × Fin 11) := if p.1 < p.2 then p else (p.2, p.1)
  let incidence := centers.biUnion fun u => (leafUnion u).image (Prod.mk u)

  have incidenceSubset : E ⊆ incidence.image ordered := by
    intro e he
    obtain ⟨h, hh, hends⟩ := covers e he
    have hc : h.1 ∈ centers := Finset.mem_image_of_mem _ hh
    have hp : h.2 ∈ leaves h.1 := Finset.mem_image_of_mem _
      (Finset.mem_filter.mpr ⟨hh, rfl⟩)
    have inPairs : ∀ v ∈ h.2, (h.1, v) ∈ incidence := by
      intro v hv
      have hx : v ∈ leafUnion h.1 := Finset.mem_biUnion.mpr ⟨h.2, hp, hv⟩
      exact Finset.mem_biUnion.mpr ⟨h.1, hc, Finset.mem_image_of_mem _ hx⟩
    have lt : e.1 < e.2 := ((Finset.mem_filter.mp (edgeSubset he)).2).1
    rcases hends with ⟨h₁, hv⟩ | ⟨h₂, hv⟩
    · refine Finset.mem_image.mpr ⟨(h.1, e.2), inPairs e.2 hv, ?_⟩
      rw [← h₁]
      simp [ordered, lt]
    · refine Finset.mem_image.mpr ⟨(h.1, e.1), inPairs e.1 hv, ?_⟩
      rw [← h₂]
      have notReverse : ¬e.2 < e.1 := (lt_asymm lt)
      simp [ordered, notReverse]

  have edgesLe : E.card ≤ incidence.card := calc
    _ ≤ (incidence.image ordered).card := Finset.card_le_card incidenceSubset
    _ ≤ incidence.card := Finset.card_image_le
  have incidenceLe : incidence.card ≤ ∑ u ∈ centers, (leafUnion u).card := calc
    incidence.card ≤ ∑ u ∈ centers, ((leafUnion u).image (Prod.mk u)).card :=
      Finset.card_biUnion_le
    _ ≤ ∑ u ∈ centers, (leafUnion u).card :=
      Finset.sum_le_sum (fun _ _ => Finset.card_image_le)

  have localBound (u : Fin 11) : (leafUnion u).card ≤ (leaves u).card + (big u).card := by
    apply unionBudget
    · intro s hs
      obtain ⟨h, hh, rfl⟩ := Finset.mem_image.mp hs
      obtain ⟨inH, center⟩ := Finset.mem_filter.mp hh
      simpa only [rowsFor, Finset.mem_filter, ← center] using heads h inH
    · intro s hs large
      obtain ⟨inD, sub⟩ := Finset.mem_filter.mp hs
      obtain ⟨a, ha, b, hb, asub, bsub, eq⟩ := build s inD large
      exact ⟨a, Finset.mem_filter.mpr ⟨ha, asub.1.trans sub⟩,
        b, Finset.mem_filter.mpr ⟨hb, bsub.1.trans sub⟩, asub, bsub, eq⟩

  have distinctFiber : (centers : Set (Fin 11)).PairwiseDisjoint fiber := by
    intro u _ v _ different
    apply Finset.disjoint_left.mpr
    intro h hu hv
    exact different ((Finset.mem_filter.mp hu).2.symm.trans (Finset.mem_filter.mp hv).2)
  have rootsTotal : (∑ u ∈ centers, (leaves u).card) ≤ H.card := calc
    _ ≤ ∑ u ∈ centers, (fiber u).card :=
      Finset.sum_le_sum (fun _ _ => Finset.card_image_le)
    _ ≤ H.card := sumDisjointCard centers fiber H
      (fun _ _ => Finset.filter_subset _ _) distinctFiber
  have distinctBig : (centers : Set (Fin 11)).PairwiseDisjoint big := by
    intro u _ v _ different
    apply Finset.disjoint_left.mpr
    intro s hu hv
    have su := (Finset.mem_filter.mp (Finset.mem_filter.mp hu).1).2
    have sv := (Finset.mem_filter.mp (Finset.mem_filter.mp hv).1).2
    have large := (Finset.mem_filter.mp hu).2
    have hs : s ⊆ neighbors u ∩ neighbors v := fun _ hw =>
      Finset.mem_inter.mpr ⟨su hw, sv hw⟩
    exact (Nat.not_le_of_gt large) ((Finset.card_le_card hs).trans (commonNeighbors u v different))
  have gatesTotal : (∑ u ∈ centers, (big u).card) ≤
      (D.filter fun s => 1 < s.card).card := by
    apply sumDisjointCard centers big _ _ distinctBig
    intro u _ s hs
    exact Finset.mem_filter.mpr ⟨(Finset.mem_filter.mp (Finset.mem_filter.mp hs).1).1,
      (Finset.mem_filter.mp hs).2⟩
  have total := Finset.sum_le_sum (s := centers) (fun u _ => localBound u)
  rw [Finset.sum_add_distrib] at total
  omega

private theorem coverCenters
    (H : Finset (Fin 11 × Finset (Fin 11))) (E : Finset (Fin 11 × Fin 11))
    (covers : ∀ e ∈ E, ∃ h ∈ H,
      (e.1 = h.1 ∧ e.2 ∈ h.2) ∨ (e.2 = h.1 ∧ e.1 ∈ h.2)) :
    ∀ e ∈ E, e.1 ∈ H.image Prod.fst ∨ e.2 ∈ H.image Prod.fst := by
  intro e he
  obtain ⟨h, hh, hends⟩ := covers e he
  have hc : h.1 ∈ H.image Prod.fst := Finset.mem_image_of_mem _ hh
  rcases hends with ⟨h₁, _⟩ | ⟨h₂, _⟩
  · exact Or.inl (h₁.symm ▸ hc)
  · exact Or.inr (h₂.symm ▸ hc)

private theorem pureCost
    (D : Finset (Finset (Fin 11))) (H : Finset (Fin 11 × Finset (Fin 11)))
    (build : ∀ w ∈ D, 1 < w.card →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (heads : ∀ h ∈ H, h.2 ∈ D ∧ h.2 ⊆ neighbors h.1)
    (covers : ∀ e ∈ orientedEdges, ∃ h ∈ H,
      (e.1 = h.1 ∧ e.2 ∈ h.2) ∨ (e.2 = h.1 ∧ e.1 ∈ h.2)) :
    23 ≤ (D.filter fun s => 1 < s.card).card + 2 * H.card := by
  have cover : isCover (H.image Prod.fst) := coverCenters H orientedEdges covers
  have needed := (coverNumber _ cover).trans (Finset.card_image_le (s := H) (f := Prod.fst))
  have edges := purePartialCost D H orientedEdges Finset.Subset.rfl build heads covers
  rw [edgeCount] at edges
  omega

end PEqualNP.Outside.L_meta_9427
