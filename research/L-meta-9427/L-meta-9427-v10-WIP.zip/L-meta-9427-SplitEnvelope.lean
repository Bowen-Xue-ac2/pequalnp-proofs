import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private def splitEnvelopeSide (d e : Finset ℕ) : Finset (Finset ℕ) :=
  insert (d ∩ (e ∪ rowsOf (tagCompatibility d)) ∩ edgeRows)
    ((tagCompatibility e).image fun u =>
      (d ∪ rootSet u) ∩ (e ∪ rowsOf (tagCompatibility d ∩ neighbors u)) ∩ edgeRows)

private def splitEnvelope (d e : Finset ℕ) : Finset (Finset ℕ) :=
  splitEnvelopeSide d e ∪ splitEnvelopeSide e d

private theorem coveredBySplitEnvelopeSide (d e : Finset ℕ) (A B : Finset (Fin 11))
    (small : A.card ≤ 1) (nameA : A ⊆ tagCompatibility e) (nameB : B ⊆ tagCompatibility d)
    (cross : ∀ u ∈ A, ∀ v ∈ B, edge u v)
    (clean : (d ∪ rowsOf A) ∩ (e ∪ rowsOf B) ⊆ edgeRows) :
    ∃ m ∈ splitEnvelopeSide d e, (d ∪ rowsOf A) ∩ (e ∪ rowsOf B) ⊆ m := by
  by_cases empty : A = ∅
  · refine ⟨_, Finset.mem_insert_self _ _, ?_⟩
    intro r hr
    obtain ⟨left, right⟩ := Finset.mem_inter.mp hr
    exact Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr
      ⟨by simpa [empty, rowsOf] using left, Finset.union_subset_union Finset.Subset.rfl
        (rowsOfMonotone nameB) right⟩, clean hr⟩
  obtain ⟨u, hu⟩ := Finset.card_eq_one.mp
    (Nat.le_antisymm small (Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr empty)))
  have here : u ∈ A := by simp [hu]
  have opposite : B ⊆ tagCompatibility d ∩ neighbors u := fun v hv =>
    Finset.mem_inter.mpr ⟨nameB hv, Finset.mem_filter.mpr ⟨Finset.mem_univ _, cross u here v hv⟩⟩
  refine ⟨_, Finset.mem_insert_of_mem (Finset.mem_image_of_mem _ (nameA here)), ?_⟩
  intro r hr
  obtain ⟨left, right⟩ := Finset.mem_inter.mp hr
  exact Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr
    ⟨by simpa [hu, rowsOf] using left,
      Finset.union_subset_union Finset.Subset.rfl (rowsOfMonotone opposite) right⟩, clean hr⟩

private theorem coveredBySplitEnvelope (d e : Finset ℕ) (A B : Finset (Fin 11))
    (clean : (d ∪ rowsOf A) ∩ (e ∪ rowsOf B) ⊆ edgeRows) :
    ∃ m ∈ splitEnvelope d e, (d ∪ rowsOf A) ∩ (e ∪ rowsOf B) ⊆ m := by
  have across := completeBetweenRows A B
    ((Finset.inter_subset_inter Finset.subset_union_right Finset.subset_union_right).trans clean)
  have left : A ⊆ tagCompatibility e := by
    intro u hu
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
    intro r hr
    obtain ⟨inE, inU⟩ := Finset.mem_inter.mp hr
    exact clean (Finset.mem_inter.mpr
      ⟨Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨u, hu, inU⟩), Finset.mem_union_left _ inE⟩)
  have right : B ⊆ tagCompatibility d := by
    intro v hv
    refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
    intro r hr
    obtain ⟨inD, inV⟩ := Finset.mem_inter.mp hr
    exact clean (Finset.mem_inter.mpr
      ⟨Finset.mem_union_left _ inD, Finset.mem_union_right _ (Finset.mem_biUnion.mpr ⟨v, hv, inV⟩)⟩)
  rcases purePairStar A B across with aSmall | bSmall
  · obtain ⟨m, hm, covers⟩ := coveredBySplitEnvelopeSide d e A B aSmall left right across clean
    exact ⟨m, Finset.mem_union_left _ hm, covers⟩
  · have flipped : (e ∪ rowsOf B) ∩ (d ∪ rowsOf A) ⊆ edgeRows := by
      rw [Finset.inter_comm]
      exact clean
    obtain ⟨m, hm, covered⟩ := coveredBySplitEnvelopeSide e d B A bSmall right left
      (fun v hv u hu => (edgeSwap u v).mp (across u hu v hv)) flipped
    exact ⟨m, Finset.mem_union_right _ hm, by rwa [Finset.inter_comm]⟩

private theorem negativePartOfIntersection (x y : Finset ℕ) :
    (x ∩ y) ∩ negativeRealRows = (x ∩ negativeRealRows) ∩ (y ∩ negativeRealRows) := by
  ext r
  simp only [Finset.mem_inter]
  tauto

private theorem compactIntersection (A B : Finset (Fin 11)) :
    ∃ P Q : Finset (Fin 11), rowsOf A ⊆ rowsOf P ∧ rowsOf B ⊆ rowsOf Q ∧
      (rowsOf A ∩ rowsOf B) ⊆ (rowsOf P ∩ rowsOf Q) ∧
      (rowsOf A ∩ rowsOf B) ∩ negativeRealRows = (rowsOf P ∩ rowsOf Q) ∩ negativeRealRows ∧
      (∀ U : Finset (Fin 11),
        rowsOf U ∩ negativeRealRows = rowsOf A ∩ negativeRealRows → rowsOf U ⊆ rowsOf P) ∧
      (∀ V : Finset (Fin 11),
        rowsOf V ∩ negativeRealRows = rowsOf B ∩ negativeRealRows → rowsOf V ⊆ rowsOf Q) := by
  obtain ⟨P, growsA, sameA, largestA⟩ := compactPureProducer A
  obtain ⟨Q, growsB, sameB, largestB⟩ := compactPureProducer B
  refine ⟨P, Q, growsA, growsB, Finset.inter_subset_inter growsA growsB, ?_, largestA, largestB⟩
  rw [negativePartOfIntersection, negativePartOfIntersection (rowsOf P), sameA, sameB]

private theorem operandNegativePart (d e p q : Finset ℕ) (a : CoverOperand)
    (sameD : d ∩ negativeRealRows = p ∩ negativeRealRows)
    (sameE : e ∩ negativeRealRows = q ∩ negativeRealRows) :
    operandRows d e a ∩ negativeRealRows = operandRows p q a ∩ negativeRealRows := by
  rcases a with ⟨support, first, second⟩
  cases first <;> cases second <;> simp [operandRows, Finset.union_inter_distrib_right, sameD, sameE]

private theorem operandWithinRealRows (d e : Finset ℕ) (a : CoverOperand)
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows) : operandRows d e a ⊆ actualRows := by
  rcases a with ⟨support, first, second⟩
  cases first <;> cases second <;>
    simp [operandRows, Finset.union_subset, rowsOfBound, dRows, eRows]

private theorem supportedCleanExactlyNoNegative (d e : Finset ℕ)
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows) (a b : CoverOperand) :
    supportedTerm d e (a, b) ⊆ insert 40 edgeRows ↔
      (operandRows d e a ∩ operandRows d e b) ∩ negativeRealRows = ∅ := by
  constructor
  · intro clean
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro r hr
    obtain ⟨core, neg⟩ := Finset.mem_inter.mp hr
    have used : r ∈ supportedTerm d e (a, b) := Finset.mem_union_left _ core
    rcases Finset.mem_insert.mp (clean used) with flag | pos
    · exact (show 40 ∉ actualRows by decide) (flag ▸ (Finset.mem_sdiff.mp neg).1)
    · exact (Finset.mem_sdiff.mp neg).2 pos
  · intro none
    intro r hr
    rcases Finset.mem_union.mp hr with core | marker
    · by_cases pos : r ∈ edgeRows
      · exact Finset.mem_insert_of_mem pos
      have bound := operandWithinRealRows d e a dRows eRows (Finset.mem_inter.mp core).1
      have neg := Finset.mem_sdiff.mpr ⟨bound, pos⟩
      exact (Finset.notMem_empty r (none ▸ Finset.mem_inter.mpr ⟨core, neg⟩)).elim
    · split at marker
      · exact Finset.mem_insert.mpr (Or.inl (Finset.mem_singleton.mp marker))
      · exact (Finset.notMem_empty r marker).elim

private theorem supportedTermsKeepCleanAfterSaturation (d e p q : Finset ℕ) (a b : CoverOperand)
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (pRows : p ⊆ actualRows) (qRows : q ⊆ actualRows)
    (sameD : d ∩ negativeRealRows = p ∩ negativeRealRows)
    (sameE : e ∩ negativeRealRows = q ∩ negativeRealRows)
    (growD : d ⊆ p) (growE : e ⊆ q) :
    supportedTerm d e (a,b) ⊆ supportedTerm p q (a,b) ∧
    (supportedTerm d e (a,b) ⊆ insert 40 edgeRows ↔
      supportedTerm p q (a,b) ⊆ insert 40 edgeRows) := by
  have grow (u : CoverOperand) : operandRows d e u ⊆ operandRows p q u := by
    rcases u with ⟨support, first, second⟩
    cases first <;> cases second <;>
      simp [operandRows, Finset.union_subset_union, growD, growE]
  constructor
  · exact Finset.union_subset_union (Finset.inter_subset_inter (grow a) (grow b)) Finset.Subset.rfl
  · rw [supportedCleanExactlyNoNegative d e dRows eRows,
      supportedCleanExactlyNoNegative p q pRows qRows,
      negativePartOfIntersection, negativePartOfIntersection (operandRows p q a),
      operandNegativePart d e p q a sameD sameE, operandNegativePart d e p q b sameD sameE]

end PEqualNP.Outside.L_meta_9427

