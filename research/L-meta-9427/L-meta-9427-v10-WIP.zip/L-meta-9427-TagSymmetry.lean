import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def swapTagIndex (i : ℕ) : ℕ := if i = 40 then 41 else if i = 41 then 40 else i

def swapTagWord (w : Finset ℕ) : Finset ℕ := w.image swapTagIndex

private theorem swapTagIndexInvolutive : Function.Involutive swapTagIndex := by
  intro i
  by_cases p : i = 40
  · subst i
    decide
  by_cases q : i = 41
  · subst i
    decide
  simp [swapTagIndex, p, q]

private theorem memSwapTagWord (i : ℕ) (w : Finset ℕ) : i ∈ swapTagWord w ↔ swapTagIndex i ∈ w := by
  constructor
  · intro h
    obtain ⟨j, hw, rfl⟩ := Finset.mem_image.mp h
    rw [swapTagIndexInvolutive j]
    exact hw
  · intro hi
    exact Finset.mem_image.mpr ⟨swapTagIndex i, hi, swapTagIndexInvolutive i⟩

private theorem swapTagWordInvolutive : Function.Involutive swapTagWord := by
  intro w
  ext i
  rw [memSwapTagWord, memSwapTagWord, swapTagIndexInvolutive]

private theorem swapTagWordReal (w : Finset ℕ) (actual : w ⊆ actualRows) : swapTagWord w = w := by
  ext r
  rw [memSwapTagWord]
  by_cases p : r = 40
  · subst r
    change 41 ∈ w ↔ 40 ∈ w
    exact ⟨fun h => ((show 41 ∉ actualRows by decide) (actual h)).elim,
      fun h => ((show 40 ∉ actualRows by decide) (actual h)).elim⟩
  by_cases q : r = 41
  · subst r
    change 40 ∈ w ↔ 41 ∈ w
    exact ⟨fun h => ((show 40 ∉ actualRows by decide) (actual h)).elim,
      fun h => ((show 41 ∉ actualRows by decide) (actual h)).elim⟩
  simp [swapTagIndex, p, q]

private theorem swapTagProduct (a b : Finset ℕ) :
    productTerm (swapTagWord a) (swapTagWord b) = productTerm a b := by
  have flags :
      {40, 41} ⊆ swapTagWord a ∪ swapTagWord b ↔ {40, 41} ⊆ a ∪ b := by
    simp only [Finset.insert_subset_iff, Finset.singleton_subset_iff, Finset.mem_union,
      memSwapTagWord, show swapTagIndex 40 = 41 by decide, show swapTagIndex 41 = 40 by decide]
    exact and_comm
  have real : swapTagWord a ∩ swapTagWord b ∩ actualRows = a ∩ b ∩ actualRows := by
    ext r
    simp only [Finset.mem_inter, memSwapTagWord]
    by_cases inside : r ∈ actualRows
    · have lt := Finset.mem_range.mp inside
      have p : r ≠ 40 := by omega
      have q : r ≠ 41 := by omega
      simp [swapTagIndex, p, q]
    · simp [inside]
  unfold productTerm
  rw [real, if_congr flags rfl rfl]

private theorem swapTagSeeds (d e : Finset ℕ) (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows) :
    (markedSeeds d e).image swapTagWord = markedSeeds e d := by
  have first : swapTagWord (insert 40 d) = insert 41 d := by
    change (insert 40 d).image swapTagIndex = _
    rw [Finset.image_insert]
    change insert 41 (swapTagWord d) = _
    rw [swapTagWordReal d dRows]
  have second : swapTagWord (insert 41 e) = insert 40 e := by
    change (insert 41 e).image swapTagIndex = _
    rw [Finset.image_insert]
    change insert 40 (swapTagWord e) = _
    rw [swapTagWordReal e eRows]
  have bases : baseSets.image swapTagWord = baseSets := by
    ext s
    constructor
    · intro h
      obtain ⟨w, hw, rfl⟩ := Finset.mem_image.mp h
      obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp hw
      rw [swapTagWordReal _ (rootRowsBound u)]
      exact Finset.mem_image_of_mem _ (Finset.mem_univ _)
    · intro h
      obtain ⟨u, _, rfl⟩ := Finset.mem_image.mp h
      exact Finset.mem_image.mpr
        ⟨rootSet u, Finset.mem_image_of_mem _ (Finset.mem_univ _),
          swapTagWordReal _ (rootRowsBound u)⟩
  simp only [markedSeeds, Finset.image_insert, first, second, bases]
  ext s
  simp only [Finset.mem_insert]
  tauto

private theorem swapTagFamily (d e : Finset ℕ) (D : Finset (Finset ℕ))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) :
    let P := D.image swapTagWord
    (P \ markedSeeds e d).card = (D \ markedSeeds d e).card ∧
    Finset.image₂ productTerm P P = Finset.image₂ productTerm D D ∧
    (∀ w ∈ P, w ∉ markedSeeds e d →
      ∃ a ∈ P, ∃ b ∈ P, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) := by
  let P := D.image swapTagWord
  change (P \ markedSeeds e d).card = (D \ markedSeeds d e).card ∧ _ ∧ _
  have seedEq := swapTagSeeds d e dRows eRows
  have injective := swapTagWordInvolutive.injective
  have count : (P \ markedSeeds e d).card = (D \ markedSeeds d e).card := by
    have equality : P \ markedSeeds e d = (D \ markedSeeds d e).image swapTagWord := by
      ext w
      rw [← seedEq]
      constructor
      · intro h
        obtain ⟨fromD, notSeed⟩ := Finset.mem_sdiff.mp h
        obtain ⟨v, vD, rfl⟩ := Finset.mem_image.mp fromD
        exact Finset.mem_image.mpr ⟨v, Finset.mem_sdiff.mpr ⟨vD,
          fun seed => notSeed (Finset.mem_image_of_mem _ seed)⟩, rfl⟩
      · intro h
        obtain ⟨v, vD, rfl⟩ := Finset.mem_image.mp h
        obtain ⟨old, notSeed⟩ := Finset.mem_sdiff.mp vD
        refine Finset.mem_sdiff.mpr ⟨Finset.mem_image_of_mem _ old, ?_⟩
        intro becomesSeed
        obtain ⟨s, hs, eq⟩ := Finset.mem_image.mp becomesSeed
        exact notSeed (injective eq ▸ hs)
    rw [equality, Finset.card_image_of_injective _ injective]
  refine ⟨count, ?_, ?_⟩
  · ext t
    constructor
    · intro h
      obtain ⟨a, aP, b, bP, rfl⟩ := Finset.mem_image₂.mp h
      obtain ⟨x, hx, rfl⟩ := Finset.mem_image.mp aP
      obtain ⟨y, hy, rfl⟩ := Finset.mem_image.mp bP
      rw [swapTagProduct]
      exact Finset.mem_image₂.mpr ⟨x, hx, y, hy, rfl⟩
    · intro h
      obtain ⟨x, hx, y, hy, rfl⟩ := Finset.mem_image₂.mp h
      exact Finset.mem_image₂.mpr ⟨swapTagWord x, Finset.mem_image_of_mem _ hx,
        swapTagWord y, Finset.mem_image_of_mem _ hy, swapTagProduct x y⟩
  · intro w wP paid
    obtain ⟨s, sD, rfl⟩ := Finset.mem_image.mp wP
    have sourcePaid : s ∉ markedSeeds d e :=
      fun h => paid (seedEq ▸ Finset.mem_image_of_mem _ h)
    obtain ⟨a, aD, b, bD, aSub, bSub, h⟩ := build s sD sourcePaid
    have inset (q : Finset ℕ) (hq : q ⊂ s) : swapTagWord q ⊂ swapTagWord s := by
      refine Finset.ssubset_iff_subset_ne.mpr ⟨Finset.image_subset_image hq.1,
        fun collision => (Finset.ssubset_iff_subset_ne.mp hq).2 (injective collision)⟩
    exact ⟨swapTagWord a, Finset.mem_image_of_mem _ aD, swapTagWord b,
      Finset.mem_image_of_mem _ bD, inset a aSub, inset b bSub,
      (congrArg swapTagWord h).trans (Finset.image_union _ _)⟩

end PEqualNP.Outside.L_meta_9427
