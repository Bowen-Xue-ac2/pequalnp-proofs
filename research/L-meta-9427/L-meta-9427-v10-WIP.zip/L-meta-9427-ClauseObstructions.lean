import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def obstructionCertificates : List (ℕ × ℕ) :=
  [(21,98319), (74,2633745), (84,63), (146,1574149), (152,21765), (386,1593858),
   (1046,2621455), (1089,176196), (1156,23564), (4101,99120), (4291,1212689),
   (4292,819), (4304,1365), (4368,26208), (5122,2647104)]

def obstructionRows (code : ℕ × ℕ) : Finset (Fin 24) :=
  Finset.univ.filter fun i => code.2.testBit i.val

def relevantEdge (i : Fin 10) : Fin 16 :=
  ([0,1,2,3,4,6,7,8,10,12] : List (Fin 16))[i.val]?.getD 0

set_option maxRecDepth 12000 in
set_option maxHeartbeats 10000000 in
private theorem obstructionCliques :
    ∀ c ∈ obstructionCertificates, (obstructionRows c).card = 6 ∧
      ∀ i ∈ obstructionRows c, ∀ j ∈ obstructionRows c, i ≠ j →
        ∃ r : Fin 16, c.1.testBit r.val = true ∧
          ∀ u : Fin 11, r.val ∈ rootSet u →
            i.val + 16 ∈ rootSet u ∨ j.val + 16 ∈ rootSet u := by
  decide +kernel

set_option maxRecDepth 12000 in
set_option maxHeartbeats 10000000 in
private theorem obstructionCodes :
    ∀ bits : Fin 1024, ∃ c ∈ obstructionCertificates,
      (∀ i : Fin 10, c.1.testBit (relevantEdge i).val = true → bits.val.testBit i.val = true) ∨
      (∀ i : Fin 10, c.1.testBit (relevantEdge i).val = true → bits.val.testBit i.val = false) := by
  decide +kernel

private theorem obstructionPositions :
    ∀ c ∈ obstructionCertificates, ∀ r : Fin 16, c.1.testBit r.val = true →
      ∃ i : Fin 10, relevantEdge i = r := by
  decide +kernel

private theorem obstructionInOneColor (color : Fin 16 → Bool) :
    ∃ c ∈ obstructionCertificates,
      (∀ r : Fin 16, c.1.testBit r.val = true → color r = true) ∨
      (∀ r : Fin 16, c.1.testBit r.val = true → color r = false) := by
  let bits (i : Fin 10) := color (relevantEdge i)
  let code : Fin 1024 := ⟨Nat.ofBits bits, Nat.ofBits_lt_two_pow bits⟩
  obtain ⟨c, hc, monochrome⟩ := obstructionCodes code
  have get (value : Bool)
      (selected : ∀ i : Fin 10, c.1.testBit (relevantEdge i).val = true →
        code.val.testBit i.val = value) (r : Fin 16) (hr : c.1.testBit r.val = true) :
      color r = value := by
    obtain ⟨i, eq⟩ := obstructionPositions c hc r hr
    have h := selected i (by simpa only [eq] using hr)
    change (Nat.ofBits bits).testBit i.val = value at h
    rw [Nat.testBit_ofBits_lt bits i i.isLt] at h
    simpa only [bits, eq] using h
  exact ⟨c, hc, monochrome.elim (fun left => Or.inl (get true left))
    (fun right => Or.inr (get false right))⟩

private theorem obstructionNeedsSix (c : ℕ × ℕ) (hc : c ∈ obstructionCertificates)
    (t : Finset ℕ) (C : List (Finset (Fin 11)))
    (clean : ∀ r ∈ actualRows, r ∈ t → r ∈ edgeRows)
    (formula : ∀ r ∈ actualRows, r ∈ t ↔ ∀ a ∈ C, r ∈ rowsOf a)
    (includes : ∀ r : Fin 16, c.1.testBit r.val = true → r.val ∈ t) : 6 ≤ C.length := by
  classical
  let X := obstructionRows c
  obtain ⟨six, incompatible⟩ := obstructionCliques c hc
  have actual (i : Fin 24) : i.val + 16 ∈ actualRows :=
    Finset.mem_range.mpr (by have := i.isLt; omega)
  have clause (i : Fin 24) : ∃ a ∈ C, i.val + 16 ∉ rowsOf a := by
    by_contra noClause
    have all : ∀ a ∈ C, i.val + 16 ∈ rowsOf a :=
      fun a ha => Classical.byContradiction fun hn => noClause ⟨a, ha, hn⟩
    have ht := (formula _ (actual i)).mpr all
    have tooSmall := Finset.mem_range.mp (clean _ (actual i) ht)
    omega
  let select (i : Fin 24) : Finset (Fin 11) := (clause i).choose
  have selected (i : Fin 24) : select i ∈ C ∧ i.val + 16 ∉ rowsOf (select i) :=
    (clause i).choose_spec
  have injective : Set.InjOn select (X : Set (Fin 24)) := by
    intro i hi j hj same
    by_contra unequal
    obtain ⟨r, hr, because⟩ := incompatible i hi j hj unequal
    have ar : r.val ∈ actualRows := Finset.mem_range.mpr (r.isLt.trans (by decide : 16 < 40))
    have included := (formula r ar).mp (includes r hr) (select i) (selected i).1
    obtain ⟨u, hu, uRow⟩ := Finset.mem_biUnion.mp included
    rcases because u uRow with iRow | jRow
    · exact (selected i).2 (Finset.mem_biUnion.mpr ⟨u, hu, iRow⟩)
    · exact (selected j).2 (Finset.mem_biUnion.mpr ⟨u, same ▸ hu, jRow⟩)
  have contained : X.image select ⊆ C.toFinset := by
    intro a ha
    obtain ⟨i, _, rfl⟩ := Finset.mem_image.mp ha
    exact List.mem_toFinset.mpr (selected i).1
  calc
    6 = X.card := six.symm
    _ = (X.image select).card := (Finset.card_image_of_injOn injective).symm
    _ ≤ C.toFinset.card := Finset.card_le_card contained
    _ ≤ C.length := List.toFinset_card_le C

private theorem twoClauseTermsCannotCover
    (a b : Finset ℕ) (A B : List (Finset (Fin 11)))
    (smallA : A.length ≤ 5) (smallB : B.length ≤ 5)
    (cleanA : ∀ r ∈ actualRows, r ∈ a → r ∈ edgeRows)
    (cleanB : ∀ r ∈ actualRows, r ∈ b → r ∈ edgeRows)
    (formulaA : ∀ r ∈ actualRows, r ∈ a ↔ ∀ c ∈ A, r ∈ rowsOf c)
    (formulaB : ∀ r ∈ actualRows, r ∈ b ↔ ∀ c ∈ B, r ∈ rowsOf c)
    (covers : edgeRows ⊆ a ∪ b) : False := by
  obtain ⟨c, hc, first | second⟩ := obstructionInOneColor (fun r => decide (r.val ∈ a))
  · have includes : ∀ r : Fin 16, c.1.testBit r.val = true → r.val ∈ a :=
      fun r hr => of_decide_eq_true (first r hr)
    have six := obstructionNeedsSix c hc a A cleanA formulaA includes
    omega
  · have includes (r : Fin 16) (hr : c.1.testBit r.val = true) : r.val ∈ b := by
      have absent : r.val ∉ a := of_decide_eq_false (second r hr)
      exact (Finset.mem_union.mp (covers (Finset.mem_range.mpr r.isLt))).resolve_left absent
    have six := obstructionNeedsSix c hc b B cleanB formulaB includes
    omega

private theorem threeCoverTermsNeeded (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dProducers : ∃ u ∈ D, ∃ v ∈ D, u ⊆ actualRows ∧ v ⊆ actualRows ∧ d = u ∩ v)
    (eProducers : ∃ u ∈ D, ∃ v ∈ D, u ⊆ actualRows ∧ v ⊆ actualRows ∧ e = u ∩ v)
    (dDirty : ¬d ⊆ edgeRows) (eDirty : ¬e ⊆ edgeRows)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) : 3 ≤ B.card := by
  classical
  by_contra! onlyTwo
  have full : edgeRows ⊆ B.biUnion id := by rw [cover]; exact Finset.subset_insert _ _
  have atLeastOne : 40 ∈ B.biUnion id := by rw [cover]; exact Finset.mem_insert_self _ _
  obtain ⟨a, ha, _⟩ := Finset.mem_biUnion.mp atLeastOne
  have n : (B.erase a).card ≤ 1 := by
    rw [Finset.card_erase_of_mem ha]
    omega
  have testOption (b : Finset ℕ) (hb : b ∈ B)
      (options : ∀ t ∈ B, t = a ∨ t = b) : False := by
    have formulas := cleanTermClauses d e D B dProducers eProducers dDirty eDirty build pairs
    obtain ⟨A, smallA, formA⟩ := formulas a ha
    obtain ⟨C, smallC, formB⟩ := formulas b hb
    have clean (t : Finset ℕ) (ht : t ∈ B) : ∀ r ∈ actualRows, r ∈ t → r ∈ edgeRows := by
      obtain ⟨_, _, _, _, _, subset⟩ := pairs t ht
      intro r ar rt
      rcases Finset.mem_insert.mp (subset rt) with eq | row
      · exact ((show 40 ∉ actualRows by decide) (eq ▸ ar)).elim
      · exact row
    apply twoClauseTermsCannotCover a b A C smallA smallC (clean a ha) (clean b hb) formA formB
    intro r hr
    obtain ⟨t, ht, row⟩ := Finset.mem_biUnion.mp (full hr)
    rcases options t ht with rfl | rfl
    · exact Finset.mem_union.mpr (Or.inl row)
    · exact Finset.mem_union.mpr (Or.inr row)
  by_cases more : (B.erase a).Nonempty
  · obtain ⟨b, hb⟩ := more
    apply testOption b (Finset.mem_of_mem_erase hb)
    intro t ht
    by_cases eq : t = a
    · exact Or.inl eq
    · exact Or.inr (Finset.card_le_one.mp n t (Finset.mem_erase.mpr ⟨eq, ht⟩) b hb)
  · apply testOption a ha
    intro t ht
    exact Or.inl (Classical.byContradiction
      fun ne => more ⟨t, Finset.mem_erase.mpr ⟨ne, ht⟩⟩)

end PEqualNP.Outside.L_meta_9427
