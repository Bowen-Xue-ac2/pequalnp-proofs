import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem pureCostWithMissing
    (D : Finset (Finset (Fin 11))) (H : Finset (Fin 11 × Finset (Fin 11)))
    (missing : Finset (Fin 11 × Fin 11)) (missingSub : missing ⊆ orientedEdges)
    (build : ∀ w ∈ D, 1 < w.card →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (heads : ∀ h ∈ H, h.2 ∈ D ∧ h.2 ⊆ neighbors h.1)
    (covers : ∀ e ∈ orientedEdges, e ∈ missing ∨ ∃ h ∈ H,
      (e.1 = h.1 ∧ e.2 ∈ h.2) ∨ (e.2 = h.1 ∧ e.1 ∈ h.2)) :
    23 ≤ (D.filter fun s => 1 < s.card).card + 2 * H.card + 2 * missing.card := by
  let singletonHead (e : Fin 11 × Fin 11) : Fin 11 × Finset (Fin 11) := (e.1, {e.2})
  let extra := missing.image singletonHead
  let D' := D ∪ extra.image Prod.snd
  let H' := H ∪ extra
  have inOld (s : Finset (Fin 11)) (hs : s ∈ D') (big : 1 < s.card) : s ∈ D := by
    rcases Finset.mem_union.mp hs with old | added
    · exact old
    · obtain ⟨h, hh, rfl⟩ := Finset.mem_image.mp added
      obtain ⟨e, he, rfl⟩ := Finset.mem_image.mp hh
      simp [singletonHead] at big
  have largeSets : D'.filter (fun s => 1 < s.card) = D.filter (fun s => 1 < s.card) := by
    apply Finset.Subset.antisymm
    · intro s hs
      obtain ⟨hD, hLarge⟩ := Finset.mem_filter.mp hs
      exact Finset.mem_filter.mpr ⟨inOld s hD hLarge, hLarge⟩
    · intro s hs
      obtain ⟨hD, hLarge⟩ := Finset.mem_filter.mp hs
      exact Finset.mem_filter.mpr ⟨Finset.mem_union.mpr (Or.inl hD), hLarge⟩
  have build' : ∀ w ∈ D', 1 < w.card →
      ∃ a ∈ D', ∃ b ∈ D', a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b := by
    intro w hw big
    obtain ⟨a, ha, b, hb, haSub, hbSub, eq⟩ := build w (inOld w hw big) big
    exact ⟨a, Finset.mem_union.mpr (Or.inl ha), b, Finset.mem_union.mpr (Or.inl hb),
      haSub, hbSub, eq⟩
  have heads' : ∀ h ∈ H', h.2 ∈ D' ∧ h.2 ⊆ neighbors h.1 := by
    intro h hh
    rcases Finset.mem_union.mp hh with old | added
    · exact ⟨Finset.mem_union.mpr (Or.inl (heads h old).1), (heads h old).2⟩
    · refine ⟨Finset.mem_union.mpr (Or.inr (Finset.mem_image_of_mem _ added)), ?_⟩
      obtain ⟨e, he, rfl⟩ := Finset.mem_image.mp added
      intro v hv
      have eq : v = e.2 := Finset.mem_singleton.mp hv
      subst v
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (Finset.mem_filter.mp (missingSub he)).2.2⟩
  have covers' : ∀ e ∈ orientedEdges, ∃ h ∈ H',
      (e.1 = h.1 ∧ e.2 ∈ h.2) ∨ (e.2 = h.1 ∧ e.1 ∈ h.2) := by
    intro e he
    rcases covers e he with gap | ⟨h, hh, cap⟩
    · exact ⟨singletonHead e,
        Finset.mem_union.mpr (Or.inr (Finset.mem_image_of_mem _ gap)),
        Or.inl ⟨rfl, Finset.mem_singleton_self _⟩⟩
    · exact ⟨h, Finset.mem_union.mpr (Or.inl hh), cap⟩
  have full := pureCost D' H' build' heads' covers'
  rw [largeSets] at full
  have count : H'.card ≤ H.card + missing.card := calc
    _ ≤ H.card + extra.card := Finset.card_union_le _ _
    _ ≤ H.card + missing.card := Nat.add_le_add_left Finset.card_image_le _
  omega

end PEqualNP.Outside.L_meta_9427
