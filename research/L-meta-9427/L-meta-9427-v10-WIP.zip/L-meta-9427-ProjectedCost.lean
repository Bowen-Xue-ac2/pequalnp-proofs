import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem projectedHead (a b t : Finset ℕ) (A B : Finset (Fin 11))
    (aLe : rowsOf A ⊆ a) (bLe : rowsOf B ⊆ b)
    (aRows : rowsOf A ∩ edgeRows = a ∩ edgeRows)
    (bRows : rowsOf B ∩ edgeRows = b ∩ edgeRows)
    (clean : a ∩ b ∩ actualRows ⊆ edgeRows)
    (term : t ∩ edgeRows = a ∩ b ∩ edgeRows)
    (nonempty : (t ∩ edgeRows).Nonempty) :
    ∃ h : Fin 11 × Finset (Fin 11), (h.2 = A ∨ h.2 = B) ∧
      h.2 ⊆ neighbors h.1 ∧ ∀ r : Fin 16, r.val ∈ t →
        ((edgeAt r).1 = h.1 ∧ (edgeAt r).2 ∈ h.2) ∨
        ((edgeAt r).2 = h.1 ∧ (edgeAt r).1 ∈ h.2) := by
  have compat : ∀ u ∈ A, ∀ v ∈ B, edge u v := by
    intro u hu v hv
    apply (rootSetPair u v).mp
    intro i hi
    obtain ⟨iu, iv⟩ := Finset.mem_inter.mp hi
    have inA := aLe (Finset.mem_biUnion.mpr ⟨u, hu, iu⟩)
    have inB := bLe (Finset.mem_biUnion.mpr ⟨v, hv, iv⟩)
    exact clean (Finset.mem_inter.mpr
      ⟨Finset.mem_inter.mpr ⟨inA, inB⟩, rootRowsBound u iu⟩)
  have trace (r : Fin 16) (hr : r.val ∈ t) :
      ∃ u ∈ A, ∃ v ∈ B,
        (u = (edgeAt r).1 ∧ v = (edgeAt r).2) ∨
        (u = (edgeAt r).2 ∧ v = (edgeAt r).1) := by
    have hp : r.val ∈ edgeRows := Finset.mem_range.mpr r.isLt
    have ht : r.val ∈ t ∩ edgeRows := Finset.mem_inter.mpr ⟨hr, hp⟩
    rw [term] at ht
    obtain ⟨ha, hb⟩ := Finset.mem_inter.mp (Finset.mem_inter.mp ht).1
    have ra : r.val ∈ rowsOf A ∩ edgeRows := by
      rw [aRows]
      exact Finset.mem_inter.mpr ⟨ha, hp⟩
    have rb : r.val ∈ rowsOf B ∩ edgeRows := by
      rw [bRows]
      exact Finset.mem_inter.mpr ⟨hb, hp⟩
    obtain ⟨u, hu, ru⟩ := Finset.mem_biUnion.mp (Finset.mem_inter.mp ra).1
    obtain ⟨v, hv, rv⟩ := Finset.mem_biUnion.mp (Finset.mem_inter.mp rb).1
    have distinct := (compat u hu v hv).1
    refine ⟨u, hu, v, hv, ?_⟩
    rcases (edgeAtMembership r u).mp ru with u₁ | u₂ <;>
      rcases (edgeAtMembership r v).mp rv with v₁ | v₂
    · exact (distinct (u₁.trans v₁.symm)).elim
    · exact Or.inl ⟨u₁, v₂⟩
    · exact Or.inr ⟨u₂, v₁⟩
    · exact (distinct (u₂.trans v₂.symm)).elim
  obtain ⟨i, hi⟩ := nonempty
  have ri : i < 16 := Finset.mem_range.mp (Finset.mem_inter.mp hi).2
  obtain ⟨u₀, uIn, v₀, vIn, _⟩ := trace ⟨i, ri⟩ (Finset.mem_inter.mp hi).1
  rcases purePairStar A B compat with small | small
  · have single := Finset.card_eq_one.mp
      (Nat.le_antisymm small (Finset.card_pos.mpr ⟨u₀, uIn⟩))
    obtain ⟨u, eq⟩ := single
    refine ⟨(u, B), Or.inr rfl, ?_, ?_⟩
    · intro v hv
      have hu : u ∈ A := by simp [eq]
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, compat u hu v hv⟩
    · intro r hr
      obtain ⟨u', hu, v, hv, order⟩ := trace r hr
      have same : u' = u := by simpa only [eq, Finset.mem_singleton] using hu
      rcases order with ⟨hu', hv'⟩ | ⟨hu', hv'⟩
      · exact Or.inl ⟨hu'.symm.trans same, hv' ▸ hv⟩
      · exact Or.inr ⟨hu'.symm.trans same, hv' ▸ hv⟩
  · have single := Finset.card_eq_one.mp
      (Nat.le_antisymm small (Finset.card_pos.mpr ⟨v₀, vIn⟩))
    obtain ⟨v, eq⟩ := single
    refine ⟨(v, A), Or.inl rfl, ?_, ?_⟩
    · intro u hu
      have hv : v ∈ B := by simp [eq]
      exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, (edgeSwap u v).mp (compat u hu v hv)⟩
    · intro r hr
      obtain ⟨u, hu, v', hv, order⟩ := trace r hr
      have same : v' = v := by simpa only [eq, Finset.mem_singleton] using hv
      rcases order with ⟨hu', hv'⟩ | ⟨hu', hv'⟩
      · exact Or.inr ⟨hv'.symm.trans same, hu' ▸ hu⟩
      · exact Or.inl ⟨hv'.symm.trans same, hu' ▸ hu⟩

private theorem projectedCost (D X B : Finset (Finset ℕ))
    (build : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (seeds : ∀ w ∈ D, w ∈ X → ∃ s : Finset (Fin 11),
      s.card ≤ 1 ∧ rowsOf s ⊆ w ∧ rowsOf s ∩ edgeRows = w ∩ edgeRows)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      a ∩ b ∩ actualRows ⊆ edgeRows ∧ t ∩ edgeRows = a ∩ b ∩ edgeRows)
    (cover : edgeRows ⊆ B.biUnion id) :
    23 ≤ (D \ X).card + 2 * B.card := by
  classical
  let seed (w : Finset ℕ) : Finset (Fin 11) :=
    if h : w ∈ D ∧ w ∈ X then (seeds w h.1 h.2).choose else ∅
  obtain ⟨label, fromSeed, fromBuild⟩ := labelUnionFamily D X seed build
  have roots (w : Finset ℕ) (hw : w ∈ D) (hx : w ∈ X) :
      (label w).card ≤ 1 ∧ rowsOf (label w) ⊆ w ∧
        rowsOf (label w) ∩ edgeRows = w ∩ edgeRows := by
    rw [fromSeed w hw hx]
    simpa [seed, hw, hx] using (seeds w hw hx).choose_spec
  have replay := replayProjection D X label (fun w hw hx => (roots w hw hx).2) fromBuild
  obtain ⟨cost, projectedBuild⟩ := projectedFamily D X label
    (fun w hw hx => (roots w hw hx).1) (fun w hw hx => by
      obtain ⟨a, ha, b, hb, haSub, hbSub, _, eq⟩ := fromBuild w hw hx
      exact ⟨a, ha, b, hb, haSub, hbSub, eq⟩)

  let terms := B.filter fun t => (t ∩ edgeRows).Nonempty
  have extract (t : Finset ℕ) (inTerm : t ∈ terms) :
      ∃ h : Fin 11 × Finset (Fin 11), h.2 ∈ D.image label ∧
        h.2 ⊆ neighbors h.1 ∧ ∀ r : Fin 16, r.val ∈ t →
          ((edgeAt r).1 = h.1 ∧ (edgeAt r).2 ∈ h.2) ∨
          ((edgeAt r).2 = h.1 ∧ (edgeAt r).1 ∈ h.2) := by
    obtain ⟨ht, hn⟩ := Finset.mem_filter.mp inTerm
    obtain ⟨a, ha, b, hb, clean, hr⟩ := pairs t ht
    have hA := replay a ha
    have hB := replay b hb
    obtain ⟨h, other, adj, edges⟩ :=
      projectedHead a b t (label a) (label b) hA.1 hB.1 hA.2 hB.2 clean hr hn
    refine ⟨h, ?_, adj, edges⟩
    rcases other with eq | eq
    · rw [eq]
      exact Finset.mem_image_of_mem _ ha
    · rw [eq]
      exact Finset.mem_image_of_mem _ hb
  let select (t : Finset ℕ) : Fin 11 × Finset (Fin 11) :=
    if h : t ∈ terms then (extract t h).choose else (0, ∅)
  have selected (t : Finset ℕ) (ht : t ∈ terms) :
      (select t).2 ∈ D.image label ∧ (select t).2 ⊆ neighbors (select t).1 ∧
        ∀ r : Fin 16, r.val ∈ t →
          ((edgeAt r).1 = (select t).1 ∧ (edgeAt r).2 ∈ (select t).2) ∨
          ((edgeAt r).2 = (select t).1 ∧ (edgeAt r).1 ∈ (select t).2) := by
    simpa [select, ht] using (extract t ht).choose_spec
  let H := terms.image select
  have heads : ∀ h ∈ H, h.2 ∈ D.image label ∧ h.2 ⊆ neighbors h.1 := by
    intro h hh
    obtain ⟨t, ht, rfl⟩ := Finset.mem_image.mp hh
    exact ⟨(selected t ht).1, (selected t ht).2.1⟩
  have covered : ∀ e ∈ orientedEdges, ∃ h ∈ H,
      (e.1 = h.1 ∧ e.2 ∈ h.2) ∨ (e.2 = h.1 ∧ e.1 ∈ h.2) := by
    intro e he
    obtain ⟨lt, adj⟩ := (Finset.mem_filter.mp he).2
    obtain ⟨r, eq⟩ := edgeAtIndexed e.1 e.2 lt adj
    have hr : r.val ∈ edgeRows := Finset.mem_range.mpr r.isLt
    obtain ⟨t, ht, inT⟩ := Finset.mem_biUnion.mp (cover hr)
    have hT : t ∈ terms := Finset.mem_filter.mpr
      ⟨ht, ⟨r.val, Finset.mem_inter.mpr ⟨inT, hr⟩⟩⟩
    refine ⟨select t, Finset.mem_image_of_mem _ hT, ?_⟩
    have found := (selected t hT).2.2 r inT
    rw [eq] at found
    exact found
  have pure := pureCost (D.image label) H projectedBuild heads covered
  have termCost : H.card ≤ B.card :=
    Finset.card_image_le.trans (Finset.card_le_card (Finset.filter_subset _ _))
  omega

end PEqualNP.Outside.L_meta_9427
