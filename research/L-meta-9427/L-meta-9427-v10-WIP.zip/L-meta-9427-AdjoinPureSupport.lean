import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem adjoinPureSupport {α : Type} [DecidableEq α]
    (F : Finset (Finset α)) (S : Finset α)
    (roots : ∀ u : α, ({u} : Finset α) ∈ F)
    (building : ∀ w ∈ F, 1 < w.card →
      ∃ a ∈ F, ∃ b ∈ F, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) :
    ∃ G : Finset (Finset α), F ⊆ G ∧ S ∈ G ∧
      (G.filter fun w => 1 < w.card).card ≤
        (F.filter fun w => 1 < w.card).card + (S.card - 1) ∧
      ∀ w ∈ G, 1 < w.card → ∃ a ∈ G, ∃ b ∈ G, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b := by
  induction S using Finset.induction_on with
  | empty =>
    let G := insert ∅ F
    have h : F ⊆ G := Finset.subset_insert _ _
    refine ⟨G, h, Finset.mem_insert_self _ _, ?_, ?_⟩
    · have eq : G.filter (fun w => 1 < w.card) = F.filter (fun w => 1 < w.card) := by
        ext w
        simp [G]
        intro large eq
        simp [eq] at large
      simp [eq]
    · intro w hw large
      obtain old := (Finset.mem_insert.mp hw).resolve_left (fun eq => by simp [eq] at large)
      obtain ⟨a, ha, b, hb, left, right, eq⟩ := building w old large
      exact ⟨a, h ha, b, h hb, left, right, eq⟩
  | @insert u U new ih =>
    by_cases nil : U = ∅
    · subst U
      refine ⟨F, Finset.Subset.rfl, ?_, ?_, building⟩
      · simpa using roots u
      · simp
    obtain ⟨P, includes, uP, count, constructions⟩ := ih
    let large := insert u U
    let G := insert large P
    have more : P ⊆ G := Finset.subset_insert _ _
    refine ⟨G, includes.trans more, Finset.mem_insert_self _ _, ?_, ?_⟩
    · have insideBig : G.filter (fun w => 1 < w.card) ⊆ insert large (P.filter fun w => 1 < w.card) := by
        intro w hw
        obtain ⟨inside, size⟩ := Finset.mem_filter.mp hw
        rcases Finset.mem_insert.mp inside with rfl | earlier
        · exact Finset.mem_insert_self _ _
        · exact Finset.mem_insert_of_mem (Finset.mem_filter.mpr ⟨earlier, size⟩)
      have graphCost := (Finset.card_le_card insideBig).trans (Finset.card_insert_le _ _)
      have alive : 0 < U.card := Finset.card_pos.mpr (Finset.nonempty_iff_ne_empty.mpr nil)
      rw [Finset.card_insert_of_notMem new]
      omega
    · intro w hw atLeast
      rcases Finset.mem_insert.mp hw with rfl | earlier
      · refine ⟨{u}, more (includes (roots u)), U, more uP, ?_, ?_, ?_⟩
        · refine Finset.ssubset_iff_subset_ne.mpr ⟨Finset.singleton_subset_iff.mpr
            (Finset.mem_insert_self _ _), ?_⟩
          intro eq
          obtain ⟨v, hv⟩ := Finset.nonempty_iff_ne_empty.mpr nil
          have atV : v ∈ ({u} : Finset α) := eq.symm ▸ Finset.mem_insert_of_mem hv
          exact new ((Finset.mem_singleton.mp atV) ▸ hv)
        · exact Finset.ssubset_iff_subset_ne.mpr ⟨Finset.subset_insert _ _, fun eq =>
            new (eq.symm ▸ Finset.mem_insert_self _ _)⟩
        · simp [large]
      · obtain ⟨a, ha, b, hb, left, right, eq⟩ := constructions w earlier atLeast
        exact ⟨a, more ha, b, more hb, left, right, eq⟩

end PEqualNP.Outside.L_meta_9427

