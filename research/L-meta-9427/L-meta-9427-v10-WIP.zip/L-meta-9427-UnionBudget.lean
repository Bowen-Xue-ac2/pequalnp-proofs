import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem unionBudget {α : Type} [DecidableEq α]
    (D H : Finset (Finset α)) (hH : H ⊆ D)
    (build : ∀ w ∈ D, 1 < w.card →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) :
    (H.biUnion id).card ≤ H.card + (D.filter fun w => 1 < w.card).card := by
  induction hD : D.card using Nat.strong_induction_on generalizing D H with
  | ind n ih =>
    by_cases hsmall : ∀ s ∈ D, s.card ≤ 1
    · have bound := Finset.card_biUnion_le_card_mul H id 1
        (fun s hs => hsmall s (hH hs))
      simp only [Nat.mul_one] at bound
      omega
    · push_neg at hsmall
      obtain ⟨v, hv, hvbig⟩ := hsmall
      obtain ⟨w, hw, hwmax⟩ := Finset.exists_max_image D Finset.card ⟨v, hv⟩
      have hwbig : 1 < w.card := lt_of_lt_of_le hvbig (hwmax v hv)
      let E := D.erase w
      have hwpos : 0 < D.card := Finset.card_pos.mpr ⟨w, hw⟩
      have hEn : E.card < n := by
        dsimp only [E]
        rw [Finset.card_erase_of_mem hw]
        omega
      have eraseBuild : ∀ q ∈ E, 1 < q.card →
          ∃ a ∈ E, ∃ b ∈ E, a ⊂ q ∧ b ⊂ q ∧ q = a ∪ b := by
        intro q hq hbq
        have hqD := (Finset.mem_erase.mp hq).2
        obtain ⟨a, ha, b, hb, hsa, hsb, eq⟩ := build q hqD hbq
        have hqa : a ≠ w := by
          intro h
          have hc := Finset.card_lt_card hsa
          rw [h] at hc
          exact (Nat.not_lt_of_ge (hwmax q hqD)) hc
        have hqb : b ≠ w := by
          intro h
          have hc := Finset.card_lt_card hsb
          rw [h] at hc
          exact (Nat.not_lt_of_ge (hwmax q hqD)) hc
        exact ⟨a, Finset.mem_erase.mpr ⟨hqa, ha⟩, b, Finset.mem_erase.mpr ⟨hqb, hb⟩,
          hsa, hsb, eq⟩
      have hwFiltered : w ∈ D.filter (fun q => 1 < q.card) :=
        Finset.mem_filter.mpr ⟨hw, hwbig⟩
      have eraseCost : (E.filter fun q => 1 < q.card).card + 1 =
          (D.filter fun q => 1 < q.card).card := by
        dsimp only [E]
        rw [Finset.filter_erase, Finset.card_erase_of_mem hwFiltered]
        have positive := Finset.card_pos.mpr ⟨w, hwFiltered⟩
        omega
      by_cases hwH : w ∈ H
      · obtain ⟨a, ha, b, hb, hsa, hsb, eq⟩ := build w hw hwbig
        let J := insert a (insert b (H.erase w))
        have hJE : J ⊆ E := by
          intro q hq
          simp only [J, Finset.mem_insert] at hq
          rcases hq with rfl | rfl | hq
          · exact Finset.mem_erase.mpr ⟨ne_of_lt hsa, ha⟩
          · exact Finset.mem_erase.mpr ⟨ne_of_lt hsb, hb⟩
          · exact Finset.mem_erase.mpr
              ⟨(Finset.mem_erase.mp hq).1, hH (Finset.mem_erase.mp hq).2⟩
        have hUnion : J.biUnion id = H.biUnion id := by
          ext x
          simp only [Finset.mem_biUnion, id_eq]
          constructor
          · rintro ⟨s, hs, hx⟩
            simp only [J, Finset.mem_insert] at hs
            rcases hs with rfl | rfl | hs
            · exact ⟨w, hwH, hsa.1 hx⟩
            · exact ⟨w, hwH, hsb.1 hx⟩
            · exact ⟨s, (Finset.mem_erase.mp hs).2, hx⟩
          · rintro ⟨s, hs, hx⟩
            by_cases e : s = w
            · subst s
              rw [eq] at hx
              rcases Finset.mem_union.mp hx with ha' | hb'
              · exact ⟨a, Finset.mem_insert_self _ _, ha'⟩
              · exact ⟨b, Finset.mem_insert_of_mem (Finset.mem_insert_self _ _), hb'⟩
            · exact ⟨s, Finset.mem_insert_of_mem (Finset.mem_insert_of_mem
                (Finset.mem_erase.mpr ⟨e, hs⟩)), hx⟩
        have hJ : J.card ≤ H.card + 1 := by
          have h1 := Finset.card_insert_le a (insert b (H.erase w))
          have h2 := Finset.card_insert_le b (H.erase w)
          have h3 := Finset.card_erase_of_mem hwH
          have hp := Finset.card_pos.mpr ⟨w, hwH⟩
          change J.card ≤ (insert b (H.erase w)).card + 1 at h1
          omega
        have h := ih E.card hEn E J hJE eraseBuild rfl
        rw [hUnion] at h
        omega
      · have hHE : H ⊆ E := by
          intro q hq
          exact Finset.mem_erase.mpr ⟨fun eq => hwH (eq ▸ hq), hH hq⟩
        have h := ih E.card hEn E H hHE eraseBuild rfl
        omega

end PEqualNP.Outside.L_meta_9427
