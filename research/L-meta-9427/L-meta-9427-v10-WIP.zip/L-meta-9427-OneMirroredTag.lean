import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private def vertexSlot (u : Fin 11) : Fin 13 := ⟨u.val, u.isLt.trans (by decide)⟩

private def ordinarySlots (s : Finset (Fin 13)) : Finset (Fin 11) :=
  Finset.univ.filter fun u => vertexSlot u ∈ s

private theorem pureSlotRows (d e : Finset ℕ) (s : Finset (Fin 13))
    (noFirst : (11 : Fin 13) ∉ s) (noSecond : (12 : Fin 13) ∉ s) :
    rowsOf (ordinarySlots s) = supportRows d e s := by
  ext r
  constructor
  · intro hr
    obtain ⟨v, vid, rows⟩ := Finset.mem_biUnion.mp hr
    exact Finset.mem_biUnion.mpr ⟨vertexSlot v, (Finset.mem_filter.mp vid).2,
      by simpa [sourceWord, vertexSlot, v.isLt] using rows⟩
  · intro hr
    obtain ⟨i, hi, rows⟩ := Finset.mem_biUnion.mp hr
    by_cases old : i.val < 11
    · let u : Fin 11 := ⟨i.val, old⟩
      have same : vertexSlot u = i := Fin.ext rfl
      exact Finset.mem_biUnion.mpr ⟨u, Finset.mem_filter.mpr ⟨Finset.mem_univ _, same.symm ▸ hi⟩,
        by simpa [sourceWord, old, u] using rows⟩
    · by_cases first : i.val = 11
      · exact (noFirst ((show i = (11 : Fin 13) from Fin.ext first) ▸ hi)).elim
      · have last : i.val = 12 := by have := i.isLt; omega
        exact (noSecond ((show i = (12 : Fin 13) from Fin.ext last) ▸ hi)).elim

private theorem restrictMarkedToActual (z : Finset ℕ) (a : ℕ)
    (inside : z ⊆ actualRows) (outside : a ∉ actualRows) :
    insert a z ∩ actualRows = z := by
  ext r
  simp only [Finset.mem_inter, Finset.mem_insert]
  exact ⟨fun ⟨h, rows⟩ => h.elim (fun eq => (outside (eq ▸ rows)).elim) id,
    fun h => ⟨Or.inr h, inside h⟩⟩

set_option maxHeartbeats 1800000 in
private theorem costWithOneCopiedTagAndAtMostOneOtherRow (d e : Finset ℕ)
    (D B : Finset (Finset ℕ)) (dD : d ∈ D)
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (few : (e ∩ edgeRows).card ≤ 1)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  obtain ⟨label, value, one, _, joins⟩ := labelByThirteenSources d e D build
  have flags (w : Finset ℕ) (wD : w ∈ D) :
      (40 ∈ w ↔ (11 : Fin 13) ∈ label w) ∧ (41 ∈ w ↔ (12 : Fin 13) ∈ label w) := by
    have exactFlags := supportRowsFlags d e dRows eRows (label w)
    rw [value w wD] at exactFlags
    exact exactFlags
  have ordinary (w : Finset ℕ) (wD : w ∈ D) (plain : w ⊆ actualRows) :
      (11 : Fin 13) ∉ label w ∧ (12 : Fin 13) ∉ label w :=
    (untaggedSupportRows d e dRows eRows _).mp ((value w wD).symm ▸ plain)
  let dSupport := ordinarySlots (label d)
  have dMatch : rowsOf dSupport = d :=
    (pureSlotRows d e _ (ordinary d dD dRows).1 (ordinary d dD dRows).2).trans (value d dD)
  let sourceView (i : Fin 13) : Finset (Fin 11) :=
    if old : i.val < 11 then {⟨i.val, old⟩} else if i = 11 then dSupport else ∅
  let view (w : Finset ℕ) := (label w).biUnion sourceView
  have plainView (w : Finset ℕ) (wD : w ∈ D) (plain : w ⊆ actualRows) :
      view w = ordinarySlots (label w) := by
    ext r
    constructor
    · intro hr
      obtain ⟨i, hi, located⟩ := Finset.mem_biUnion.mp hr
      by_cases old : i.val < 11
      · have same : r = (⟨i.val, old⟩ : Fin 11) := by simpa [sourceView, old] using located
        have index : vertexSlot r = i := by
          apply Fin.ext
          exact congrArg (fun u : Fin 11 => u.val) same
        exact Finset.mem_filter.mpr ⟨Finset.mem_univ _, index.symm ▸ hi⟩
      · have diff : i ≠ 11 := fun h => (ordinary w wD plain).1 (h ▸ hi)
        simp [sourceView, old, diff] at located
    · intro hr
      have picked := (Finset.mem_filter.mp hr).2
      exact Finset.mem_biUnion.mpr ⟨vertexSlot r, picked, by simp [sourceView, vertexSlot, r.isLt]⟩
  have fromSource (i : Fin 13) :
      sourceWord d e i ∩ actualRows =
        rowsOf (sourceView i) ∪ (if i = 12 then e else ∅) := by
    by_cases old : i.val < 11
    · have diff : i ≠ 12 := fun h => by
        rw [h] at old
        exact (by decide : ¬ (12 : Fin 13).val < 11) old
      simp [sourceWord, sourceView, old, diff, rowsOf,
        Finset.inter_eq_left.mpr (rootRowsBound ⟨i.val, old⟩)]
    by_cases first : i.val = 11
    · have same : i = (11 : Fin 13) := Fin.ext first
      subst i
      simp [sourceWord, sourceView, dMatch,
        restrictMarkedToActual d 40 dRows (by decide)]
    · have last : i.val = 12 := by have := i.isLt; omega
      have same : i = (12 : Fin 13) := Fin.ext last
      subst i
      simp [sourceWord, sourceView, rowsOf, restrictMarkedToActual e 41 eRows (by decide)]
  have region (w : Finset ℕ) (wD : w ∈ D) (r : ℕ) :
      r ∈ w ∩ actualRows ↔ r ∈ rowsOf (view w) ∨ (12 : Fin 13) ∈ label w ∧ r ∈ e := by
    constructor
    · intro seen
      obtain ⟨inW, inside⟩ := Finset.mem_inter.mp seen
      rw [← value w wD] at inW
      obtain ⟨i, hi, contains⟩ := Finset.mem_biUnion.mp inW
      have hit : r ∈ sourceWord d e i ∩ actualRows := Finset.mem_inter.mpr ⟨contains, inside⟩
      rw [fromSource] at hit
      rcases Finset.mem_union.mp hit with kept | last
      · obtain ⟨u, hu, row⟩ := Finset.mem_biUnion.mp kept
        exact Or.inl (Finset.mem_biUnion.mpr ⟨u, Finset.mem_biUnion.mpr ⟨i, hi, hu⟩, row⟩)
      · by_cases which : i = 12
        · exact Or.inr ⟨which ▸ hi, by simpa [which] using last⟩
        · simp [which] at last
    · intro seen
      have useSource (i : Fin 13) (hi : i ∈ label w)
          (row : r ∈ rowsOf (sourceView i) ∪ (if i = 12 then e else ∅)) :
          r ∈ w ∩ actualRows := by
        rw [← fromSource] at row
        obtain ⟨atI, actual⟩ := Finset.mem_inter.mp row
        exact Finset.mem_inter.mpr
          ⟨value w wD ▸ Finset.mem_biUnion.mpr ⟨i, hi, atI⟩, actual⟩
      rcases seen with kept | ⟨slot, last⟩
      · obtain ⟨u, marked, row⟩ := Finset.mem_biUnion.mp kept
        obtain ⟨i, hi, hu⟩ := Finset.mem_biUnion.mp marked
        exact useSource i hi (Finset.mem_union_left _ (Finset.mem_biUnion.mpr ⟨u, hu, row⟩))
      · exact useSource 12 slot (Finset.mem_union_right _ (by simpa using last))
  have freeView (w : Finset ℕ) (wD : w ∈ D) (seed : w ∈ markedSeeds d e) :
      (view w).card ≤ 1 ∨ ∃ q ∈ D, q ⊂ w ∧ view q = view w := by
    obtain ⟨i, single⟩ := Finset.card_eq_one.mp ((one w wD).mpr seed)
    have labelView : view w = sourceView i := by simp [view, single]
    simp only [markedSeeds, Finset.mem_insert] at seed
    rcases seed with first | second | ordinarySeed
    · have flag : (11 : Fin 13) ∈ label w :=
        (flags w wD).1.mp (first.symm ▸ Finset.mem_insert_self _ _)
      have index : (11 : Fin 13) = i := by simpa [single] using flag
      refine Or.inr ⟨d, dD, ?_, ?_⟩
      · rw [first]
        exact Finset.ssubset_iff_subset_ne.mpr ⟨Finset.subset_insert _ _, fun h =>
          (show 40 ∉ actualRows by decide) (dRows (h.symm ▸ Finset.mem_insert_self _ _))⟩
      · rw [plainView d dD dRows, labelView, ← index]
        simp [sourceView, dSupport]
    · have flag : (12 : Fin 13) ∈ label w :=
        (flags w wD).2.mp (second.symm ▸ Finset.mem_insert_self _ _)
      have index : (12 : Fin 13) = i := by simpa [single] using flag
      exact Or.inl (by simp [labelView, ← index, sourceView])
    · have plain : w ⊆ actualRows := by
        obtain ⟨v, _, rfl⟩ := Finset.mem_image.mp ordinarySeed
        exact rootRowsBound v
      have sourceHere : i ∈ label w := by simp [single]
      have notMark : i ≠ 11 := fun same => (ordinary w wD plain).1 (same ▸ sourceHere)
      exact Or.inl (by rw [labelView]; by_cases old : i.val < 11 <;> simp [sourceView, old, notMark])
  have projectedUnion (w : Finset ℕ) (wD : w ∈ D) (paid : w ∉ markedSeeds d e) :
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ view w = view a ∪ view b := by
    obtain ⟨a, aD, b, bD, aa, bb, _, _, eq⟩ := joins w wD paid
    exact ⟨a, aD, b, bD, aa, bb, by simp only [view, eq, Finset.union_biUnion]⟩
  obtain ⟨paid, builds⟩ := projectionWithSmallerSeedCopies D (markedSeeds d e) view freeView projectedUnion
  let erased := (Finset.univ : Finset (Fin 16)).filter fun r => r.val ∈ e
  let missing := erased.image edgeAt
  have missingBound : missing ⊆ orientedEdges := by
    intro edge he
    obtain ⟨r, _, rfl⟩ := Finset.mem_image.mp he
    exact (show ∀ r : Fin 16, edgeAt r ∈ orientedEdges by decide +kernel) r
  have erasedCount : missing.card ≤ 1 := by
    have images : erased.image Fin.val ⊆ e ∩ edgeRows := by
      intro x hx
      obtain ⟨r, hr, rfl⟩ := Finset.mem_image.mp hx
      exact Finset.mem_inter.mpr ⟨(Finset.mem_filter.mp hr).2, Finset.mem_range.mpr r.isLt⟩
    have countEquiv : (erased.image Fin.val).card = erased.card :=
      Finset.card_image_of_injective _ (fun _ _ h => Fin.ext h)
    exact Finset.card_image_le.trans
      ((countEquiv.symm.le.trans (Finset.card_le_card images)).trans few)
  have projectedPairs (t : Finset ℕ) (ht : t ∈ B) :
      ∃ a ∈ D, ∃ b ∈ D, rowsOf (view a) ∩ rowsOf (view b) ⊆ edgeRows ∧
        ∀ r : Fin 16, r.val ∈ t → edgeAt r ∉ missing →
          r.val ∈ rowsOf (view a) ∩ rowsOf (view b) := by
    obtain ⟨a, aD, b, bD, eq, clean⟩ := pairs t ht
    have known := cleanProductFacts a b (eq ▸ clean)
    refine ⟨a, aD, b, bD, ?_, ?_⟩
    · intro r hr
      obtain ⟨left, right⟩ := Finset.mem_inter.mp hr
      obtain ⟨atA, hrActual⟩ := Finset.mem_inter.mp ((region a aD r).mpr (Or.inl left))
      have atB := (Finset.mem_inter.mp ((region b bD r).mpr (Or.inl right))).1
      exact known.1 (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr ⟨atA, atB⟩, hrActual⟩)
    · intro r row kept
      have edgeRow : r.val ∈ edgeRows := Finset.mem_range.mpr r.isLt
      have actual : r.val ∈ actualRows := (show edgeRows ⊆ actualRows by decide) edgeRow
      have noE : r.val ∉ e := fun hr =>
        kept (Finset.mem_image.mpr ⟨r, Finset.mem_filter.mpr ⟨Finset.mem_univ _, hr⟩, rfl⟩)
      have atBoth : r.val ∈ t ∩ edgeRows := Finset.mem_inter.mpr ⟨row, edgeRow⟩
      rw [eq, known.2.1] at atBoth
      obtain ⟨atA, atB⟩ := Finset.mem_inter.mp (Finset.mem_inter.mp atBoth).1
      have sees (w : Finset ℕ) (wD : w ∈ D) (atW : r.val ∈ w) : r.val ∈ rowsOf (view w) :=
        ((region w wD r.val).mp (Finset.mem_inter.mpr ⟨atW, actual⟩)).resolve_right
          (fun h => noE h.2)
      exact Finset.mem_inter.mpr ⟨sees a aD atA, sees b bD atB⟩
  have all : edgeRows ⊆ B.biUnion id := by rw [cover]; exact Finset.subset_insert _ _
  have lower := projectedCostWithMissing D B view missing missingBound builds projectedPairs all
  omega

end PEqualNP.Outside.L_meta_9427

