#define OR_LIMIT 5
#define COVER_LIMIT 7
#define main general_search_main
#include "L-meta-9427-small-or.cpp"
#undef main

#include <map>

bool uses_all_three(unsigned d_witnesses, unsigned e_witnesses) {
    for (int x = 0; x < 8; ++x) {
        if (!(d_witnesses & (1u << x))) {
            continue;
        }
        for (int y = 0; y < 8; ++y) {
            if ((x | y) == 7 && (e_witnesses & (1u << y))) {
                return true;
            }
        }
    }
    return false;
}

bool cover_with_five(Search& search, std::vector<Mask>& wires, Mask d, Mask e) {
    const Mask both = d | e | tag_d | tag_e;
    search.append(wires, both);
    for (bool has_tag : {false, true}) {
        for (Mask extra : unions(wires, has_tag)) {
            search.append(wires, extra);
            if (search.inspect(d, e, wires)) {
                return true;
            }
            search.pop(wires);
        }
    }
    search.pop(wires);

    // Any five-union family missing the merge of the two seeds must use
    // one union to extend one tagged seed and the last union to merge it.
    for (Mask extended : unions(wires, true)) {
        const Mask flags = extended & (tag_d | tag_e);
        if (flags == (tag_d | tag_e)) {
            continue;
        }
        const Mask other = flags == tag_d ? e | tag_e : d | tag_d;
        const Mask joined = extended | other;
        if (joined == both) {
            continue;
        }
        search.append(wires, extended);
        search.append(wires, joined);
        if (search.inspect(d, e, wires)) {
            return true;
        }
        search.pop(wires);
        search.pop(wires);
    }
    return false;
}

bool cover_with_six(Search& search, std::vector<Mask>& wires, Mask d, Mask e,
                    int left, bool has_merge, Mask after) {
    constexpr Mask flags = tag_d | tag_e;
    if (!left) {
        return has_merge && search.inspect(d, e, wires);
    }
    std::vector<Mask> candidates;
    const bool must_merge = left == 1 && !has_merge;
    for (std::size_t a = 0; a < wires.size(); ++a) {
        for (std::size_t b = a + 1; b < wires.size(); ++b) {
            const Mask x = wires[a], y = wires[b], joined = x | y;
            if (joined <= after || joined == x || joined == y
                || (must_merge && (joined & flags) != flags)
                || std::find(wires.begin(), wires.end(), joined) != wires.end()) {
                continue;
            }
            candidates.push_back(joined);
        }
    }
    std::sort(candidates.begin(), candidates.end());
    candidates.erase(std::unique(candidates.begin(), candidates.end()), candidates.end());
    for (Mask word : candidates) {
        search.append(wires, word);
        if (cover_with_six(search, wires, d, e, left - 1,
                           has_merge || (word & flags) == flags, word)) {
            return true;
        }
        search.pop(wires);
    }
    return false;
}

unsigned usable_tag_edges(Mask tag) {
    unsigned result = 0;
    for (Mask seed : vertices) {
        if (!(seed & tag & negatives)) {
            result |= unsigned(seed & tag & low);
        }
    }
    return result;
}

int main(int argc, char** argv) {
    const auto first = argc >= 2 ? std::stoul(argv[1]) : 0;
    const auto last = argc >= 3 ? std::stoul(argv[2]) : 55;
    const bool six = argc >= 4 && std::stoi(argv[3]) == 6;
    const auto direct = unions(vertices, false);
    assert(direct.size() == 55);
    if (first > last || last > direct.size()) {
        return 2;
    }
    Search search;
    std::uint64_t triples = 0, profiles = 0, small_omissions = 0;
    for (std::size_t i = first; i < last; ++i) {
        for (std::size_t j = i + 1; j < direct.size(); ++j) {
            for (std::size_t k = j + 1; k < direct.size(); ++k) {
                ++triples;
                std::vector<Mask> wires;
                wires.reserve(18);
                for (Mask seed : vertices) {
                    search.append(wires, seed);
                }
                for (Mask plain : {direct[i], direct[j], direct[k]}) {
                    search.append(wires, plain);
                }
                const auto used = [](std::size_t t) {
                    return t < vertices.size() ? 0u : 1u << (t - vertices.size());
                };
                std::map<Mask, unsigned> junk;
                for (std::size_t a = 0; a < wires.size(); ++a) {
                    for (std::size_t b = a; b < wires.size(); ++b) {
                        const Mask mask = wires[a] & wires[b];
                        if (mask & negatives) {
                            junk[mask] |= 1u << (used(a) | used(b));
                        }
                    }
                }
                for (auto d = junk.begin(); d != junk.end(); ++d) {
                    search.append(wires, d->first | tag_d);
                    for (auto e = d; e != junk.end(); ++e) {
                        if (!(d->first & e->first & negatives)
                            || !uses_all_three(d->second, e->second)) {
                            continue;
                        }
                        const Mask combined = d->first | e->first;
                        if (std::none_of(vertices.begin(), vertices.end(), [combined](Mask seed) {
                                return !(seed & combined & negatives);
                            })) {
                            continue;
                        }
                        ++profiles;
                        if (six && std::popcount(usable_tag_edges(d->first)
                                                | usable_tag_edges(e->first)) <= 2) {
                            ++small_omissions;
                            continue;
                        }
                        search.append(wires, e->first | tag_e);
                        const bool found = six
                            ? cover_with_six(search, wires, d->first, e->first, 3, false, 0)
                            : cover_with_five(search, wires, d->first, e->first);
                        if (found) {
                            return 1;
                        }
                        search.pop(wires);
                    }
                    search.pop(wires);
                }
                while (!wires.empty()) {
                    search.pop(wires);
                }
            }
        }
    }
    std::cout << "triples " << triples << ", profiles " << profiles << ", small omissions "
              << small_omissions << ", searched families " << search.families
              << ", exact cover checks " << search.covers_checked << '\n';
}
