#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <utility>

using Bits = std::uint32_t;
constexpr Bits all_rows = (1u << 24) - 1;
constexpr Bits all_edges = (1u << 16) - 1;

constexpr std::array<std::pair<int, int>, 16> edges = {
    {{0,9},{0,10},{1,4},{1,8},{2,5},{2,10},{3,6},{3,7},
     {4,8},{4,10},{5,8},{5,9},{6,7},{6,10},{7,9},{8,9}},
};
constexpr std::array<Bits, 24> independent = {
    15,29,43,57,71,85,99,113,135,149,163,177,269,325,389,526,540,582,
    596,1066,1186,1288,1408,1546,
};

using Graph = std::array<Bits, 24>;

bool obstruction(const Graph& graph, Bits pool, int need, Bits chosen, Bits& witness) {
    if (!need) {
        witness = chosen;
        return true;
    }
    while (std::popcount(pool) >= need) {
        const int v = std::countr_zero(pool);
        const Bits single = 1u << v;
        pool ^= single;
        if (obstruction(graph, pool & graph[v], need - 1, chosen | single, witness)) {
            return true;
        }
    }
    return false;
}

int main() {
    std::array<std::array<Bits, 24>, 24> conflict = {};
    for (int i = 0; i < 24; ++i) {
        for (int j = i + 1; j < 24; ++j) {
            const Bits both = independent[i] | independent[j];
            for (int e = 0; e < 16; ++e) {
                const auto [v, w] = edges[e];
                const Bits ends = (1u << v) | (1u << w);
                if ((both & ends) == ends) {
                    conflict[i][j] |= 1u << e;
                }
            }
        }
    }
    std::array<Bits, all_edges + 1> found = {};
    int minimal = 0;
    for (Bits t = 0; t <= all_edges; ++t) {
        for (Bits set = t; set; set &= set - 1) {
            if (Bits previous = found[t ^ (set & -set)]) {
                found[t] = previous;
                break;
            }
        }
        if (found[t]) {
            continue;
        }
        Graph graph = {};
        for (int i = 0; i < 24; ++i) {
            for (int j = i + 1; j < 24; ++j) {
                if (conflict[i][j] & t) {
                    graph[i] |= 1u << j;
                }
            }
        }
        if (obstruction(graph, all_rows, 6, 0, found[t])) {
            ++minimal;
            std::cout << "clique " << t << ' ' << found[t] << '\n';
        }
    }
    int unproved = 0;
    for (Bits t = 0; t <= all_edges / 2; ++t) {
        if (!found[t] && !found[all_edges ^ t]) {
            ++unproved;
            std::cout << "unproved " << t << '\n';
        }
    }
    std::cout << "minimal " << minimal << ", unproved partitions " << unproved << '\n';
}
