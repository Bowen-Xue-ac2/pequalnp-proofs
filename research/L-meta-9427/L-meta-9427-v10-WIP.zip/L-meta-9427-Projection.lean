import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem labelUnionFamily {α β : Type} [DecidableEq α] [DecidableEq β]
    (D X : Finset (Finset α)) (seed : Finset α → Finset β)
    (build : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) :
    ∃ label : Finset α → Finset β,
      (∀ w ∈ D, w ∈ X → label w = seed w) ∧
      (∀ w ∈ D, w ∉ X →
        ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧
          w = a ∪ b ∧ label w = label a ∪ label b) := by
  induction hD : D.card using Nat.strong_induction_on generalizing D with
  | ind n ih =>
    by_cases alive : D.Nonempty
    · obtain ⟨w, hw, top⟩ := Finset.exists_max_image D Finset.card alive
      let E := D.erase w
      have small : E.card < n := by
        dsimp only [E]
        rw [Finset.card_erase_of_mem hw]
        have positive := Finset.card_pos.mpr alive
        omega
      have children (v : Finset α) (hv : v ∈ D) (hnot : v ∉ X) :
          ∃ a ∈ E, ∃ b ∈ E, a ⊂ v ∧ b ⊂ v ∧ v = a ∪ b := by
        obtain ⟨a, ha, b, hb, haSub, hbSub, eq⟩ := build v hv hnot
        have different (c : Finset α) (sub : c ⊂ v) : c ≠ w := by
          intro h
          have hc := Finset.card_lt_card sub
          rw [h] at hc
          exact (Nat.not_lt_of_ge (top v hv)) hc
        exact ⟨a, Finset.mem_erase.mpr ⟨different a haSub, ha⟩,
          b, Finset.mem_erase.mpr ⟨different b hbSub, hb⟩, haSub, hbSub, eq⟩
      obtain ⟨old, oldSeed, oldBuild⟩ := ih E.card small E
        (fun v hv => children v (Finset.mem_erase.mp hv).2) rfl
      have pick : ∃ c : Finset β,
          (w ∈ X → c = seed w) ∧
          (w ∉ X → ∃ a ∈ E, ∃ b ∈ E, a ⊂ w ∧ b ⊂ w ∧
            w = a ∪ b ∧ c = old a ∪ old b) := by
        by_cases win : w ∈ X
        · exact ⟨seed w, fun _ => rfl, fun h => (h win).elim⟩
        · obtain ⟨a, ha, b, hb, haSub, hbSub, eq⟩ := children w hw win
          exact ⟨old a ∪ old b, fun h => (win h).elim,
            fun _ => ⟨a, ha, b, hb, haSub, hbSub, eq, rfl⟩⟩
      obtain ⟨c, hcSeed, hcBuild⟩ := pick
      let label (v : Finset α) := if v = w then c else old v
      have atTop : label w = c := by simp [label]
      have same (v : Finset α) (hv : v ∈ E) : label v = old v := by
        simp [label, (Finset.mem_erase.mp hv).1]
      refine ⟨label, ?_, ?_⟩
      · intro v hv hx
        by_cases hvw : v = w
        · subst v
          rw [atTop]
          exact hcSeed hx
        · have hvE := Finset.mem_erase.mpr ⟨hvw, hv⟩
          rw [same v hvE]
          exact oldSeed v hvE hx
      · intro v hv hx
        by_cases hvw : v = w
        · subst v
          obtain ⟨a, ha, b, hb, haSub, hbSub, eq, he⟩ := hcBuild hx
          refine ⟨a, (Finset.mem_erase.mp ha).2, b, (Finset.mem_erase.mp hb).2,
            haSub, hbSub, eq, ?_⟩
          rw [atTop, same a ha, same b hb]
          exact he
        · have hvE := Finset.mem_erase.mpr ⟨hvw, hv⟩
          obtain ⟨a, ha, b, hb, haSub, hbSub, eq, he⟩ := oldBuild v hvE hx
          refine ⟨a, (Finset.mem_erase.mp ha).2, b, (Finset.mem_erase.mp hb).2,
            haSub, hbSub, eq, ?_⟩
          rwa [same v hvE, same a ha, same b hb]
    · refine ⟨seed, fun _ _ _ => rfl, ?_⟩
      intro w hw _
      exact (alive ⟨w, hw⟩).elim

private theorem projectedFamily {α β : Type} [DecidableEq α] [DecidableEq β]
    (D X : Finset (Finset α)) (label : Finset α → Finset β)
    (root : ∀ w ∈ D, w ∈ X → (label w).card ≤ 1)
    (build : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ label w = label a ∪ label b) :
    ((D.image label).filter (fun w => 1 < w.card)).card ≤ (D \ X).card ∧
    (∀ w ∈ D.image label, 1 < w.card →
      ∃ a ∈ D.image label, ∃ b ∈ D.image label, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) := by
  constructor
  · have sub : (D.image label).filter (fun w => 1 < w.card) ⊆ (D \ X).image label := by
      intro w hw
      obtain ⟨himage, large⟩ := Finset.mem_filter.mp hw
      obtain ⟨s, hs, rfl⟩ := Finset.mem_image.mp himage
      exact Finset.mem_image_of_mem _ (Finset.mem_sdiff.mpr
        ⟨hs, fun h => (Nat.not_le_of_gt large) (root s hs h)⟩)
    exact (Finset.card_le_card sub).trans Finset.card_image_le
  · intro w hw large
    obtain ⟨s, hs, e⟩ := Finset.mem_image.mp hw
    let candidates := D.filter fun t => label t = w
    have nonempty : candidates.Nonempty := ⟨s, Finset.mem_filter.mpr ⟨hs, e⟩⟩
    obtain ⟨v, hv, small⟩ := Finset.exists_min_image candidates Finset.card nonempty
    obtain ⟨hvD, hvEq⟩ := Finset.mem_filter.mp hv
    have notRoot : v ∉ X := by
      intro hx
      have limit := root v hvD hx
      rw [hvEq] at limit
      exact (Nat.not_le_of_gt large) limit
    obtain ⟨a, ha, b, hb, haSub, hbSub, eq⟩ := build v hvD notRoot
    have equality : w = label a ∪ label b := hvEq.symm.trans eq
    have proper (t : Finset α) (ht : t ∈ D) (hq : t ⊂ v) (incl : label t ⊆ w) :
        label t ⊂ w := by
      apply Finset.ssubset_iff_subset_ne.mpr
      refine ⟨incl, ?_⟩
      intro e'
      have hlt := Finset.card_lt_card hq
      exact (Nat.not_lt_of_ge (small t (Finset.mem_filter.mpr ⟨ht, e'⟩))) hlt
    refine ⟨label a, Finset.mem_image_of_mem _ ha, label b, Finset.mem_image_of_mem _ hb,
      proper a ha haSub ?_, proper b hb hbSub ?_, equality⟩
    · rw [equality]
      exact Finset.subset_union_left
    · rw [equality]
      exact Finset.subset_union_right

end PEqualNP.Outside.L_meta_9427
