import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def headEdges (H : Finset (Fin 11 × Finset (Fin 11))) : Finset (Fin 11 × Fin 11) :=
  orientedEdges.filter fun f => ∃ h ∈ H,
    (f.1 = h.1 ∧ f.2 ∈ h.2) ∨ (f.2 = h.1 ∧ f.1 ∈ h.2)

def neighborsIn (E : Finset (Fin 11 × Fin 11)) (u : Fin 11) : Finset (Fin 11) :=
  Finset.univ.filter fun v => (u, v) ∈ E ∨ (v, u) ∈ E

def rowsIn (E : Finset (Fin 11 × Fin 11)) : Finset ℕ :=
  (Finset.univ.filter fun r : Fin 16 => edgeAt r ∈ E).image Fin.val

private theorem graphNoLoop : ∀ u : Fin 11, ¬edge u u := by decide +kernel

private theorem headLeavesInGraph (H : Finset (Fin 11 × Finset (Fin 11)))
    (h : Fin 11 × Finset (Fin 11)) (hh : h ∈ H) (valid : h.2 ⊆ neighbors h.1) :
    h.2 ⊆ neighborsIn (headEdges H) h.1 := by
  intro v hv
  have adjacent := (Finset.mem_filter.mp (valid hv)).2
  have different : h.1 ≠ v := fun eq => graphNoLoop h.1 (eq.symm ▸ adjacent)
  refine Finset.mem_filter.mpr ⟨Finset.mem_univ _, ?_⟩
  rcases lt_or_gt_of_ne different with left | right
  · exact Or.inl (Finset.mem_filter.mpr
      ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, left, adjacent⟩,
        h, hh, Or.inl ⟨rfl, hv⟩⟩)
  · exact Or.inr (Finset.mem_filter.mpr
      ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _, right, (edgeSwap _ _).mp adjacent⟩,
        h, hh, Or.inr ⟨rfl, hv⟩⟩)

private theorem rowsOfAdjacentRootsIn (E : Finset (Fin 11 × Fin 11))
    (edges : E ⊆ orientedEdges) (u v : Fin 11)
    (linked : (u, v) ∈ E ∨ (v, u) ∈ E) (r : ℕ)
    (ru : r ∈ rootSet u) (rv : r ∈ rootSet v) : r ∈ rowsIn E := by
  have ordered (p : Fin 11 × Fin 11) (hp : p ∈ E) : p.1 < p.2 ∧ edge p.1 p.2 :=
    (Finset.mem_filter.mp (edges hp)).2
  have adj : edge u v := by
    rcases linked with uv | vu
    · exact (ordered _ uv).2
    · exact (edgeSwap v u).mp (ordered _ vu).2
  have distinct : u ≠ v := fun eq => graphNoLoop u (eq.symm ▸ adj)
  have inBounds := (rootSetPair u v).mpr adj
    (Finset.mem_inter.mpr ⟨ru, rv⟩)
  let i : Fin 16 := ⟨r, Finset.mem_range.mp inBounds⟩
  have across : edgeAt i = (u, v) ∨ edgeAt i = (v, u) := by
    rcases (edgeAtMembership i u).mp ru with left | right <;>
      rcases (edgeAtMembership i v).mp rv with low | high
    · exact (distinct (left.trans low.symm)).elim
    · exact Or.inl (Prod.ext left.symm high.symm)
    · exact Or.inr (Prod.ext low.symm right.symm)
    · exact (distinct (right.trans high.symm)).elim
  have iOrder := (Finset.mem_filter.mp (edgeAtOriented i)).2.1
  have iEdge : edgeAt i ∈ E := by
    rcases across with eq | eq
    · rw [eq] at iOrder ⊢
      exact linked.resolve_right (fun h => lt_asymm iOrder (ordered _ h).1)
    · rw [eq] at iOrder ⊢
      exact linked.resolve_left (fun h => lt_asymm iOrder (ordered _ h).1)
  exact Finset.mem_image.mpr ⟨i, Finset.mem_filter.mpr ⟨Finset.mem_univ _, iEdge⟩, rfl⟩

private theorem unusedOnRetainedRows (d e w : Finset ℕ)
    (s centers : Finset (Fin 11)) (E : Finset (Fin 11 × Fin 11))
    (edges : E ⊆ orientedEdges)
    (shape : projectionFacts d e ∅ ∅ w s) (untagged : ¬carriesTag w)
    (noRoot : ∀ u ∈ centers, ¬(w ∩ rootSet u ∩ actualRows ⊆ rowsIn E)) :
    ¬usableSupport centers s (neighborsIn E) := by
  rintro ⟨u, hu, supported⟩
  apply noRoot u hu
  intro r hr
  obtain ⟨both, actual⟩ := Finset.mem_inter.mp hr
  obtain ⟨atW, atU⟩ := Finset.mem_inter.mp both
  have projected : r ∈ rowsOf s := by
    rcases shape.2.2.2 r atW actual with atRoot | ⟨tag, _⟩ | ⟨tag, _⟩
    · exact atRoot
    · exact (untagged (Or.inl tag)).elim
    · exact (untagged (Or.inr tag)).elim
  obtain ⟨v, hv, atV⟩ := Finset.mem_biUnion.mp projected
  exact rowsOfAdjacentRootsIn E edges u v (Finset.mem_filter.mp (supported hv)).2 r atU atV

private theorem costByRetainedGraph (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows)
    (spare : ∀ E : Finset (Fin 11 × Fin 11), E ⊆ orientedEdges →
      (∀ r : Fin 16, ¬possibleOmission d e r.val → edgeAt r ∈ E) →
      ∀ C : Finset (Fin 11), (∀ f ∈ E, f.1 ∈ C ∨ f.2 ∈ C) →
      ∃ U : Finset (Finset ℕ), 21 ≤ E.card + C.card + U.card + 2 ∧
        ∀ w ∈ U, w ∈ D \ markedSeeds d e ∧ ¬carriesTag w ∧
          ∀ u ∈ C, ¬(w ∩ rootSet u ∩ actualRows ⊆ rowsIn E)) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  obtain ⟨label, H, missing, replay, roots, projectedBuild, headShapes,
    coverage, omitted, _, tagCost⟩ := actualErasure d e D B dRows eRows build pairs cover
  let E := headEdges H
  let C := H.image Prod.fst
  have edges : E ⊆ orientedEdges := Finset.filter_subset _ _
  have kept (r : Fin 16) (certain : ¬possibleOmission d e r.val) : edgeAt r ∈ E := by
    have oriented := edgeAtOriented r
    rcases coverage (edgeAt r) oriented with lost | present
    · obtain ⟨q, eq, reason⟩ := omitted _ lost
      have same : r = q := by
        have injectiveEdge : Function.Injective edgeAt := by decide +kernel
        exact injectiveEdge eq
      exact (certain (same.symm ▸ reason)).elim
    · exact Finset.mem_filter.mpr ⟨oriented, present⟩
  have headCovers (f : Fin 11 × Fin 11) (hf : f ∈ E) : ∃ h ∈ H,
      (f.1 = h.1 ∧ f.2 ∈ h.2) ∨ (f.2 = h.1 ∧ f.1 ∈ h.2) :=
    (Finset.mem_filter.mp hf).2
  obtain ⟨U, enough, unused⟩ := spare E edges kept C (coverCenters H E headCovers)
  have usefulHeads : ∀ h ∈ H, h.2 ∈ usefulProjection D label C (neighborsIn E) ∧
      h.2 ⊆ neighbors h.1 := by
    intro h hh
    obtain ⟨previous, neighborhood⟩ := headShapes h hh
    have usable : usableSupport C h.2 (neighborsIn E) :=
      ⟨h.1, Finset.mem_image_of_mem _ hh, headLeavesInGraph H h hh neighborhood⟩
    exact ⟨Finset.mem_filter.mpr ⟨previous, usable⟩, neighborhood⟩
  have edgeCost := purePartialCost (usefulProjection D label C (neighborsIn E)) H E edges
    (usefulBuild D label C (neighborsIn E) projectedBuild) usefulHeads headCovers
  have unionCost := usefulProjectionDeficit D (markedSeeds d e) label C (neighborsIn E) roots U
    (fun w hw => by
      obtain ⟨old, flat, cannot⟩ := unused w hw
      exact ⟨old, flat, unusedOnRetainedRows d e w (label w) C E edges
        (replay w (Finset.mem_sdiff.mp old).1) flat cannot⟩)
  have centers : C.card ≤ H.card := Finset.card_image_le
  omega

end PEqualNP.Outside.L_meta_9427
