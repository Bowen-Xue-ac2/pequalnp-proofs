#include <algorithm>
#include <array>
#include <bit>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <limits>
#include <set>
#include <unordered_map>
#include <vector>

using Mask = std::uint64_t;
constexpr Mask tag_d = Mask{1} << 40;
constexpr Mask tag_e = Mask{1} << 41;
constexpr Mask low = (Mask{1} << 16) - 1;
constexpr Mask negatives = (tag_d - 1) ^ low;
constexpr unsigned target = (1u << 17) - 1;
#ifndef OR_LIMIT
#define OR_LIMIT 2
#endif
#ifndef COVER_LIMIT
#define COVER_LIMIT 9
#endif
constexpr int or_limit = OR_LIMIT;
constexpr int cover_limit = COVER_LIMIT;
const std::vector<Mask> vertices = {
    2147418115, 663661903884, 34144976944, 728266375360,
    21653750532, 103293914128, 26322415680, 344922804352,
    414195942664, 581968119809, 1065151898146,
};

// Proper-subset OR children precede their parent. Untagged nodes have only
// untagged ancestors, so they can be enumerated before choosing the two
// tagged intersections. Making all seeds available costs no OR gates.
std::vector<Mask> unions(const std::vector<Mask>& wires, bool tagged, Mask after = 0) {
    std::vector<Mask> result;
    for (std::size_t i = 0; i < wires.size(); ++i) {
        for (std::size_t j = i + 1; j < wires.size(); ++j) {
            const Mask a = wires[i];
            const Mask b = wires[j];
            const Mask c = a | b;
            if (c <= after || c == a || c == b || (bool(c & (tag_d | tag_e)) != tagged)) {
                continue;
            }
            if (std::find(wires.begin(), wires.end(), c) == wires.end()) {
                result.push_back(c);
            }
        }
    }
    std::sort(result.begin(), result.end());
    result.erase(std::unique(result.begin(), result.end()), result.end());
    return result;
}

bool cover(const std::vector<unsigned>& terms, unsigned uncovered, int left,
           std::unordered_map<unsigned, int>& impossible, std::vector<unsigned>& chosen) {
    if (!uncovered) {
        return true;
    }
    if (!left || (impossible.contains(uncovered) && impossible[uncovered] >= left)) {
        return false;
    }
    int fewest = int(terms.size()) + 1;
    unsigned edge = 0;
    for (unsigned bit = 1; bit <= (1u << 16); bit <<= 1) {
        if (uncovered & bit) {
            int n = std::ranges::count_if(terms, [bit](unsigned t) { return t & bit; });
            if (n < fewest) {
                fewest = n;
                edge = bit;
            }
        }
    }
    for (unsigned t : terms) {
        if (t & edge) {
            chosen.push_back(t);
            if (cover(terms, uncovered & ~t, left - 1, impossible, chosen)) {
                return true;
            }
            chosen.pop_back();
        }
    }
    impossible[uncovered] = left;
    return false;
}

struct Search {
    std::uint64_t families = 0;
    std::uint64_t covers_checked = 0;
    std::array<unsigned, target + 1> frequency{};
    std::vector<unsigned> relevant;
    int extra_savings = 0;
    int tag_terms = 0;

    static unsigned extra_term(Mask a, Mask b) {
        if (a & b & negatives) {
            return 0;
        }
        unsigned t = unsigned(a & b & low);
        if (((a | b) & (tag_d | tag_e)) == (tag_d | tag_e)) {
            t |= 1u << 16;
        }
        return ((t & (1u << 16)) || std::popcount(t) > 1) ? t : 0;
    }

    void append(std::vector<Mask>& wires, Mask wire) {
        assert(wire & negatives);
        for (Mask prior : wires) {
            const unsigned term = extra_term(prior, wire);
            if (term && !frequency[term]++) {
                relevant.push_back(term);
                extra_savings += std::popcount(term) - 1;
                tag_terms += bool(term & (1u << 16));
            }
        }
        wires.push_back(wire);
    }

    void pop(std::vector<Mask>& wires) {
        const Mask wire = wires.back();
        wires.pop_back();
        for (auto i = wires.rbegin(); i != wires.rend(); ++i) {
            const unsigned term = extra_term(*i, wire);
            if (term && !--frequency[term]) {
                assert(relevant.back() == term);
                relevant.pop_back();
                extra_savings -= std::popcount(term) - 1;
                tag_terms -= bool(term & (1u << 16));
            }
        }
    }

    bool inspect(Mask d, Mask e, const std::vector<Mask>& wires) {
        ++families;
        // Each ordinary edge is already available as a singleton. A cover
        // with k terms can cover at most k plus the sum of their gains.
        if (!tag_terms || extra_savings < std::popcount(target) - cover_limit) {
            return false;
        }
        std::vector<unsigned> terms = relevant;
        for (unsigned edge = 1; edge <= (1u << 15); edge <<= 1) {
            terms.push_back(edge);
        }
        std::vector<unsigned> maximal;
        for (unsigned t : terms) {
            if (!std::ranges::any_of(terms, [t](unsigned s) { return s != t && (s | t) == s; })) {
                maximal.push_back(t);
            }
        }
        std::sort(maximal.begin(), maximal.end(), [](unsigned a, unsigned b) {
            return std::popcount(a) > std::popcount(b);
        });
        int upper = 0;
        for (std::size_t i = 0; i < maximal.size() && i < cover_limit; ++i) {
            upper += std::popcount(maximal[i]);
        }
        if (upper < std::popcount(target)) {
            return false;
        }
        ++covers_checked;
        std::vector<unsigned> chosen;
        std::unordered_map<unsigned, int> impossible;
        if (!cover(maximal, target, cover_limit, impossible, chosen)) {
            return false;
        }
        std::cout << "candidate d=" << d << " e=" << e << " wires:";
        for (Mask wire : wires) {
            std::cout << ' ' << wire;
        }
        std::cout << " cover:";
        for (unsigned t : chosen) {
            const Mask actual = (t & low) | ((t >> 16) ? tag_d : 0);
            std::cout << ' ' << actual;
        }
        std::cout << '\n';
        return true;
    }

    bool tagged(Mask d, Mask e, std::vector<Mask>& wires, int used, Mask previous) {
        if (used && inspect(d, e, wires)) {
            return true;
        }
        if (used == or_limit) {
            return false;
        }
        for (Mask value : unions(wires, true, previous)) {
            append(wires, value);
            if (tagged(d, e, wires, used + 1, value)) {
                return true;
            }
            pop(wires);
        }
        return false;
    }
};

int main(int argc, char** argv) {
    const int first = argc >= 2 ? std::stoi(argv[1]) : 0;
    const int last = argc >= 3 ? std::stoi(argv[2]) : or_limit;
    const std::size_t begin = argc >= 4 ? std::stoull(argv[3]) : 0;
    const std::size_t end = argc >= 5 ? std::stoull(argv[4]) : std::numeric_limits<std::size_t>::max();
    if (first < 0 || last < first || last > or_limit || end < begin || (argc >= 4 && first != last)) {
        return 2;
    }
    Search search;
    std::vector<Mask> seeds = vertices;
    std::sort(seeds.begin(), seeds.end());
    std::set<std::vector<Mask>> current{seeds};
    for (int r = 0; r <= last; ++r) {
        std::set<std::vector<Mask>> next;
        std::size_t index = 0;
        std::size_t inspected = 0;
        for (const auto& untagged : current) {
            const std::size_t item = index++;
            if (r >= first && item >= begin && item < end) {
                ++inspected;
                std::set<Mask> junk;
                for (Mask a : untagged) {
                    for (Mask b : untagged) {
                        if (a & b & negatives) {
                            junk.insert(a & b);
                        }
                    }
                }
                std::vector<Mask> wires;
                wires.reserve(vertices.size() + 2 + or_limit);
                for (Mask wire : untagged) {
                    search.append(wires, wire);
                }
                for (auto d = junk.begin(); d != junk.end(); ++d) {
                    search.append(wires, *d | tag_d);
                    for (auto e = d; e != junk.end(); ++e) {
                        if (r == or_limit && (*d & *e & negatives)) {
                            ++search.families;
                            continue;
                        }
                        search.append(wires, *e | tag_e);
                        if (search.tagged(*d, *e, wires, r, 0)) {
                            return 1;
                        }
                        search.pop(wires);
                    }
                    search.pop(wires);
                }
                while (!wires.empty()) {
                    search.pop(wires);
                }
            }
            if (r < last) {
                for (Mask value : unions(untagged, false)) {
                    auto family = untagged;
                    family.push_back(value);
                    std::sort(family.begin(), family.end());
                    next.insert(std::move(family));
                }
            }
        }
        std::cout << "untagged_ORs=" << r << " untagged_families=" << current.size()
                  << " inspected_untagged_families=" << inspected
                  << " total_families=" << search.families
                  << " full_cover_tests=" << search.covers_checked << std::endl;
        current = std::move(next);
    }
    std::cout << "No cover with at most " << or_limit << " OR gates and "
              << cover_limit << " cover terms for the inspected untagged families.\n";
}
