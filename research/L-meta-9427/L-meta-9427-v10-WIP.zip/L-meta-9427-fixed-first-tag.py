"""Search for a budget-20 cover around the known right-hand G11 gadget."""

import argparse
from collections import defaultdict
from functools import cache
from itertools import combinations, combinations_with_replacement
import json
from pathlib import Path
import runpy


directory = Path(__file__).resolve().parent
integer = runpy.run_path(str(directory / "L-meta-9427-integer-cover.py"))
base = integer["model"]["model"]
roots = base["VERTEX_ROWS"]
positive = base["EDGE_ROWS"]
negative = base["NEGATIVE_ROWS"]
union = base["union"]


def support(indices):
    return sum(1 << i for i in indices)


@cache
def tag_signature(value):
    compatible = [i for i, root in enumerate(roots) if not value & root & negative]
    return support(compatible), value & positive & union(roots[i] for i in compatible)


def cases(overlap, size):
    d_producers = (roots[6] | roots[9], roots[7] | roots[10])
    d = d_producers[0] & d_producers[1]
    assert d == 549755842560
    first = (support((6, 9)), support((7, 10)))
    raw = {word: 1 for word in roots}
    for k in range(2, size + 1):
        for values in combinations(roots, k):
            raw.setdefault(union(values), k)

    groups = defaultdict(dict)
    for a, b in combinations_with_replacement(sorted(raw), 2):
        e = a & b
        if not e & negative or bool(d & e & negative) != overlap:
            continue
        compat, used = tag_signature(e)
        common = compat & tag_signature(d)[0]
        if overlap and not common:
            continue
        jointly = 0 if overlap else d & e & positive
        key = (compat, used, jointly)
        groups[key][(a, b, e)] = len({a, b} - set(roots))

    ranked = []
    used_d = tag_signature(d)[1]
    for key, options in groups.items():
        compat, used, jointly = key
        sorted_options = sorted(options, key=lambda x: (options[x], raw[x[0]] + raw[x[1]], x))
        left, right, e = sorted_options[0]
        score = (used_d | used | jointly).bit_count() - options[(left, right, e)]
        ranked.append((score, jointly.bit_count(), compat.bit_count(), e, sorted_options))
    ranked.sort(reverse=True)
    return d, first, [(*d_producers, d)], ranked


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("branch", choices=("overlap", "safe"))
    parser.add_argument("--start", type=int, default=0)
    parser.add_argument("--count", type=int, default=16)
    parser.add_argument("--seconds", type=float, default=6)
    parser.add_argument("--producer-size", type=int, default=3)
    parser.add_argument("--budget", type=int, default=20)
    parser.add_argument("--min-shared", type=int, default=0)
    parser.add_argument("--fixed-right", action="store_true")
    args = parser.parse_args()

    overlap = args.branch == "overlap"
    d, first, d_options, ranked = cases(overlap, args.producer_size)
    ranked = [entry for entry in ranked if entry[1] >= args.min_shared]
    if args.fixed_right:
        first += (support((6, 7)), support((3, 11)))
    print(json.dumps({"branch": args.branch, "profiles": len(ranked), "fixed_right": args.fixed_right}),
          flush=True)
    for index, (score, jointly, _, e, options) in enumerate(ranked[args.start:args.start+args.count],
                                                           args.start):
        result = integer["solve"](d, e, first, 13, args.budget, args.seconds, overlap_relaxation=overlap,
                                  producer_options=(d_options, options))
        print(json.dumps({"index": index, "score": score, "shared_rows": jointly, **result}),
              flush=True)
        if "witness" in result:
            break


if __name__ == "__main__":
    main()
