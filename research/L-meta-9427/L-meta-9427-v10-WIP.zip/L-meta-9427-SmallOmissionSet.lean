import Mathlib

namespace PEqualNP.Outside.L_meta_9427

noncomputable def potentialOmissions (d e : Finset ℕ) : Finset (Fin 11 × Fin 11) := by
  classical
  exact (Finset.univ.filter fun r : Fin 16 => possibleOmission d e r.val).image edgeAt

private theorem edgeAtOriented : ∀ r : Fin 16, edgeAt r ∈ orientedEdges := by
  decide +kernel

private theorem costWithSmallOmissionSet (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (small : (potentialOmissions d e).card ≤ 2)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  classical
  obtain ⟨label, H, missing, _, roots, projectedBuild, heads, covers, omitted, _, charge⟩ :=
    actualErasure d e D B dRows eRows build pairs cover
  have possible : missing ⊆ potentialOmissions d e := by
    intro f hf
    obtain ⟨r, rfl, reason⟩ := omitted f hf
    exact Finset.mem_image.mpr ⟨r, Finset.mem_filter.mpr ⟨Finset.mem_univ _, reason⟩, rfl⟩
  have sub : missing ⊆ orientedEdges := by
    intro f hf
    obtain ⟨r, rfl, _⟩ := omitted f hf
    exact edgeAtOriented r
  have omittedCount := (Finset.card_le_card possible).trans small
  have bound := pureCostWithMissing (D.image label) H missing sub projectedBuild heads covers
  have counts := projectionUnionDeficit D (markedSeeds d e) label roots
  have tagged : (redundantTaggedUnions D (markedSeeds d e) label).card ≤
      (redundantUnions D (markedSeeds d e) label).card :=
    Finset.card_le_card (Finset.filter_subset _ _)
  omega

end PEqualNP.Outside.L_meta_9427
