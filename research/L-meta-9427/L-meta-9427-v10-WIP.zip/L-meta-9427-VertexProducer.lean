import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem vertexIntersectionMatches (v : Fin 11) (S : Finset (Fin 11))
    (noCenter : v ∉ S) (r : Fin 16) (atV : r.val ∈ rootSet v) (atS : r.val ∈ rowsOf S)
    (oriented : edgeAt r ∈ orientedEdges) :
    ((edgeAt r).1 = v ∧ (edgeAt r).2 ∈ S ∩ neighbors v) ∨
    ((edgeAt r).2 = v ∧ (edgeAt r).1 ∈ S ∩ neighbors v) := by
  obtain ⟨u, hu, atU⟩ := Finset.mem_biUnion.mp atS
  have different : u ≠ v := fun eq => noCenter (eq ▸ hu)
  have adj := (Finset.mem_filter.mp oriented).2.2
  rcases (edgeAtMembership r v).mp atV with vlo | vhi <;>
    rcases (edgeAtMembership r u).mp atU with ulo | uhi
  · exact (different (ulo.trans vlo.symm)).elim
  · have vu : edge v u := vlo.symm ▸ uhi.symm ▸ adj
    exact Or.inl ⟨vlo.symm, uhi ▸ Finset.mem_inter.mpr
      ⟨hu, Finset.mem_filter.mpr ⟨Finset.mem_univ _, vu⟩⟩⟩
  · have uv : edge u v := ulo.symm ▸ vhi.symm ▸ adj
    exact Or.inr ⟨vhi.symm, ulo ▸ Finset.mem_inter.mpr
      ⟨hu, Finset.mem_filter.mpr ⟨Finset.mem_univ _, (edgeSwap _ _).mp uv⟩⟩⟩
  · exact (different (uhi.trans vhi.symm)).elim

private theorem costFromVertexIntersectionAndCopy (d e w : Finset ℕ)
    (v z : Fin 11) (D B : Finset (Finset ℕ))
    (dEq : d = rootSet v ∩ w) (eEq : e = rootSet z)
    (wD : w ∈ D) (wRows : w ⊆ actualRows) (noCopy : ¬rootSet v ⊆ w)
    (build : ∀ t ∈ D, t ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ t ∧ b ⊂ t ∧ t = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  have dRows : d ⊆ actualRows := by
    rw [dEq]
    exact Finset.inter_subset_left.trans (rootRowsBound v)
  have eRows : e ⊆ actualRows := eEq.symm ▸ rootRowsBound z
  have eProj : rowsOf ({z} : Finset (Fin 11)) = e := by simp [rowsOf, eEq]
  obtain ⟨label, valid, budget, projectedBuild⟩ :=
    projectionWithSmallSeedImages d e D ∅ {z} dRows eRows (by simp) (by simp)
      (by simp [rowsOf]) (fun _ hr => eProj ▸ hr) build
  let missing := (Finset.univ.filter fun r : Fin 16 => r.val ∈ d).image edgeAt
  have stays (a : Finset ℕ) (ha : a ∈ D) (r : ℕ) (ra : r ∈ a)
      (actual : r ∈ actualRows) (outside : r ∉ d) : r ∈ rowsOf (label a) := by
    have replay := valid a ha
    rcases replay.2.2.2 r ra actual with kept | ⟨_, rd⟩ | ⟨flag, re⟩
    · exact kept
    · exact (outside rd).elim
    · have rz : r ∈ rootSet z := eEq ▸ re
      exact Finset.mem_biUnion.mpr ⟨z, (replay.2.2.1 flag).2 (Finset.mem_singleton_self _), rz⟩
  have positive : edgeRows ⊆ B.biUnion id := by rw [cover]; exact Finset.subset_insert _ _
  have project : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      rowsOf (label a) ∩ rowsOf (label b) ⊆ edgeRows ∧
      ∀ r : Fin 16, r.val ∈ t → edgeAt r ∉ missing →
        r.val ∈ rowsOf (label a) ∩ rowsOf (label b) := by
    intro t ht
    obtain ⟨a, ha, b, hb, eq, inside⟩ := pairs t ht
    have ⟨clean, rows, _⟩ := cleanProductFacts a b (eq ▸ inside)
    refine ⟨a, ha, b, hb, projectedClean a b _ _ (valid a ha).1 (valid b hb).1 clean, ?_⟩
    intro r real retained
    have noD : r.val ∉ d :=
      fun atD => retained (Finset.mem_image.mpr ⟨r, Finset.mem_filter.mpr
        ⟨Finset.mem_univ _, atD⟩, rfl⟩)
    have actual : r.val ∈ actualRows :=
      Finset.mem_range.mpr (r.isLt.trans (by decide : 16 < 40))
    have row : r.val ∈ t ∩ edgeRows := Finset.mem_inter.mpr ⟨real, Finset.mem_range.mpr r.isLt⟩
    rw [eq, rows] at row
    obtain ⟨ra, rb⟩ := Finset.mem_inter.mp (Finset.mem_inter.mp row).1
    exact Finset.mem_inter.mpr ⟨stays a ha r ra actual noD, stays b hb r rb actual noD⟩
  obtain ⟨H, hCount, heads, hCovers⟩ :=
    headsFromProjection D B label missing project positive
  have pureProducer := untaggedRows d e w ∅ {z} (label w) (valid w wD) wRows
  have noCenter : v ∉ label w := by
    intro hv
    apply noCopy
    intro i hi
    exact (valid w wD).1 (Finset.mem_biUnion.mpr ⟨v, hv, hi⟩)
  have repairs (f : Fin 11 × Fin 11) (hf : f ∈ orientedEdges) (lost : f ∈ missing) :
      (f.1 = v ∧ f.2 ∈ label w ∩ neighbors v) ∨
      (f.2 = v ∧ f.1 ∈ label w ∩ neighbors v) := by
    obtain ⟨r, hr, rfl⟩ := Finset.mem_image.mp lost
    have both := (Finset.mem_filter.mp hr).2
    rw [dEq] at both
    obtain ⟨atV, atW⟩ := Finset.mem_inter.mp both
    exact vertexIntersectionMatches v (label w) noCenter r atV (pureProducer ▸ atW) hf
  have pure := pureCostWithStarRepair (D.image label) H v (label w) (Finset.mem_image_of_mem _ wD)
    projectedBuild heads (fun f hf => (hCovers f hf).elim
      (fun lost => (repairs f hf lost).elim Or.inl (fun right => Or.inr (Or.inl right)))
      (fun kept => Or.inr (Or.inr kept)))
  have noMore : H.card ≤ B.card :=
    hCount.trans (Finset.card_le_card (Finset.filter_subset _ _))
  omega

private theorem costFromSameVertexIntersections (d e w y : Finset ℕ)
    (v : Fin 11) (D B : Finset (Finset ℕ))
    (dEq : d = rootSet v ∩ w) (eEq : e = rootSet v ∩ y)
    (wD : w ∈ D) (yD : y ∈ D) (wRows : w ⊆ actualRows) (yRows : y ⊆ actualRows)
    (wNotCopy : ¬rootSet v ⊆ w) (yNotCopy : ¬rootSet v ⊆ y)
    (build : ∀ t ∈ D, t ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ t ∧ b ⊂ t ∧ t = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    22 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  classical
  have dRows : d ⊆ actualRows := by rw [dEq]; exact Finset.inter_subset_left.trans (rootRowsBound v)
  have eRows : e ⊆ actualRows := by rw [eEq]; exact Finset.inter_subset_left.trans (rootRowsBound v)
  obtain ⟨label, H, missing, replay, roots, builds, heads, covers, lost, _, tagCost⟩ :=
    actualErasure d e D B dRows eRows build pairs cover
  let F := D.image label
  let S := label w ∪ label y
  let family := insert S F
  have prevW : label w ∈ F := Finset.mem_image_of_mem _ wD
  have prevY : label y ∈ F := Finset.mem_image_of_mem _ yD
  have newBuild : ∀ t ∈ family, 1 < t.card →
      ∃ a ∈ family, ∃ b ∈ family, a ⊂ t ∧ b ⊂ t ∧ t = a ∪ b := by
    intro t ht large
    by_cases old : t ∈ F
    · obtain ⟨a, ha, b, hb, asub, bsub, eq⟩ := builds t old large
      exact ⟨a, Finset.mem_insert_of_mem ha, b, Finset.mem_insert_of_mem hb, asub, bsub, eq⟩
    have eq : t = S := (Finset.mem_insert.mp ht).resolve_right old
    subst t
    have sw : label w ⊂ S := Finset.ssubset_iff_subset_ne.mpr
      ⟨Finset.subset_union_left, fun eq => old (eq ▸ prevW)⟩
    have sy : label y ⊂ S := Finset.ssubset_iff_subset_ne.mpr
      ⟨Finset.subset_union_right, fun eq => old (eq ▸ prevY)⟩
    exact ⟨label w, Finset.mem_insert_of_mem prevW, label y, Finset.mem_insert_of_mem prevY,
      sw, sy, rfl⟩
  have newHeads : ∀ h ∈ H, h.2 ∈ family ∧ h.2 ⊆ neighbors h.1 :=
    fun h hh => ⟨Finset.mem_insert_of_mem (heads h hh).1, (heads h hh).2⟩
  have noCenter : v ∉ S := by
    intro hv
    have copy (word : Finset ℕ) (hw : word ∈ D) (found : v ∈ label word) :
        rootSet v ⊆ word :=
      fun r hr => (replay word hw).1 (Finset.mem_biUnion.mpr ⟨v, found, hr⟩)
    exact (Finset.mem_union.mp hv).elim (fun found => wNotCopy (copy w wD found))
      (fun found => yNotCopy (copy y yD found))
  have repair (r : Fin 16) (marked : r.val ∈ d ∨ r.val ∈ e)
      (oriented : edgeAt r ∈ orientedEdges) :
      ((edgeAt r).1 = v ∧ (edgeAt r).2 ∈ S ∩ neighbors v) ∨
      ((edgeAt r).2 = v ∧ (edgeAt r).1 ∈ S ∩ neighbors v) := by
    have inTag (tag word : Finset ℕ) (producer : tag = rootSet v ∩ word)
        (hw : word ∈ D) (hwRows : word ⊆ actualRows) (subset : label word ⊆ S)
        (hit : r.val ∈ tag) : r.val ∈ rootSet v ∧ r.val ∈ rowsOf S := by
      rw [producer] at hit
      obtain ⟨atV, atW⟩ := Finset.mem_inter.mp hit
      have exactWord := untaggedRows d e word ∅ ∅ (label word) (replay word hw) hwRows
      obtain ⟨u, hu, rowU⟩ := Finset.mem_biUnion.mp (exactWord ▸ atW)
      exact ⟨atV, Finset.mem_biUnion.mpr ⟨u, subset hu, rowU⟩⟩
    have both := marked.elim (inTag d w dEq wD wRows Finset.subset_union_left)
      (inTag e y eEq yD yRows Finset.subset_union_right)
    exact vertexIntersectionMatches v S noCenter r both.1 both.2 oriented
  have pure := pureCostWithStarRepair family H v S (Finset.mem_insert_self _ _)
    newBuild newHeads (fun f hf => by
      rcases covers f hf with omitted | kept
      · obtain ⟨r, rfl, explanation⟩ := lost f omitted
        rcases repair r (possibleOmissionMem explanation) hf with left | right
        · exact Or.inl left
        · exact Or.inr (Or.inl right)
      · exact Or.inr (Or.inr kept))
  have subset : (family.filter fun s => 1 < s.card) ⊆ insert S (F.filter fun s => 1 < s.card) := by
    intro t ht
    obtain ⟨inFamily, big⟩ := Finset.mem_filter.mp ht
    rcases Finset.mem_insert.mp inFamily with rfl | old
    · exact Finset.mem_insert_self _ _
    · exact Finset.mem_insert_of_mem (Finset.mem_filter.mpr ⟨old, big⟩)
  have added := (Finset.card_le_card subset).trans (Finset.card_insert_le _ _)
  have gates := projectionUnionDeficit D (markedSeeds d e) label roots
  have tagged : (redundantTaggedUnions D (markedSeeds d e) label).card ≤
      (redundantUnions D (markedSeeds d e) label).card :=
    Finset.card_le_card (Finset.filter_subset _ _)
  change (F.filter fun w => 1 < w.card).card +
    (redundantUnions D (markedSeeds d e) label).card ≤ _ at gates
  omega

end PEqualNP.Outside.L_meta_9427
