import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem scenarioAfterErasingPaidWord (d e w : Finset ℕ) (D B C : Finset (Finset ℕ))
    (scenario : coverScenario d e D B)
    (limit : (D \ markedSeeds d e).card + 2 * B.card ≤ 20)
    (paid : w ∈ D \ markedSeeds d e)
    (dStill : d ∈ plainIntersections (D.erase w)) (eStill : e ∈ plainIntersections (D.erase w))
    (buildStill : ∀ t ∈ D.erase w, t ∉ markedSeeds d e →
      ∃ a ∈ D.erase w, ∃ b ∈ D.erase w, a ⊂ t ∧ b ⊂ t ∧ t = a ∪ b)
    (smaller : C.card ≤ B.card) (full : C.biUnion id = insert 40 edgeRows)
    (pairsStill : ∀ t ∈ C,
      t ∈ Finset.image₂ productTerm (D.erase w) (D.erase w) ∧ t ⊆ insert 40 edgeRows ∧
      ∀ q ∈ Finset.image₂ productTerm (D.erase w) (D.erase w), q ⊆ insert 40 edgeRows → t ⊆ q → q = t)
    (privateRows : ∀ t ∈ C, ∃ r ∈ t, ∀ q ∈ C, r ∈ q → q = t) :
    coverScenario d e (D.erase w) C ∧
      ((D.erase w) \ markedSeeds d e).card + 1 = (D \ markedSeeds d e).card := by
  let E := D.erase w
  have properPaid : E \ markedSeeds d e = (D \ markedSeeds d e).erase w := by
    ext t
    change t ∈ (D.erase w) \ markedSeeds d e ↔ t ∈ (D \ markedSeeds d e).erase w
    simp only [Finset.mem_erase, Finset.mem_sdiff]
    tauto
  have count : (E \ markedSeeds d e).card + 1 = (D \ markedSeeds d e).card := by
    rw [properPaid]
    exact Finset.card_erase_add_one paid
  obtain ⟨_, _, dDirty, eDirty, bounded, _, _, mBound, kBound, _, _, _⟩ :=
    scenario
  have cleanPairs (t : Finset ℕ) (ht : t ∈ C) :
      ∃ a ∈ E, ∃ b ∈ E, t = productTerm a b ∧ t ⊆ insert 40 edgeRows := by
    obtain ⟨a, aE, b, bE, eq⟩ := Finset.mem_image₂.mp (pairsStill t ht).1
    exact ⟨a, aE, b, bE, eq.symm, (pairsStill t ht).2.1⟩
  have pos : 1 ≤ (E \ markedSeeds d e).card := by
    by_contra none
    have ordinary : E.filter (· ⊆ actualRows) \ baseSets ⊆ E \ markedSeeds d e := by
      intro t ht
      obtain ⟨atE, notBase⟩ := Finset.mem_sdiff.mp ht
      obtain ⟨tE, real⟩ := Finset.mem_filter.mp atE
      refine Finset.mem_sdiff.mpr ⟨tE, ?_⟩
      intro seed
      simp only [markedSeeds, Finset.mem_insert] at seed
      rcases seed with rfl | rfl | base
      · exact (show 40 ∉ actualRows by decide) (real (Finset.mem_insert_self _ _))
      · exact (show 41 ∉ actualRows by decide) (real (Finset.mem_insert_self _ _))
      · exact notBase base
    have small : (E.filter (· ⊆ actualRows) \ baseSets).card ≤ 1 :=
      (Finset.card_le_card ordinary).trans (by omega)
    have lower := costWithAtMostOnePlainUnion d e E C dStill eStill dDirty eDirty
      small buildStill cleanPairs full
    omega
  have within : (E \ markedSeeds d e).card ≤ 18 := by omega
  exact ⟨⟨dStill, eStill, dDirty, eDirty, fun t ht => bounded t (Finset.mem_of_mem_erase ht),
    buildStill, pos, within, smaller.trans kBound, full, pairsStill, privateRows⟩, count⟩

private theorem discardUnusedPaidWord (d e w : Finset ℕ) (D B : Finset (Finset ℕ))
    (scenario : coverScenario d e D B)
    (limit : (D \ markedSeeds d e).card + 2 * B.card ≤ 20)
    (paid : w ∈ D \ markedSeeds d e)
    (dStill : d ∈ plainIntersections (D.erase w)) (eStill : e ∈ plainIntersections (D.erase w))
    (buildStill : ∀ t ∈ D.erase w, t ∉ markedSeeds d e →
      ∃ a ∈ D.erase w, ∃ b ∈ D.erase w, a ⊂ t ∧ b ⊂ t ∧ t = a ∪ b)
    (pairsStill : ∀ t ∈ B, t ∈ Finset.image₂ productTerm (D.erase w) (D.erase w)) :
    coverScenario d e (D.erase w) B ∧
      ((D.erase w) \ markedSeeds d e).card + 1 = (D \ markedSeeds d e).card := by
  have properties := scenario
  obtain ⟨_, _, _, _, _, _, _, _, _, full, terms, privateRows⟩ := properties
  apply scenarioAfterErasingPaidWord d e w D B B scenario limit paid dStill eStill buildStill
    le_rfl full _ privateRows
  intro t ht
  have old := terms t ht
  refine ⟨pairsStill t ht, old.2.1, ?_⟩
  intro s hs good grows
  obtain ⟨a, aE, b, bE, eq⟩ := Finset.mem_image₂.mp hs
  exact old.2.2 s
    (Finset.mem_image₂.mpr ⟨a, Finset.mem_of_mem_erase aE, b, Finset.mem_of_mem_erase bE, eq⟩)
    good grows

private theorem cappedCounterexampleAllUnionsUsed (d e : Finset ℕ) (cap : ℕ)
    (witness : ∃ D B, coverScenario d e D B ∧
      (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧ B.card ≤ cap) :
    ∃ D B, coverScenario d e D B ∧ (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧
      markedSeeds d e ⊆ D ∧ B.card ≤ cap ∧
      (∀ a ∈ D, ∀ b ∈ D, ∀ c ∈ D, ∀ f ∈ D,
        productTerm a b ∈ B → productTerm c f ∈ B → productTerm a b ≠ productTerm c f →
        ¬(productTerm a f ⊆ insert 40 edgeRows ∧ productTerm c b ⊆ insert 40 edgeRows)) ∧
      ∀ w ∈ D \ markedSeeds d e, ¬(
        d ∈ plainIntersections (D.erase w) ∧ e ∈ plainIntersections (D.erase w) ∧
        (∀ t ∈ D.erase w, t ∉ markedSeeds d e →
          ∃ a ∈ D.erase w, ∃ b ∈ D.erase w, a ⊂ t ∧ b ⊂ t ∧ t = a ∪ b) ∧
        ∀ t ∈ B, t ∈ Finset.image₂ productTerm (D.erase w) (D.erase w)) := by
  have seeded : ∃ D B, coverScenario d e D B ∧
      (D \ markedSeeds d e).card + 2 * B.card ≤ 20 ∧ markedSeeds d e ⊆ D ∧
      B.card ≤ cap := by
    obtain ⟨D, B, valid, budget, few⟩ := witness
    obtain ⟨C, enlarged, smaller, count⟩ := augmentSeedCover d e D B valid
    exact ⟨D ∪ markedSeeds d e, C, enlarged, by omega, Finset.subset_union_right, smaller.trans few⟩
  obtain ⟨D, B, scenario, cost, seeds, few, noRectangle, optimal⟩ :=
    cappedCounterexampleWithOptimalFamily d e (markedSeeds d e) cap seeded
  refine ⟨D, B, scenario, cost, seeds, few, noRectangle, ?_⟩
  intro w paid h
  obtain ⟨dStill, eStill, buildStill, pairsStill⟩ := h
  obtain ⟨valid, count⟩ :=
    discardUnusedPaidWord d e w D B scenario cost paid dStill eStill buildStill pairsStill
  have keeps : markedSeeds d e ⊆ D.erase w := by
    intro s hs
    exact Finset.mem_erase.mpr ⟨fun eq => (Finset.mem_sdiff.mp paid).2 (eq ▸ hs), seeds hs⟩
  have bound : ((D.erase w) \ markedSeeds d e).card + 2 * B.card ≤ 20 := by omega
  have check := optimal (D.erase w) B valid bound keeps few
  dsimp [coverRank] at check
  omega

end PEqualNP.Outside.L_meta_9427

