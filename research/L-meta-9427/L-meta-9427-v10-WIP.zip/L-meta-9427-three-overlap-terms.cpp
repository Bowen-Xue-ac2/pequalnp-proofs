#include <algorithm>
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <map>
#include <string_view>
#include <tuple>
#include <vector>

using Word = std::uint64_t;
using Edges = std::uint32_t;
constexpr Edges positive = (1u << 16) - 1;
constexpr Word negative = ((1ul << 40) - 1) ^ positive;
constexpr std::array<Word, 11> roots = {
    2147418115, 663661903884, 34144976944, 728266375360, 21653750532, 103293914128,
    26322415680, 344922804352, 414195942664, 581968119809, 1065151898146,
};

using Support = unsigned int;
constexpr Support limit = 1u << roots.size();
std::array<Word, limit> words = {};
std::array<Support, roots.size()> neighbors = {};

Support compatible(Word word) {
    Support compatible = 0;
    for (unsigned i = 0; i < roots.size(); ++i) {
        if (!(word & roots[i] & negative)) {
            compatible |= 1u << i;
        }
    }
    return compatible;
}

std::vector<Edges> tag_terms(Support domain, Edges edges) {
    std::vector<Edges> result = {edges & Edges(words[domain])};
    for (unsigned i = 0; i < roots.size(); ++i) {
        Support opposite = domain & neighbors[i];
        if (std::popcount(opposite) > 1) {
            result.push_back((edges | Edges(roots[i])) & Edges(words[opposite]) & positive);
        }
    }
    for (Support choices = domain; choices; choices &= choices - 1) {
        result.push_back(Edges(roots[std::countr_zero(choices)]) & positive);
    }
    std::sort(result.begin(), result.end());
    result.erase(std::unique(result.begin(), result.end()), result.end());
    return result;
}

struct Profile {
    Support compatible = 0;
    Edges edges = 0;
    Word negatives = 0;
    int producer_size = 25;
    Word representative = 0;
    std::vector<Edges> terms;
};

bool has_cover(const std::vector<Edges>& tag, std::vector<Edges>& all,
               std::array<Edges, 3>& cover) {
    std::sort(all.begin(), all.end(), [](Edges a, Edges b) {
        return std::tuple(std::popcount(a), a) > std::tuple(std::popcount(b), b);
    });
    all.erase(std::unique(all.begin(), all.end()), all.end());
    for (Edges head : tag) {
        const Edges remaining = positive ^ head;
        if (std::popcount(remaining) > 2 * std::popcount(all.front())) {
            continue;
        }
        for (std::size_t i = 0; i < all.size(); ++i) {
            const Edges second = all[i];
            if (std::popcount(remaining) > 2 * std::popcount(second)) {
                break;
            }
            const Edges need = remaining & ~second;
            for (std::size_t j = i; j < all.size(); ++j) {
                const Edges third = all[j];
                if (std::popcount(need) > std::popcount(third)) {
                    break;
                }
                if ((third & need) == need) {
                    cover = {head, second, third};
                    return true;
                }
            }
        }
    }
    return false;
}

std::vector<Edges> split_tag_terms(Word d, Word e, Support dc, Support ec) {
    const Edges joint = Edges(d & e) & positive;
    std::vector<Edges> output = {
        joint | (Edges(d & words[dc]) & positive),
        joint | (Edges(e & words[ec]) & positive),
    };
    const auto include = [&](Word a, Word b, Support ac, Support bc) {
        for (Support s = bc; s; s &= s - 1) {
            const unsigned u = std::countr_zero(s);
            const Support other = ac & neighbors[u];
            const Word rows = (roots[u] & b) | ((a | roots[u]) & words[other]);
            output.push_back(joint | (Edges(rows) & positive));
        }
    };
    include(d, e, dc, ec);
    include(e, d, ec, dc);
    std::sort(output.begin(), output.end());
    output.erase(std::unique(output.begin(), output.end()), output.end());
    return output;
}

void run_safe(const std::map<Word, int>& ordinary, const std::vector<Edges>& pure) {
    std::map<Word, Word> saturation;
    for (const auto [x, size] : ordinary) {
        saturation[x & negative] |= x;
    }
    std::map<Word, int> tags;
    for (auto a = saturation.begin(); a != saturation.end(); ++a) {
        for (auto b = a; b != saturation.end(); ++b) {
            const Word tag = a->second & b->second;
            if (tag & negative) {
                const int size = ordinary.at(a->second) + ordinary.at(b->second);
                auto [it, fresh] = tags.try_emplace(tag, size);
                if (!fresh) {
                    it->second = std::min(it->second, size);
                }
            }
        }
    }
    std::map<Word, std::vector<Profile>> buckets;
    for (const auto [tag, size] : tags) {
        const Support comp = compatible(tag);
        const Edges rows = Edges(tag) & positive;
        buckets[tag & negative].push_back({comp, rows, tag & negative, size, tag,
                                          tag_terms(comp, rows)});
    }
    std::cout << "saturated tags " << tags.size() << ", negative patterns " << buckets.size() << '\n';
    int eligible = 0, possible = 0, best = 100;
    for (auto a = buckets.begin(); a != buckets.end(); ++a) {
        for (auto b = std::next(a); b != buckets.end(); ++b) {
            if (a->first & b->first) {
                continue;
            }
            for (const auto& d : a->second) {
                for (const auto& e : b->second) {
                    ++eligible;
                    const Support shared = d.compatible & e.compatible;
                    auto anchor = split_tag_terms(d.representative, e.representative,
                                                  d.compatible, e.compatible);
                    if (shared) {
                        const auto double_terms = tag_terms(shared, d.edges | e.edges);
                        anchor.insert(anchor.end(), double_terms.begin(), double_terms.end());
                    }
                    auto all = pure;
                    all.insert(all.end(), anchor.begin(), anchor.end());
                    all.insert(all.end(), d.terms.begin(), d.terms.end());
                    all.insert(all.end(), e.terms.begin(), e.terms.end());
                    std::array<Edges, 3> cover;
                    if (has_cover(anchor, all, cover)) {
                        ++possible;
                        const int size = d.producer_size + e.producer_size;
                        if (size <= best) {
                            best = size;
                            std::cout << "possible " << size << ' ' << d.representative << ' '
                                      << e.representative << ' ' << cover[0] << ' ' << cover[1]
                                      << ' ' << cover[2] << '\n';
                        }
                    }
                }
            }
        }
    }
    std::cout << "safe pairs " << eligible << ", three-term pairs " << possible << '\n';
}

int main(int argc, char** argv) {
    std::map<Word, int> ordinary;
    for (Support s = 1; s < limit; ++s) {
        words[s] = words[s & (s - 1)] | roots[std::countr_zero(s)];
        auto [entry, fresh] = ordinary.try_emplace(words[s], std::popcount(s));
        if (!fresh) {
            entry->second = std::min(entry->second, std::popcount(s));
        }
    }
    for (unsigned i = 0; i < roots.size(); ++i) {
        neighbors[i] = compatible(roots[i]);
    }
    std::vector<Edges> pure;
    for (Word root : roots) {
        pure.push_back(Edges(root) & positive);
    }
    if (argc > 1 && std::string_view(argv[1]) == "safe") {
        ordinary.try_emplace(0, 0);
        run_safe(ordinary, pure);
        return 0;
    }
    std::map<std::pair<Support, Edges>, Profile> profiles;
    std::map<Word, Support> saved_compatibility;
    for (auto a = ordinary.begin(); a != ordinary.end(); ++a) {
        for (auto b = a; b != ordinary.end(); ++b) {
            const Word tag = a->first & b->first;
            if (!(tag & negative)) {
                continue;
            }
            auto [record, fresh] = saved_compatibility.try_emplace(tag, 0);
            if (fresh) {
                record->second = compatible(tag);
            }
            const Support comp = record->second;
            if (!comp) {
                continue;
            }
            const Edges seen = Edges(tag & words[comp]) & positive;
            Profile& profile = profiles[{comp, seen}];
            profile.compatible = comp;
            profile.edges = seen;
            profile.negatives |= tag & negative;
            if (const int size = a->second + b->second; size < profile.producer_size) {
                profile.producer_size = size;
                profile.representative = tag;
            }
        }
    }
    for (auto& [key, profile] : profiles) {
        profile.terms = tag_terms(profile.compatible, profile.edges);
    }
    std::cout << "profiles " << profiles.size() << '\n';
    if (argc > 1) {
        const auto original = profiles;
        std::erase_if(profiles, [&](const auto& entry) {
            const Profile& a = entry.second;
            return std::ranges::any_of(original, [&](const auto& other) {
                const Profile& b = other.second;
                return other.first != entry.first && (a.compatible & b.compatible) == a.compatible
                    && (a.edges & b.edges) == a.edges;
            });
        });
        std::cout << "maximal profiles " << profiles.size() << '\n';
        for (const auto& [key, prof] : profiles) {
            std::cout << "profile " << prof.compatible << ' ' << prof.edges << ' '
                      << prof.representative << '\n';
        }
    }
    int eligible = 0, possible = 0, best = 100;
    for (auto a = profiles.begin(); a != profiles.end(); ++a) {
        for (auto b = a; b != profiles.end(); ++b) {
            const Profile& d = a->second;
            const Profile& e = b->second;
            const Support domain = d.compatible & e.compatible;
            if (!domain || (argc == 1 && !(d.negatives & e.negatives))) {
                continue;
            }
            ++eligible;
            auto anchor = tag_terms(domain, d.edges | e.edges);
            auto all = pure;
            all.insert(all.end(), anchor.begin(), anchor.end());
            all.insert(all.end(), d.terms.begin(), d.terms.end());
            all.insert(all.end(), e.terms.begin(), e.terms.end());
            std::array<Edges, 3> cover;
            if (has_cover(anchor, all, cover)) {
                ++possible;
                const int size = d.producer_size + e.producer_size;
                if (size <= best) {
                    best = size;
                    std::cout << "possible " << size << ' ' << d.representative << ' '
                              << e.representative << ' ' << cover[0] << ' ' << cover[1] << ' '
                              << cover[2] << '\n';
                }
            }
        }
    }
    std::cout << "eligible " << eligible << ", three-term profiles " << possible << '\n';
}
