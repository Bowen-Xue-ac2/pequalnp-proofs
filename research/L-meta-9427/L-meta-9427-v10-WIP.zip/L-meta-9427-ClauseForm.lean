import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def operandClauses (w : Finset ℕ) (S U V X Y : Finset (Fin 11)) :
    List (Finset (Fin 11)) :=
  if 40 ∈ w then
    if 41 ∈ w then
      [S ∪ U ∪ X, S ∪ U ∪ Y, S ∪ V ∪ X, S ∪ V ∪ Y]
    else
      [S ∪ U, S ∪ V]
  else
    if 41 ∈ w then [S ∪ X, S ∪ Y] else [S]

private theorem rowsOfUnion (S T : Finset (Fin 11)) :
    rowsOf (S ∪ T) = rowsOf S ∪ rowsOf T := by
  simp only [rowsOf, Finset.union_biUnion]

set_option maxHeartbeats 1800000 in
private theorem operandClausesSound
    (d e w : Finset ℕ) (S U V X Y : Finset (Fin 11))
    (dValue : d = rowsOf U ∩ rowsOf V) (eValue : e = rowsOf X ∩ rowsOf Y)
    (shape : projectionFacts d e ∅ ∅ w S) (r : ℕ) (hr : r ∈ actualRows) :
    r ∈ w ↔ ∀ c ∈ operandClauses w S U V X Y, r ∈ rowsOf c := by
  have row : r ∈ w ↔ r ∈ rowsOf S ∨ (40 ∈ w ∧ r ∈ d) ∨ (41 ∈ w ∧ r ∈ e) := by
    constructor
    · exact fun atW => shape.2.2.2 r atW hr
    · rintro (plain | ⟨flag, atD⟩ | ⟨flag, atE⟩)
      · exact shape.1 plain
      · exact (shape.2.1 flag).1 atD
      · exact (shape.2.2.1 flag).1 atE
  rw [row, dValue, eValue]
  by_cases p : 40 ∈ w <;> by_cases q : 41 ∈ w <;>
    simp [operandClauses, p, q, rowsOfUnion] <;> tauto

private theorem clausesPairLength (a b : Finset ℕ) (A B U V X Y : Finset (Fin 11))
    (np : ¬(40 ∈ a ∧ 40 ∈ b)) (nq : ¬(41 ∈ a ∧ 41 ∈ b)) :
    (operandClauses a A U V X Y ++ operandClauses b B U V X Y).length ≤ 5 := by
  by_cases pa : 40 ∈ a <;> by_cases qa : 41 ∈ a <;>
    by_cases pb : 40 ∈ b <;> by_cases qb : 41 ∈ b <;>
    simp_all [operandClauses]

private theorem cleanTermClauses (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (positions : ∃ u ∈ D, ∃ v ∈ D, u ⊆ actualRows ∧ v ⊆ actualRows ∧ d = u ∩ v)
    (positions' : ∃ u ∈ D, ∃ v ∈ D, u ⊆ actualRows ∧ v ⊆ actualRows ∧ e = u ∩ v)
    (dDirty : ¬d ⊆ edgeRows) (eDirty : ¬e ⊆ edgeRows)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows) :
    ∀ t ∈ B, ∃ C : List (Finset (Fin 11)), C.length ≤ 5 ∧
      ∀ r ∈ actualRows, r ∈ t ↔ ∀ c ∈ C, r ∈ rowsOf c := by
  classical
  obtain ⟨u, hu, v, hv, uRows, vRows, dRaw⟩ := positions
  obtain ⟨x, hx, y, hy, xRows, yRows, eRaw⟩ := positions'
  have dRows : d ⊆ actualRows := dRaw ▸ Finset.inter_subset_left.trans uRows
  have eRows : e ⊆ actualRows := eRaw ▸ Finset.inter_subset_left.trans xRows
  let seed (w : Finset ℕ) : Finset (Fin 11) :=
    if h : w ∈ markedSeeds d e then (eraseSeedFacts d e dRows eRows w h).choose else ∅
  obtain ⟨label, root, join⟩ := labelUnionFamily D (markedSeeds d e) seed build
  have replay := projectionFactsReplay D (markedSeeds d e) d e ∅ ∅ label
    (fun w hw hSeed => by
      rw [root w hw hSeed]
      simpa [seed, hSeed] using (eraseSeedFacts d e dRows eRows w hSeed).choose_spec.2.1) join
  have dValue : d = rowsOf (label u) ∩ rowsOf (label v) := by
    exact dRaw.trans (congrArg₂ (· ∩ ·)
      (untaggedRows d e u ∅ ∅ (label u) (replay u hu) uRows)
      (untaggedRows d e v ∅ ∅ (label v) (replay v hv) vRows))
  have eValue : e = rowsOf (label x) ∩ rowsOf (label y) := by
    exact eRaw.trans (congrArg₂ (· ∩ ·)
      (untaggedRows d e x ∅ ∅ (label x) (replay x hx) xRows)
      (untaggedRows d e y ∅ ∅ (label y) (replay y hy) yRows))
  intro t ht
  obtain ⟨a, ha, b, hb, term, inside⟩ := pairs t ht
  rw [term] at inside
  have clean := (cleanProductFacts a b inside).1
  have fa := replay a ha
  have fb := replay b hb
  have np : ¬(40 ∈ a ∧ 40 ∈ b) := by
    intro common
    apply dDirty
    intro r hr
    exact clean (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr
      ⟨(fa.2.1 common.1).1 hr, (fb.2.1 common.2).1 hr⟩, dRows hr⟩)
  have nq : ¬(41 ∈ a ∧ 41 ∈ b) := by
    intro common
    apply eDirty
    intro r hr
    exact clean (Finset.mem_inter.mpr ⟨Finset.mem_inter.mpr
      ⟨(fa.2.2.1 common.1).1 hr, (fb.2.2.1 common.2).1 hr⟩, eRows hr⟩)
  let A := operandClauses a (label a) (label u) (label v) (label x) (label y)
  let C := operandClauses b (label b) (label u) (label v) (label x) (label y)
  refine ⟨A ++ C, clausesPairLength a b _ _ _ _ _ _ np nq, ?_⟩
  intro r hr
  have plain : r ≠ 40 := fun eq => (show 40 ∉ actualRows by decide) (eq ▸ hr)
  have synthetic :
      r ∉ (if {40, 41} ⊆ a ∪ b then {40} else (∅ : Finset ℕ)) := by
    split <;> simp [plain]
  have normal : r ∈ t ↔ r ∈ a ∧ r ∈ b := by
    rw [term]
    simp only [productTerm, Finset.mem_union, Finset.mem_inter, hr, and_true, synthetic, or_false]
  rw [normal]
  have left : r ∈ a ↔ ∀ c ∈ A, r ∈ rowsOf c :=
    operandClausesSound d e a _ _ _ _ _ dValue eValue fa r hr
  have right : r ∈ b ↔ ∀ c ∈ C, r ∈ rowsOf c :=
    operandClausesSound d e b _ _ _ _ _ dValue eValue fb r hr
  rw [left, right]
  simp only [List.mem_append, or_imp, forall_and]

end PEqualNP.Outside.L_meta_9427
