import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem costByProjectedCenters (d e : Finset ℕ) (D B : Finset (Finset ℕ))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows)
    (E : Finset (Fin 11 × Fin 11)) (edges : E ⊆ orientedEdges)
    (untouched : ∀ r : Fin 16, edgeAt r ∈ E → ¬possibleOmission d e r.val)
    (spare : ∀ C : Finset (Fin 11), (∀ f ∈ E, f.1 ∈ C ∨ f.2 ∈ C) →
      ∃ U : Finset (Finset ℕ), 21 ≤ E.card + C.card + U.card + 2 ∧
        ∀ w ∈ U, w ∈ D \ markedSeeds d e ∧ ¬carriesTag w ∧
          ∀ u ∈ C, ¬(w ∩ rootSet u ∩ actualRows ⊆ edgeRows)) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  obtain ⟨label, H, missing, replay, roots, projectionBuild, projectedHeads,
    coverage, omitted, _, charge⟩ := actualErasure d e D B dRows eRows build pairs cover
  let C := H.image Prod.fst
  have retained : ∀ f ∈ E, ∃ h ∈ H,
      (f.1 = h.1 ∧ f.2 ∈ h.2) ∨ (f.2 = h.1 ∧ f.1 ∈ h.2) := by
    intro f hf
    rcases coverage f (edges hf) with lost | kept
    · obtain ⟨r, rfl, h⟩ := omitted f lost
      exact (untouched r hf h).elim
    · exact kept
  obtain ⟨U, enough, unused⟩ := spare C (coverCenters H E retained)
  have headUseful : ∀ h ∈ H,
      h.2 ∈ usefulProjection D label C neighbors ∧ h.2 ⊆ neighbors h.1 := by
    intro h hh
    obtain ⟨atD, atNeighbor⟩ := projectedHeads h hh
    exact ⟨Finset.mem_filter.mpr ⟨atD, h.1, Finset.mem_image_of_mem _ hh, atNeighbor⟩,
      atNeighbor⟩
  have edgeBudget := purePartialCost (usefulProjection D label C neighbors) H E edges
    (usefulBuild D label C neighbors projectionBuild) headUseful retained
  have gateBudget := usefulProjectionDeficit D (markedSeeds d e) label C neighbors roots U
    (fun w hw => by
      obtain ⟨old, untagged, noRoot⟩ := unused w hw
      exact ⟨old, untagged, noCommonNeighborFromRows d e w ∅ ∅ (label w) C
        (replay w (Finset.mem_sdiff.mp old).1) untagged noRoot⟩)
  have centerCount : C.card ≤ H.card := Finset.card_image_le
  omega

end PEqualNP.Outside.L_meta_9427
