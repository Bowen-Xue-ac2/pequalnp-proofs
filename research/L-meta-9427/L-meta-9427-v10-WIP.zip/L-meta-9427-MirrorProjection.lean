import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem projectionWithSmallerSeedCopies {α β : Type} [DecidableEq α] [DecidableEq β]
    (D X : Finset (Finset α)) (view : Finset α → Finset β)
    (seeds : ∀ w ∈ D, w ∈ X → (view w).card ≤ 1 ∨
      ∃ q ∈ D, q ⊂ w ∧ view q = view w)
    (underUnion : ∀ w ∈ D, w ∉ X →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ view w = view a ∪ view b) :
    ((D.image view).filter fun s => 1 < s.card).card ≤ (D \ X).card ∧
    (∀ s ∈ D.image view, 1 < s.card →
      ∃ a ∈ D.image view, ∃ b ∈ D.image view, a ⊂ s ∧ b ⊂ s ∧ s = a ∪ b) := by
  have least (s : Finset β) (hs : s ∈ D.image view) (large : 1 < s.card) :
      ∃ w ∈ D, w ∉ X ∧ view w = s ∧ ∀ v ∈ D, view v = s → w.card ≤ v.card := by
    let preimages := D.filter fun w => view w = s
    obtain ⟨a, ha, eq⟩ := Finset.mem_image.mp hs
    have nonempty : preimages.Nonempty := ⟨a, Finset.mem_filter.mpr ⟨ha, eq⟩⟩
    obtain ⟨w, h, first⟩ := Finset.exists_min_image preimages Finset.card nonempty
    obtain ⟨inD, hValue⟩ := Finset.mem_filter.mp h
    have optimal (v : Finset α) (hv : v ∈ D) (vValue : view v = s) : w.card ≤ v.card :=
      first v (Finset.mem_filter.mpr ⟨hv, vValue⟩)
    refine ⟨w, inD, ?_, hValue, optimal⟩
    intro free
    rcases seeds w inD free with small | ⟨q, qD, smaller, value⟩
    · rw [hValue] at small
      omega
    · exact (Nat.not_lt_of_ge (optimal q qD (value.trans hValue))) (Finset.card_lt_card smaller)
  constructor
  · have paid : (D.image view).filter (fun s => 1 < s.card) ⊆ (D \ X).image view := by
      intro s hs
      obtain ⟨inD, large⟩ := Finset.mem_filter.mp hs
      obtain ⟨w, wD, wX, eq, _⟩ := least s inD large
      exact Finset.mem_image.mpr ⟨w, Finset.mem_sdiff.mpr ⟨wD, wX⟩, eq⟩
    exact (Finset.card_le_card paid).trans Finset.card_image_le
  · intro s hs large
    obtain ⟨w, wD, wX, eq, optimal⟩ := least s hs large
    obtain ⟨a, aD, b, bD, aSmall, bSmall, join⟩ := underUnion w wD wX
    have left : view a ⊂ s := Finset.ssubset_iff_subset_ne.mpr
      ⟨(join.symm.trans eq) ▸ Finset.subset_union_left,
        fun same => (Nat.not_lt_of_ge (optimal a aD same)) (Finset.card_lt_card aSmall)⟩
    have right : view b ⊂ s := Finset.ssubset_iff_subset_ne.mpr
      ⟨(join.symm.trans eq) ▸ Finset.subset_union_right,
        fun same => (Nat.not_lt_of_ge (optimal b bD same)) (Finset.card_lt_card bSmall)⟩
    exact ⟨view a, Finset.mem_image_of_mem _ aD, view b, Finset.mem_image_of_mem _ bD,
      left, right, eq.symm.trans join⟩

end PEqualNP.Outside.L_meta_9427

