"""Search the exact row-cover instance for a concrete counterexample.

Every untagged row set is an OR of vertex row sets. Tagged seeds are
the two designated intersections of untagged sets, with one added bit.
An OR straight-line program of the available cost represents the family
of row sets. Additional base sets may be present at zero cost. Any cover
using clean pairs extends to a cover by inclusion-maximal clean pairs;
removing redundant sets restores the private-row condition. A model is
reported only after an independent check of all original hypotheses.
"""

import argparse
import functools
import itertools
import json
import operator

import z3


VERTEX_ROWS = (
    2147418115, 663661903884, 34144976944, 728266375360,
    21653750532, 103293914128, 26322415680, 344922804352,
    414195942664, 581968119809, 1065151898146,
)
TAG_D = 1 << 40
TAG_E = 1 << 41
WIDTH = 42
ROWS = TAG_D - 1
EDGE_ROWS = (1 << 16) - 1
NEGATIVE_ROWS = ROWS ^ EDGE_ROWS
TARGET = EDGE_ROWS | TAG_D


def union(values):
    return functools.reduce(operator.or_, values, 0)


def pair_rows(a, b):
    rows = a & b & ROWS
    if (a | b) & (TAG_D | TAG_E) == TAG_D | TAG_E:
        rows |= TAG_D
    return rows


def verify_certificate(d, e, family, cover, budget):
    leaves = set(VERTEX_ROWS) | {d | TAG_D, e | TAG_E}
    untagged = {value for value in family if value <= ROWS}
    intersections = {a & b for a in untagged for b in untagged}
    assert d in intersections and e in intersections
    assert d & NEGATIVE_ROWS and e & NEGATIVE_ROWS
    assert all(0 <= a < (1 << WIDTH) for a in family)
    new = family - leaves
    assert 1 <= len(new) <= 18
    for value in new:
        operands = [a for a in family if a != value and a | value == value]
        assert any(a | b == value for a, b in itertools.combinations(operands, 2))
    assert len(cover) <= 9 and len(new) + 2 * len(cover) <= budget
    assert union(cover) == TARGET
    clean = {pair_rows(a, b) for a in family for b in family}
    clean = {b for b in clean if b & TARGET == b}
    for value in cover:
        assert value in clean
        assert not any(v != value and value | v == v for v in clean)
        assert value & ~union(cover - {value})
    return len(new) + 2 * len(cover)


def checked_cover(family, candidate_cover):
    values = {pair_rows(a, b) for a in family for b in family}
    clean = {v for v in values if v & TARGET == v}
    maximal = set()
    for value in candidate_cover:
        extensions = [v for v in clean if value | v == v]
        maximal.add(max(extensions, key=lambda v: (v.bit_count(), v)))
    for value in sorted(maximal):
        remainder = maximal - {value}
        if union(remainder) == TARGET:
            maximal = remainder
    return maximal


def solve(count, budget, seconds, case):
    length = min(18, budget - 2 * count)
    if length < 1:
        raise ValueError("The requested budget leaves no OR nodes.")
    solver = z3.SolverFor("QF_BV")
    solver.set(timeout=seconds * 1000)
    d, e = z3.BitVecs("d e", WIDTH)
    inputs = [z3.BitVecVal(value, WIDTH) for value in VERTEX_ROWS]
    tagged = [d | TAG_D, e | TAG_E]
    nodes = [z3.BitVec(f"node_{i}", WIDTH) for i in range(length)]
    wires = inputs + tagged + nodes

    def select(name, available):
        bits = max(1, (len(available) - 1).bit_length())
        index = z3.BitVec(name, bits)
        if len(available) < (1 << bits):
            solver.add(z3.ULT(index, len(available)))
        value = available[-1]
        for i in reversed(range(len(available) - 1)):
            value = z3.If(index == i, available[i], value)
        return index, value

    for i, node in enumerate(nodes):
        a, left = select(f"node_{i}_left", wires[:len(inputs)+len(tagged)+i])
        b, right = select(f"node_{i}_right", wires[:len(inputs)+len(tagged)+i])
        solver.add(z3.ULE(a, b), node == left | right)
    not_a_seed = [z3.And(*(node != seed for seed in inputs + tagged)) for node in nodes]
    solver.add(z3.Or(*not_a_seed))
    for name, value in (("d", d), ("e", e)):
        a, left = select(name + "_left", inputs + nodes)
        b, right = select(name + "_right", inputs + nodes)
        solver.add(z3.ULE(a, b), left & ~ROWS == 0, right & ~ROWS == 0)
        solver.add(value == left & right, value & NEGATIVE_ROWS != 0)
    solver.add(z3.ULE(d, e))
    if case == "safe":
        solver.add(d & e & NEGATIVE_ROWS == 0)
    elif case == "overlap":
        solver.add(d & e & NEGATIVE_ROWS != 0)

    outputs = []
    for i in range(count):
        a, left = select(f"output_{i}_left", wires)
        b, right = select(f"output_{i}_right", wires)
        solver.add(z3.ULE(a, b), left & right & NEGATIVE_ROWS == 0)
        tag = z3.If((left | right) & (TAG_D | TAG_E) == TAG_D | TAG_E,
                    z3.BitVecVal(TAG_D, WIDTH), z3.BitVecVal(0, WIDTH))
        value = z3.BitVec(f"output_{i}", WIDTH)
        solver.add(value == (left & right & ROWS) | tag)
        if outputs:
            solver.add(z3.ULT(outputs[-1], value))
        outputs.append(value)
    solver.add(union(outputs) == TARGET)
    for i, value in enumerate(outputs):
        solver.add(value & ~union(outputs[:i] + outputs[i+1:]) != 0)

    return finish(solver, count, length, case, budget, d, e, wires, outputs)


def finish(solver, count, length, case, budget, d, e, wires, outputs):
    result = solver.check()
    row = {"count": count, "or_budget": length, "case": case, "result": str(result)}
    if result == z3.unknown:
        row["reason"] = solver.reason_unknown()
    elif result == z3.sat:
        model = solver.model()
        d_value = model.eval(d).as_long()
        e_value = model.eval(e).as_long()
        family = {model.eval(wire).as_long() for wire in wires}
        candidate_cover = {model.eval(value).as_long() for value in outputs}
        cover = checked_cover(family, candidate_cover)
        cost = verify_certificate(d_value, e_value, family, cover, budget)
        row["witness"] = {"d":d_value, "e":e_value, "family":sorted(family),
                          "cover":sorted(cover), "cost":cost}
    return row


def solve_supports(count, budget, seconds, case):
    length = min(18, budget - 2 * count)
    if length < 1:
        raise ValueError("The requested budget leaves no OR nodes.")
    solver = z3.SolverFor("QF_BV")
    solver.set(timeout=seconds * 1000)
    d, e = z3.BitVecs("d e", WIDTH)
    support_width = len(VERTEX_ROWS) + 2
    marker_d = 1 << len(VERTEX_ROWS)
    marker_e = marker_d << 1
    markers = marker_d | marker_e
    unit = [z3.BitVecVal(1 << i, support_width) for i in range(support_width)]
    nodes = [z3.BitVec(f"support_{i}", support_width) for i in range(length)]
    supports = unit + nodes

    def select(name, available):
        bits = max(1, (len(available) - 1).bit_length())
        index = z3.BitVec(name, bits)
        if len(available) < (1 << bits):
            solver.add(z3.ULT(index, len(available)))
        value = z3.BitVec(name + "_support", support_width)
        for i, source in enumerate(available):
            solver.add(z3.Implies(index == i, value == source))
        return index, value

    def actual_rows(support):
        row_sources = tuple(z3.BitVecVal(v, WIDTH) for v in VERTEX_ROWS) + (d | TAG_D, e | TAG_E)
        zero = z3.BitVecVal(0, WIDTH)
        return union(z3.If(support & (1 << i) != 0, v, zero) for i, v in enumerate(row_sources))

    for i, node in enumerate(nodes):
        a, left = select(f"node_{i}_left", supports[:len(unit)+i])
        b, right = select(f"node_{i}_right", supports[:len(unit)+i])
        solver.add(z3.ULE(a, b), node == left | right)
        solver.add(z3.If(node == 1, z3.And(a == 0, b == 0),
                         z3.And(node != left, node != right)))
        if i:
            solver.add(z3.Or(z3.And(node == 1, nodes[i-1] == 1), z3.ULT(nodes[i-1], node)))
    wires = [actual_rows(support) for support in supports]
    solver.add(z3.Or(*(z3.And(*(node != seed for seed in wires[:len(unit)]))
                       for node in wires[len(unit):])))

    for name, value in (("d", d), ("e", e)):
        a, left = select(name + "_left", unit[:-2] + nodes)
        b, right = select(name + "_right", unit[:-2] + nodes)
        solver.add(z3.ULE(a, b), left & markers == 0, right & markers == 0)
        solver.add(value == actual_rows(left) & actual_rows(right), value & NEGATIVE_ROWS != 0)
    solver.add(z3.ULE(d, e))
    if case == "safe":
        solver.add(d & e & NEGATIVE_ROWS == 0)
    elif case == "overlap":
        solver.add(d & e & NEGATIVE_ROWS != 0)
        solver.add(z3.Or(*(node & markers == markers for node in nodes)))
        solver.add(z3.Or(*(((d | e) & v & NEGATIVE_ROWS) == 0 for v in VERTEX_ROWS)))

    outputs = []
    for i in range(count):
        a, left = select(f"output_{i}_left", supports)
        b, right = select(f"output_{i}_right", supports)
        intersection = actual_rows(left) & actual_rows(right)
        solver.add(z3.ULE(a, b), intersection & NEGATIVE_ROWS == 0)
        tag = z3.If((left | right) & markers == markers,
                    z3.BitVecVal(TAG_D, WIDTH), z3.BitVecVal(0, WIDTH))
        value = z3.BitVec(f"output_{i}", WIDTH)
        solver.add(value == (intersection & ROWS) | tag)
        if outputs:
            solver.add(z3.ULT(outputs[-1], value))
        outputs.append(value)
    solver.add(union(outputs) == TARGET)
    for i, value in enumerate(outputs):
        solver.add(value & ~union(outputs[:i] + outputs[i+1:]) != 0)
    return finish(solver, count, length, case, budget, d, e, wires, outputs)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("count", type=int, choices=range(1, 10))
    parser.add_argument("--seconds", type=int, default=25)
    parser.add_argument("--budget", type=int, default=20)
    parser.add_argument("--case", choices=("all", "safe", "overlap"), default="all")
    parser.add_argument("--supports", action="store_true")
    args = parser.parse_args()
    run = solve_supports if args.supports else solve
    print(json.dumps(run(args.count, args.budget, args.seconds, args.case)), flush=True)


if __name__ == "__main__":
    main()
