import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem terminalUnionNeedsPrivateRow (d e w child other : Finset ℕ)
    (D B : Finset (Finset ℕ)) (cap : ℕ)
    (scenario : coverScenario d e D B)
    (budget : (D \ markedSeeds d e).card + 2 * B.card ≤ 20)
    (seeds : markedSeeds d e ⊆ D) (kBound : B.card ≤ cap)
    (optimal : ∀ E C, coverScenario d e E C → (E \ markedSeeds d e).card + 2 * C.card ≤ 20 →
      markedSeeds d e ⊆ E → C.card ≤ cap → coverRank d e D B ≤ coverRank d e E C)
    (paid : w ∈ D \ markedSeeds d e)
    (childIn : child ∈ D.erase w) (otherIn : other ∈ D.erase w) (childSub : child ⊆ w)
    (selected : productTerm w other ∈ B)
    (dStill : d ∈ plainIntersections (D.erase w)) (eStill : e ∈ plainIntersections (D.erase w))
    (buildStill : ∀ t ∈ D.erase w, t ∉ markedSeeds d e →
      ∃ a ∈ D.erase w, ∃ b ∈ D.erase w, a ⊂ t ∧ b ⊂ t ∧ t = a ∪ b)
    (pairsStill : ∀ t ∈ B, t ≠ productTerm w other →
      t ∈ Finset.image₂ productTerm (D.erase w) (D.erase w)) :
    ∃ r ∈ productTerm w other, r ∉ productTerm child other ∧
      ∀ t ∈ B, r ∈ t → t = productTerm w other := by
  classical
  by_contra noMissing
  have properties := scenario
  obtain ⟨_, _, _, _, _, _, _, _, _, cover, terms, _⟩ := properties
  let E := D.erase w
  let old := productTerm w other
  let new := productTerm child other
  let work := insert new (B.erase old)
  let family := (Finset.image₂ productTerm E E).filter fun t => t ⊆ insert 40 edgeRows
  have newClean : new ⊆ insert 40 edgeRows :=
    (productTermMonotone childSub Finset.Subset.rfl).trans (terms old selected).2.1
  have admitted (t : Finset ℕ) (ht : t ∈ work) : t ∈ family := by
    rcases Finset.mem_insert.mp ht with rfl | prior
    · exact Finset.mem_filter.mpr
        ⟨Finset.mem_image₂.mpr ⟨child, childIn, other, otherIn, rfl⟩, newClean⟩
    · obtain ⟨different, oldB⟩ := Finset.mem_erase.mp prior
      exact Finset.mem_filter.mpr ⟨pairsStill t oldB different, (terms t oldB).2.1⟩
  have otherTerm (r : ℕ) (inOld : r ∈ old) (noNew : r ∉ new) :
      ∃ t ∈ B.erase old, r ∈ t := by
    by_contra none
    apply noMissing
    refine ⟨r, inOld, noNew, ?_⟩
    intro t ht row
    by_contra different
    exact none ⟨t, Finset.mem_erase.mpr ⟨different, ht⟩, row⟩
  have full : work.biUnion id = insert 40 edgeRows := by
    ext r
    constructor
    · intro hr
      obtain ⟨t, ht, row⟩ := Finset.mem_biUnion.mp hr
      exact (Finset.mem_filter.mp (admitted t ht)).2 row
    · intro hr
      rw [← cover] at hr
      obtain ⟨t, ht, row⟩ := Finset.mem_biUnion.mp hr
      by_cases same : t = old
      · by_cases newHit : r ∈ new
        · exact Finset.mem_biUnion.mpr ⟨new, Finset.mem_insert_self _ _, newHit⟩
        · obtain ⟨x, hx, keep⟩ := otherTerm r (same ▸ row) newHit
          exact Finset.mem_biUnion.mpr ⟨x, Finset.mem_insert_of_mem hx, keep⟩
      · exact Finset.mem_biUnion.mpr ⟨t, Finset.mem_insert_of_mem (Finset.mem_erase.mpr ⟨same, ht⟩), row⟩
  obtain ⟨C, size, all, maximal, privateRows⟩ := maximalPrivateSubcover _ family work
    admitted full (fun _ h => (Finset.mem_filter.mp h).2)
  have workBound : work.card ≤ B.card :=
    (Finset.card_insert_le _ _).trans (Finset.card_erase_add_one selected).le
  have ready (t : Finset ℕ) (ht : t ∈ C) :
      t ∈ Finset.image₂ productTerm E E ∧ t ⊆ insert 40 edgeRows ∧
      ∀ s ∈ Finset.image₂ productTerm E E, s ⊆ insert 40 edgeRows → t ⊆ s → s = t := by
    obtain ⟨found, limits⟩ := maximal t ht
    obtain ⟨fromPair, clean⟩ := Finset.mem_filter.mp found
    exact ⟨fromPair, clean,
      fun s hs good grows => limits s (Finset.mem_filter.mpr ⟨hs, good⟩) grows⟩
  have fewer := size.trans workBound
  obtain ⟨valid, count⟩ := scenarioAfterErasingPaidWord d e w D B C scenario budget
    paid dStill eStill buildStill fewer all ready privateRows
  have keeps : markedSeeds d e ⊆ D.erase w := by
    intro s hs
    exact Finset.mem_erase.mpr ⟨fun eq => (Finset.mem_sdiff.mp paid).2 (eq ▸ hs), seeds hs⟩
  have nextCost : ((D.erase w) \ markedSeeds d e).card + 2 * C.card ≤ 20 := by omega
  have conflict := optimal (D.erase w) C valid nextCost keeps (fewer.trans kBound)
  dsimp [coverRank] at conflict
  omega

end PEqualNP.Outside.L_meta_9427

