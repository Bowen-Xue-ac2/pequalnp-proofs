import Mathlib

namespace PEqualNP.Outside.L_meta_9427

private theorem costWithOneOmissionAfterSmallProjection (d e : Finset ℕ)
    (D B : Finset (Finset ℕ)) (ds es : Finset (Fin 11))
    (dRows : d ⊆ actualRows) (eRows : e ⊆ actualRows)
    (dCard : ds.card ≤ 1) (eCard : es.card ≤ 1)
    (dPreserves : rowsOf ds ⊆ d) (ePreserves : rowsOf es ⊆ e)
    (few : ((((d \ rowsOf ds) ∪ (e \ rowsOf es)) ∩ edgeRows)).card ≤ 1)
    (build : ∀ w ∈ D, w ∉ markedSeeds d e →
      ∃ a ∈ D, ∃ b ∈ D, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b)
    (pairs : ∀ t ∈ B, ∃ a ∈ D, ∃ b ∈ D,
      t = productTerm a b ∧ t ⊆ insert 40 edgeRows)
    (cover : B.biUnion id = insert 40 edgeRows) :
    21 ≤ (D \ markedSeeds d e).card + 2 * B.card := by
  obtain ⟨label, replay, paid, builds⟩ := projectionWithSmallSeedImages d e D ds es
    dRows eRows dCard eCard dPreserves ePreserves build
  let omitted := ((d \ rowsOf ds) ∪ (e \ rowsOf es)) ∩ edgeRows
  let erased := (Finset.univ : Finset (Fin 16)).filter fun r => r.val ∈ omitted
  let missing := erased.image edgeAt
  have count : missing.card ≤ 1 := by
    have below : erased.image Fin.val ⊆ omitted := by
      intro r hr
      obtain ⟨u, hu, rfl⟩ := Finset.mem_image.mp hr
      exact (Finset.mem_filter.mp hu).2
    have equal : (erased.image Fin.val).card = erased.card :=
      Finset.card_image_of_injective _ (fun _ _ h => Fin.ext h)
    exact Finset.card_image_le.trans
      (equal.symm.le.trans ((Finset.card_le_card below).trans few))
  have missingBound : missing ⊆ orientedEdges := by
    intro f hf
    obtain ⟨r, _, rfl⟩ := Finset.mem_image.mp hf
    exact edgeAtOriented r
  have preserved (w : Finset ℕ) (wD : w ∈ D) (r : Fin 16)
      (hw : r.val ∈ w) (notMissing : edgeAt r ∉ missing) : r.val ∈ rowsOf (label w) := by
    have real : r.val ∈ actualRows := Finset.mem_range.mpr (r.isLt.trans (by decide : 16 < 40))
    have edge : r.val ∈ edgeRows := Finset.mem_range.mpr r.isLt
    have still : r.val ∉ omitted := fun h => notMissing (Finset.mem_image.mpr
      ⟨r, Finset.mem_filter.mpr ⟨Finset.mem_univ _, h⟩, rfl⟩)
    have copy (S : Finset (Fin 11)) (inLabel : S ⊆ label w) (seen : r.val ∈ rowsOf S) :
        r.val ∈ rowsOf (label w) := by
      obtain ⟨u, use, found⟩ := Finset.mem_biUnion.mp seen
      exact Finset.mem_biUnion.mpr ⟨u, inLabel use, found⟩
    rcases (replay w wD).2.2.2 r.val hw real with retained | ⟨a, hd⟩ | ⟨b, he⟩
    · exact retained
    · apply copy ds ((replay w wD).2.1 a).2
      by_contra absent
      exact still (Finset.mem_inter.mpr
        ⟨Finset.mem_union_left _ (Finset.mem_sdiff.mpr ⟨hd, absent⟩), edge⟩)
    · apply copy es ((replay w wD).2.2.1 b).2
      by_contra absent
      exact still (Finset.mem_inter.mpr
        ⟨Finset.mem_union_right _ (Finset.mem_sdiff.mpr ⟨he, absent⟩), edge⟩)
  have projected (t : Finset ℕ) (ht : t ∈ B) :
      ∃ a ∈ D, ∃ b ∈ D, rowsOf (label a) ∩ rowsOf (label b) ⊆ edgeRows ∧
        ∀ r : Fin 16, r.val ∈ t → edgeAt r ∉ missing → r.val ∈ rowsOf (label a) ∩ rowsOf (label b) := by
    obtain ⟨a, aD, b, bD, eq, clean⟩ := pairs t ht
    have known := cleanProductFacts a b (eq ▸ clean)
    refine ⟨a, aD, b, bD, projectedClean _ _ _ _ (replay a aD).1 (replay b bD).1 known.1, ?_⟩
    intro r row kept
    have original : r.val ∈ t ∩ edgeRows := Finset.mem_inter.mpr ⟨row, Finset.mem_range.mpr r.isLt⟩
    rw [eq, known.2.1] at original
    obtain ⟨left, right⟩ := Finset.mem_inter.mp (Finset.mem_inter.mp original).1
    exact Finset.mem_inter.mpr ⟨preserved a aD r left kept, preserved b bD r right kept⟩
  have full : edgeRows ⊆ B.biUnion id := by rw [cover]; exact Finset.subset_insert _ _
  have lower := projectedCostWithMissing D B label missing missingBound builds projected full
  omega

end PEqualNP.Outside.L_meta_9427

