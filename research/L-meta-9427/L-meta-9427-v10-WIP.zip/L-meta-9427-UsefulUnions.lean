import Mathlib

namespace PEqualNP.Outside.L_meta_9427

def usableSupport (centers s : Finset (Fin 11)) (allowed : Fin 11 → Finset (Fin 11)) : Prop :=
  ∃ u ∈ centers, s ⊆ allowed u

instance (centers s : Finset (Fin 11)) (allowed : Fin 11 → Finset (Fin 11)) :
    Decidable (usableSupport centers s allowed) := by
  unfold usableSupport
  infer_instance

def usefulProjection (D : Finset (Finset ℕ)) (label : Finset ℕ → Finset (Fin 11))
    (centers : Finset (Fin 11)) (allowed : Fin 11 → Finset (Fin 11)) :
    Finset (Finset (Fin 11)) :=
  (D.image label).filter fun s => usableSupport centers s allowed

private theorem usefulBuild (D : Finset (Finset ℕ)) (label : Finset ℕ → Finset (Fin 11))
    (centers : Finset (Fin 11)) (allowed : Fin 11 → Finset (Fin 11))
    (build : ∀ w ∈ D.image label, 1 < w.card →
      ∃ a ∈ D.image label, ∃ b ∈ D.image label, a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b) :
    ∀ w ∈ usefulProjection D label centers allowed, 1 < w.card →
      ∃ a ∈ usefulProjection D label centers allowed, ∃ b ∈ usefulProjection D label centers allowed,
        a ⊂ w ∧ b ⊂ w ∧ w = a ∪ b := by
  intro w hw big
  obtain ⟨wMem, u, huC, hu⟩ := Finset.mem_filter.mp hw
  obtain ⟨a, ha, b, hb, asub, bsub, eq⟩ := build w wMem big
  exact ⟨a, Finset.mem_filter.mpr ⟨ha, u, huC, asub.1.trans hu⟩,
    b, Finset.mem_filter.mpr ⟨hb, u, huC, bsub.1.trans hu⟩, asub, bsub, eq⟩

noncomputable def discardedUnions (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11)) (centers : Finset (Fin 11))
    (allowed : Fin 11 → Finset (Fin 11)) : Finset (Finset ℕ) := by
  classical
  exact (D \ X).filter fun w => w ∈ redundantUnions D X label ∨ ¬usableSupport centers (label w) allowed

private theorem usefulProjectionDeficit (D X : Finset (Finset ℕ))
    (label : Finset ℕ → Finset (Fin 11)) (centers : Finset (Fin 11))
    (allowed : Fin 11 → Finset (Fin 11))
    (root : ∀ w ∈ D, w ∈ X → (label w).card ≤ 1)
    (U : Finset (Finset ℕ))
    (unused : ∀ w ∈ U, w ∈ D \ X ∧ ¬carriesTag w ∧ ¬usableSupport centers (label w) allowed) :
    ((usefulProjection D label centers allowed).filter fun s => 1 < s.card).card + U.card +
      (redundantTaggedUnions D X label).card ≤ (D \ X).card := by
  classical
  let G := discardedUnions D X label centers allowed
  have incidence : ((usefulProjection D label centers allowed).filter fun s => 1 < s.card) ⊆
      ((D \ X) \ G).image label := by
    intro s hs
    obtain ⟨good, large⟩ := Finset.mem_filter.mp hs
    obtain ⟨image, kept⟩ := Finset.mem_filter.mp good
    obtain ⟨w, hw, eq⟩ := Finset.mem_image.mp image
    let candidates := D.filter fun t => label t = s
    have has : candidates.Nonempty := ⟨w, Finset.mem_filter.mpr ⟨hw, eq⟩⟩
    obtain ⟨v, hv, least⟩ := Finset.exists_min_image candidates Finset.card has
    obtain ⟨vD, vEq⟩ := Finset.mem_filter.mp hv
    have vX : v ∉ X := by
      intro h
      have bound := root v vD h
      rw [vEq] at bound
      exact (Nat.not_le_of_gt large) bound
    have vG : v ∉ G := by
      intro discarded
      rcases (Finset.mem_filter.mp discarded).2 with redundant | irrelevant
      · obtain ⟨_, a, ha, smaller, equal⟩ := (redundantIff D X label v).mp redundant
        have earlier : a ∈ candidates := Finset.mem_filter.mpr ⟨ha, equal.trans vEq⟩
        exact (Nat.not_lt_of_ge (least a earlier)) (Finset.card_lt_card smaller)
      · exact irrelevant (vEq.symm ▸ kept)
    exact Finset.mem_image.mpr
      ⟨v, Finset.mem_sdiff.mpr ⟨Finset.mem_sdiff.mpr ⟨vD, vX⟩, vG⟩, vEq⟩
  have count := (Finset.card_le_card incidence).trans Finset.card_image_le
  have within : G ⊆ D \ X := Finset.filter_subset _ _
  have equation := Finset.card_sdiff_add_card_eq_card within
  have disjoint : Disjoint U (redundantTaggedUnions D X label) := by
    apply Finset.disjoint_left.mpr
    intro s hu htag
    exact (unused s hu).2.1 (Finset.mem_filter.mp htag).2
  have unionSub : U ∪ redundantTaggedUnions D X label ⊆ G := by
    intro s hs
    rcases Finset.mem_union.mp hs with useless | tagged
    · exact Finset.mem_filter.mpr ⟨(unused s useless).1, Or.inr (unused s useless).2.2⟩
    · have redundant := (Finset.mem_filter.mp tagged).1
      exact Finset.mem_filter.mpr ⟨((redundantIff D X label s).mp redundant).1, Or.inl redundant⟩
  have discarded := Finset.card_le_card unionSub
  rw [Finset.card_union_of_disjoint disjoint] at discarded
  omega

private theorem noCommonNeighborFromRows (d e w : Finset ℕ)
    (ds es s centers : Finset (Fin 11)) (shape : projectionFacts d e ds es w s)
    (untagged : ¬carriesTag w)
    (noRoot : ∀ u ∈ centers, ¬(w ∩ rootSet u ∩ actualRows ⊆ edgeRows)) :
    ¬usableSupport centers s neighbors := by
  intro any
  obtain ⟨u, huC, hu⟩ := any
  apply noRoot u huC
  intro r hr
  obtain ⟨pair, actual⟩ := Finset.mem_inter.mp hr
  obtain ⟨inW, inRoot⟩ := Finset.mem_inter.mp pair
  have projected : r ∈ rowsOf s := by
    rcases shape.2.2.2 r inW actual with good | ⟨flag, _⟩ | ⟨flag, _⟩
    · exact good
    · exact (untagged (Or.inl flag)).elim
    · exact (untagged (Or.inr flag)).elim
  obtain ⟨v, hv, rowV⟩ := Finset.mem_biUnion.mp projected
  have adj := (Finset.mem_filter.mp (hu hv)).2
  have allowed := (rootSetPair v u).2 ((edgeSwap u v).1 adj)
  exact allowed (Finset.mem_inter.mpr ⟨rowV, inRoot⟩)

end PEqualNP.Outside.L_meta_9427
